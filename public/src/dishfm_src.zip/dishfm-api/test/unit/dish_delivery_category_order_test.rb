require 'test_helper'

class DishDeliveryCategoryOrderTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  test "the truth" do
    assert true
  end
end
