require 'test_helper'

class RestaurantsHelperTest < ActionView::TestCase
end
