require 'test_helper'

class DishfeedHelperTest < ActionView::TestCase
end
