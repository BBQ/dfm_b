require 'test_helper'

class AutocompleteSearchesHelperTest < ActionView::TestCase
end
