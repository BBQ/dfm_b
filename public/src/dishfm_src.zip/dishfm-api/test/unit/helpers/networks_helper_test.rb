require 'test_helper'

class NetworksHelperTest < ActionView::TestCase
end
