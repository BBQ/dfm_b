require 'test_helper'

class DishesHelperTest < ActionView::TestCase
end
