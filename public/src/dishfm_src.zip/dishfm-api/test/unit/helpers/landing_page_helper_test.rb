require 'test_helper'

class LandingPageHelperTest < ActionView::TestCase
end
