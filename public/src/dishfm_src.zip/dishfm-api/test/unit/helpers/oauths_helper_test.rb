require 'test_helper'

class OauthsHelperTest < ActionView::TestCase
end
