module OauthsHelper
end
