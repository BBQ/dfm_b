class RestaurantCategory < ActiveRecord::Base
end
