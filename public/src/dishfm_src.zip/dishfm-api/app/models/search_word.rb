class SearchWord < ActiveRecord::Base
end
