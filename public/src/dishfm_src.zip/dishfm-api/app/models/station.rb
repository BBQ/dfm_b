class Station < ActiveRecord::Base
end
