class ParserStat < ActiveRecord::Base
end
