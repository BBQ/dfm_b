class HomeCookTag < ActiveRecord::Base
end
