class MiDish < ActiveRecord::Base
  belongs_to :mi_restaurant
end
