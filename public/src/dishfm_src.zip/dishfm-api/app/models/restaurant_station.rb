class RestaurantStation < ActiveRecord::Base
end
