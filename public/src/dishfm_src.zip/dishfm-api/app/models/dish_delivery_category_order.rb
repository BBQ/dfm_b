class DishDeliveryCategoryOrder < ActiveRecord::Base
end
