class DishHomeCook < ActiveRecord::Base
end
