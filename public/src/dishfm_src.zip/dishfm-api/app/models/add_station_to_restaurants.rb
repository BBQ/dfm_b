class AddStationToRestaurants < ActiveRecord::Base
end
