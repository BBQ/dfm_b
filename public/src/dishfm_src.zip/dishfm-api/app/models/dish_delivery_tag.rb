class DishDeliveryTag < ActiveRecord::Base
end
