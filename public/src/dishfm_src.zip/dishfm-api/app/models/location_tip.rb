class LocationTip < ActiveRecord::Base
end
