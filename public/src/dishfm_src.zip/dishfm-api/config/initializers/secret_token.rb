# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Dishfm::Application.config.secret_token = '83c3bb6015bf99cec290c114435bd768ee981508fe4dac2ea8cc99ed96ea0f9d16741e6d90aac2cbceca6a4baca978575978f13bc93f75d0ba61d229ce0ce83e'
