Twitter.configure do |config|
  config.consumer_key = '1DQYnbvFrRFfbmm0SU9IVg'
  config.consumer_secret = 'ixUaNcyUlAUUVc6KXKMWUZudqMWkVNbrbseYKckbjI'
  # config.oauth_token = YOUR_OAUTH_TOKEN
  # config.oauth_token_secret = YOUR_OAUTH_TOKEN_SECRET
end