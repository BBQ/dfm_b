#import <UIKit/UIKit.h>
#import "HJManagedImageV.h"
#import "HJObjManager.h"
#import "FeedItemModel.h"
#import "RequestProcessor.h"
#import "ActiveStarView.h"
#import "CuteDotsController.h"
#import "DishModel.h"
#import "SmartJumpingController.h"

@interface DishController : UIViewController<UITextViewDelegate>
{
    NSDictionary *_dishDetails;
    
    HJManagedImageV *_reviewAvatar;
    HJManagedImageV *_reviewPhoto;
    
    BOOL _firstTimeReviewSet;
    BOOL _isSendingReview;
    
    UINavigationBar *_navBar;
    
    float _rating;
    
    NSInteger _previousPage;
    
    ActiveStarView *_activeStarView;
    IBOutlet UIView *_readAllReviewsView;
    
    IBOutlet UILabel *_dishNameLabel;
    
    IBOutlet UILabel *_dishDescriptionLabel;
    IBOutlet UIButton *_allLocationsButton;
    CuteDotsController *_cuteDotsController;
    IBOutlet UIView *_cuteDotsPlaceholder;
    IBOutlet UIButton *_addReviewWithPhotoButton;
    
    
    IBOutlet UIView *_detailsView;
    IBOutlet UILabel *_reviewCommentsCountLabel;
    IBOutlet UILabel *_reviewLikesCountLabel;
    
    IBOutlet UILabel *_priceLabel;
    
    IBOutletCollection(UIView) NSArray *_viewsWithShadow;
    
    NSMutableArray *_reviewsWithPhoto;
    
    IBOutlet UIView *_addReviewView;
    
    BOOL _homeCooked;
    
    IBOutletCollection(UIView) NSArray* _placeSpecificViews;
    
    IBOutlet UIButton *_expertButton;
    
    CheckinType _type;
    
    NSDictionary *_nearestRestaurant;
    
    IBOutlet UIView *_SJCPlaceholder;
    SmartJumpingController *_SJC;
    IBOutlet UIButton *_saveButton;
}

/*
 outlets
 */

@property (nonatomic, retain) IBOutletCollection(UIView) NSArray *roundableViews;
@property (retain, nonatomic) IBOutlet UIView *scrollViewContent;
@property (retain, nonatomic) IBOutlet UILabel *ratingLabel;
@property (retain, nonatomic) IBOutlet UIScrollView *reviewScrollView;
@property (retain, nonatomic) IBOutlet UIPageControl *pageControl;

@property (retain, nonatomic) IBOutlet UIView *quickReviewView;

//ratings
@property (retain, nonatomic) IBOutlet UILabel *ratingRestaurantPosition;
@property (retain, nonatomic) IBOutlet UILabel *ratingRestaurantSubtitle;
@property (retain, nonatomic) IBOutlet UILabel *ratingTypePosition;
@property (retain, nonatomic) IBOutlet UILabel *ratingTypeSubtitle;

@property (nonatomic, retain) IBOutletCollection(UIImageView) NSArray *ratingStars;

@property (retain, nonatomic) IBOutlet UIButton *restaurantRatingButton;
@property (retain, nonatomic) IBOutlet UIButton *categoryRatingButton;


//top expert
@property (retain, nonatomic) IBOutlet UIView *topExpertAvatarPlaceholder;
@property (retain, nonatomic) IBOutlet UILabel *topExpertName;

//review
@property (retain, nonatomic) IBOutlet UIView *reviewDishPhotoPlaceholder;

@property (retain, nonatomic) IBOutlet UIButton *reviewUsernameButton;
@property (retain, nonatomic) IBOutlet UILabel *reviewText;

@property (retain, nonatomic) IBOutletCollection(UIImageView) NSArray *reviewStars;

//your reviews
@property (retain, nonatomic) IBOutlet UIView *yourReviewsView;
@property (retain, nonatomic) IBOutlet UILabel *yourReviewsText;
@property (retain, nonatomic) IBOutlet UIButton *allUserReviewsButton;
@property (retain, nonatomic) IBOutletCollection(UIImageView) NSArray *yourReviewStars;
@property (retain, nonatomic) IBOutlet UIView *yourReviewPhoto;

//details
@property (retain, nonatomic) IBOutlet UIView *detailsPhotoPlaceholder;
@property (retain, nonatomic) IBOutlet UILabel *detailText;


//restaurant
@property (retain, nonatomic) IBOutlet UILabel *restaurantName;
@property (retain, nonatomic) IBOutlet UILabel *restaurantAddress;
@property (retain, nonatomic) IBOutlet UILabel *restaurantPhone;
@property (retain, nonatomic) IBOutlet UILabel *restaurantWorkingHours;
@property (retain, nonatomic) IBOutlet UIButton *restaurantButton;
@property (retain, nonatomic) IBOutlet UIButton *restaurantButton2;

//map
@property (retain, nonatomic) IBOutlet MKMapView *mapView;

@property (retain, nonatomic) IBOutletCollection(UIView) NSArray *viewsToHide;

//quick review
@property (retain, nonatomic) IBOutlet UIView *quickReviewCommentView;
@property (retain, nonatomic) IBOutlet UILabel *quickReviewLabel;
@property (retain, nonatomic) IBOutlet UITextView *quickReviewText;
@property (retain, nonatomic) IBOutletCollection(UIButton) NSArray *quickReviewStars;

/*
 properties
 */

@property (nonatomic, retain) UIScrollView *scrollView;
@property (readwrite, assign) NSInteger dishId;
@property (nonatomic, retain) RequestProcessor *requestProcessor;

@property (nonatomic, retain) RequestProcessor *dishInRP;
@property (nonatomic, retain) NSString *dishName;

@property (nonatomic, retain) NSNumber *currentReviewID;
@property (nonatomic, retain) NSMutableArray *restaurants;

@property (readwrite, assign) BOOL isFound;

- (void)rateView:(ActiveStarView *)view ratingDidChange:(double)rating;

- (id)initWithDishId:(NSInteger)aDishId;
- (id)initWithDishId:(NSInteger)aDishId
          homeCooked:(BOOL)homeCooked;
- (id)initWithDishId:(NSInteger)aDishId
                type:(CheckinType)type;

- (IBAction)addReviewWithPhoto:(id)sender;
- (IBAction)restaurantPositionClick:(id)sender;
- (IBAction)showOnMap:(id)sender;
- (IBAction)cancelQuickReview:(id)sender;
- (IBAction)postQuickReview:(id)sender;
- (IBAction)showUserReviews:(id)sender;
- (IBAction)showAllReviews:(id)sender;
- (IBAction)showReview:(id)sender;
- (IBAction)showUserProfile:(id)sender;
- (IBAction)showReviewUserProfile:(id)sender;

@end
