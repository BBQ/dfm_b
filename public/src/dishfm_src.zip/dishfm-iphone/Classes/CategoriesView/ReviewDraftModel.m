//
//  ReviewDraftModel.m
//  dish.fm
//
//  Created by Petr Prokop on 5/3/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "ReviewDraftModel.h"

@implementation ReviewDraftModel

@synthesize reviewType;
@synthesize photoData;
@synthesize uuid;
@synthesize restaurantID;
@synthesize restaurantName;
@synthesize foursquareVenueID;
@synthesize reviewText;
@synthesize reviewRating;
@synthesize postOnFacebook;
@synthesize postOnTwitter;
@synthesize postOnPinterest;
@synthesize dishName;
@synthesize dishPrice;
@synthesize typeID;
@synthesize subtypeID;
@synthesize dishID;
@synthesize checkinType; 
@synthesize taggedFriends;
@synthesize reviewStatus;
@synthesize authorSystemID;
@synthesize reviewID;

- (void)saveToFile {
    
    if(!self.uuid || self.reviewType == kUndefined)
        return;
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	
	NSString *reviewFile = 
    [documentsDirectory stringByAppendingPathComponent: [NSString stringWithFormat:@"%@.plist", self.uuid]];
    
    NSMutableDictionary *dictToSave = [[NSMutableDictionary alloc] init];
    
    [dictToSave setObject:[NSNumber numberWithInt:self.reviewType] forKey:@"reviewType"];
    
    if(self.uuid)
        [dictToSave setObject:self.uuid forKey:@"uuid"];
    
    if(self.photoData)
        [dictToSave setObject:self.photoData forKey:@"photoData"];
    
    if(self.restaurantID)
        [dictToSave setObject:self.restaurantID forKey:@"restaurantID"];
    
    if(self.restaurantName)
        [dictToSave setObject:self.restaurantName forKey:@"restaurantName"];
    
    if(self.foursquareVenueID)
        [dictToSave setObject:self.foursquareVenueID forKey:@"foursquareVenueID"];
    
    if(self.reviewText)
        [dictToSave setObject:self.reviewText forKey:@"reviewText"];
    
    if(self.reviewRating)
        [dictToSave setObject:self.reviewRating forKey:@"reviewRating"];
    
    if(self.postOnFacebook)
        [dictToSave setObject:self.postOnFacebook forKey:@"postOnFacebook"];
    
    if(self.postOnTwitter)
        [dictToSave setObject:self.postOnTwitter forKey:@"postOnTwitter"];
    
    if(self.postOnPinterest)
        [dictToSave setObject:self.postOnPinterest forKey:@"postOnPinterest"];
    
    if(self.dishName)
        [dictToSave setObject:self.dishName forKey:@"dishName"];
    
    if(self.dishPrice)
        [dictToSave setObject:self.dishPrice forKey:@"dishPrice"];
    
    if(self.typeID)
        [dictToSave setObject:self.typeID forKey:@"typeID"];
    
    if(self.subtypeID)
        [dictToSave setObject:self.subtypeID forKey:@"subtypeID"];
    
    if(self.dishID)
        [dictToSave setObject:self.dishID forKey:@"dishID"];
    
    [dictToSave setObject:[NSNumber numberWithInt:self.checkinType] forKey:@"checkinType"];
    
    if(self.taggedFriends)
        [dictToSave setObject:self.taggedFriends forKey:@"taggedFriends"];

    
    [dictToSave setObject:[NSNumber numberWithInt:self.reviewStatus] forKey:@"reviewStatus"];
    
    if(self.authorSystemID)
        [dictToSave setObject:self.authorSystemID forKey:@"authorSystemID"];
    
    if(self.reviewID)
        [dictToSave setObject:self.reviewID forKey:@"reviewID"];
    
    //dlog(@"dictToSave %@", dictToSave);
    
    if(![dictToSave writeToFile:reviewFile atomically:NO])
    {
        dlog(@"error saving to file");
    }
    
    [dictToSave release];
}

+ (ReviewDraftModel *)modelWithContentsOfFile:(NSString *)file
{
    NSDictionary *dictionary = [NSDictionary dictionaryWithContentsOfFile:file];

    //dlog(@"dictionary %@", dictionary);
    
    ReviewDraftModel *rdm = [[ReviewDraftModel alloc] init];
    
    rdm.reviewType = [[dictionary objectForKey:@"reviewType"] intValue];
    rdm.uuid = [dictionary objectForKey:@"uuid"];
    rdm.photoData = [dictionary objectForKey:@"photoData"];
    rdm.restaurantID = [dictionary objectForKey:@"restaurantID"];
    rdm.restaurantName = [dictionary objectForKey:@"restaurantName"];
    rdm.foursquareVenueID = [dictionary objectForKey:@"foursquareVenueID"];
    rdm.reviewText = [dictionary objectForKey:@"reviewText"];
    rdm.reviewRating = [dictionary objectForKey:@"reviewRating"];
    rdm.postOnFacebook = [dictionary objectForKey:@"postOnFacebook"];
    rdm.postOnTwitter = [dictionary objectForKey:@"postOnTwitter"];
    rdm.postOnPinterest = [dictionary objectForKey:@"postOnPinterest"];
    rdm.dishName = [dictionary objectForKey:@"dishName"];
    rdm.dishPrice= [dictionary objectForKey:@"dishPrice"];
    rdm.typeID = [dictionary objectForKey:@"typeID"];
    rdm.subtypeID = [dictionary objectForKey:@"subtypeID"];
    rdm.dishID = [dictionary objectForKey:@"dishID"];
    rdm.checkinType = [[dictionary objectForKey:@"checkinType"] intValue];
    rdm.taggedFriends = [dictionary objectForKey:@"taggedFriends"];
    rdm.reviewStatus = (ReviewStatus) [[dictionary objectForKey:@"reviewStatus"] intValue];
    rdm.authorSystemID = [dictionary objectForKey:@"authorSystemID"];
    rdm.reviewID = [dictionary objectForKey:@"reviewID"];
    
    return [rdm autorelease];
}

@end