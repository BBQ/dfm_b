//
//  ReviewDraftModel.h
//  dish.fm
//
//  Created by Petr Prokop on 5/3/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CheckinType.h"

typedef enum {
    kUndefined = 0,
    kReviewTypeNormal,
    kReviewTypeDraft
} ReviewType;

typedef enum {
    kReviewStatusUndefined = 0,
    kReviewStatusInQueue,
    kReviewStatusLoading,
    kReviewStatusLoaded,
    kReviewStatusFailed,
} ReviewStatus;

@interface ReviewDraftModel : NSObject

@property (readwrite, assign) ReviewType reviewType; 
@property (nonatomic, retain) NSData *photoData;
@property (nonatomic, retain) NSString *uuid;
@property (nonatomic, retain) NSNumber *restaurantID;
@property (nonatomic, retain) NSString *restaurantName;
@property (nonatomic, retain) NSString *foursquareVenueID;
@property (nonatomic, retain) NSString *reviewText;
@property (nonatomic, retain) NSNumber *reviewRating;
@property (nonatomic, retain) NSNumber *postOnFacebook;
@property (nonatomic, retain) NSNumber *postOnTwitter;
@property (nonatomic, retain) NSNumber *postOnPinterest;
@property (nonatomic, retain) NSString *dishName;
@property (nonatomic, retain) NSNumber *dishPrice;
@property (nonatomic, retain) NSNumber *typeID;
@property (nonatomic, retain) NSNumber *subtypeID;
@property (nonatomic, retain) NSNumber *dishID;
@property (readwrite, assign) CheckinType checkinType; 
@property (nonatomic, retain) NSMutableArray *taggedFriends;
@property (readwrite, assign) ReviewStatus reviewStatus; 
@property (nonatomic, retain) NSNumber *authorSystemID;
@property (nonatomic, retain) NSNumber *reviewID;

- (void)saveToFile;
+ (ReviewDraftModel *)modelWithContentsOfFile:(NSString *)file;

@end
