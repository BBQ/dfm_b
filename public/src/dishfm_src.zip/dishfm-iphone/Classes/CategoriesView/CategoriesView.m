//you can change it for something else 
#define kFirstButtonBGTag 654654
#define kButtonDistance 2.0f
#define kButtonHeight 73.0f
#define kButtonVerticalOrigin 0.0f

#define kFont [UIFont fontWithName:@"HelveticaNeue-Bold" size:14.0f]
#define kLabelNormalTextColor [UIColor colorWithRed:117.0/255 green:90.0/255 blue:76.0/255 alpha:1.0f]

#import "CategoriesView.h"
#import "DataSource.h"
#import "HJManagedImageV.h"

@implementation CategoriesView

@synthesize keywords = _keywords;
@synthesize images = _images;
@synthesize scrollView = _scrollView,
            delegate,
            searchString = _searchString;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 
                                                                     0, 
                                                                     frame.size.width, 
                                                                     frame.size.height)];
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
        
        self.searchString = nil;
        
        [self addSubview:_scrollView];
    }
    
    return self;
}
- (void)dealloc
{
    self.searchString = nil;
    self.images = nil;
    [_scrollView release];
    [super dealloc];
}

- (void)setKeywords:(NSArray *)keywordsToSet
{
    [keywordsToSet retain];
    [_keywords release];
    _keywords = keywordsToSet;
    
    
    for(UIView *subview in [_scrollView subviews])
    {
        [subview removeFromSuperview];
    }
    
    CGFloat horizontalShift = kButtonDistance;
    
    NSArray *keywordsAndSearchStringArray = _keywords;
    
    if(self.searchString)
        keywordsAndSearchStringArray = [_keywords arrayByAddingObject:self.searchString];
    
    for(NSInteger i = 0; i < [keywordsAndSearchStringArray count]; i++)
    {
        UIButton *button = [[UIButton alloc] init];
        
        button.titleLabel.numberOfLines = 0;
        button.titleLabel.lineBreakMode = UILineBreakModeWordWrap;
        button.titleLabel.textAlignment = UITextAlignmentCenter;
        
        NSString *title = [keywordsAndSearchStringArray objectAtIndex:i];
        
        if(![title isKindOfClass:[NSString class]])
            title = @"";
        
        [button setTitle:title forState:UIControlStateNormal];
        button.titleLabel.font = kFont;
        
        UIImage *passiveImage = [UIImage imageNamed:@"buttonCategoryTop.png"];
        UIImage *activeImage = [UIImage imageNamed:@"categoryBtnActive.png"];
        
        button.frame = CGRectMake(horizontalShift, 
                                  kButtonVerticalOrigin, 
                                  kButtonHeight, 
                                  kButtonHeight);
        
        button.tag = i + kFirstButtonBGTag;
        

        [button setBackgroundImage:passiveImage forState:UIControlStateNormal];
        [button setBackgroundImage:activeImage forState:UIControlStateSelected];
        
        [button addTarget:self 
                   action:@selector(click:) 
         forControlEvents:UIControlEventTouchUpInside];
        
        [button setTitleColor:kLabelNormalTextColor forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
        
        horizontalShift += kButtonHeight;
        horizontalShift += kButtonDistance;
        
        [_scrollView addSubview:button];
    }
    
    _scrollView.contentSize = CGSizeMake(horizontalShift, _scrollView.frame.size.height);
}

- (void)setImages:(NSArray *) imagesToSet
{
    [imagesToSet retain];
    [_images release];
    _images = imagesToSet;
    
    for(NSInteger i = 0; i < MIN([_images count], [_keywords count]); i++)
    {
        UIButton *currentButton = (UIButton *) [self viewWithTag:i + kFirstButtonBGTag];
        NSString *image = [_images objectAtIndex:i];
        if(image && ![image isEqualToString:@""])
        {
            [currentButton setTitleEdgeInsets:
             UIEdgeInsetsMake(0.0, 0.0, -currentButton.frame.size.height+16.0, 0.0)];
            
            HJManagedImageV *miv = 
            [[HJManagedImageV alloc] initWithFrame:CGRectMake(16, 
                                                              16, 
                                                              currentButton.frame.size.width-32,
                                                              currentButton.frame.size.height-32)];
            miv.url = [NSURL URLWithString:image];
            [currentButton addSubview:miv];
            [[DataSource instance].objMan manage:miv];
        }
    }
}

- (void)setSearchString:(NSString *)searchString
{
    if([_keywords indexOfObject:searchString] == NSNotFound)
    {
        [searchString retain];
        [_searchString release];
        _searchString = searchString;
        
        [self setKeywords:_keywords];
    }
    
    [self setKeywordSelected:[_keywords count]];
}

- (void)click:(id) sender
{
    UIButton *button = (UIButton *)sender;
    
    [self selectNone];
    
    [self.delegate categorySelected:[self.keywords objectAtIndex:button.tag - kFirstButtonBGTag]];
    
    button.selected = YES;
}

- (void)setKeywordSelected:(NSInteger) keywordIndex
{
    [self selectNone];
    
    UIButton *button = (UIButton *)[self viewWithTag:keywordIndex + kFirstButtonBGTag];
    button.selected = YES;
    
    CGRect frameToSroll = CGRectMake(button.frame.origin.x - kButtonDistance, 
                                     button.frame.origin.y, 
                                     button.frame.size.width + kButtonDistance * 2, 
                                     button.frame.size.height);
    
    [_scrollView scrollRectToVisible:frameToSroll animated:YES];
    
    [self.delegate categorySelected:[self.keywords objectAtIndex:keywordIndex]];
}

- (void)selectNone
{
    for(NSInteger i = 0; i < [_keywords count]; i++)
    {
        UIButton *currentButton = (UIButton *) [self viewWithTag:i + kFirstButtonBGTag];
        currentButton.selected = NO;
    }
}

@end
