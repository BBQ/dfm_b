//
//  KeywordsView.h
//  dish.fm
//
//  Created by Petr Prokop on 11/24/11.
//  Copyright (c) 2011 Dish.FM. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CategoriesViewDelegate <NSObject>

- (void)categorySelected:(NSString *)keyword;

@end

@interface CategoriesView : UIView
{
    NSArray *_keywords;
    NSString *_searchString;
    UIScrollView *_scrollView;
}

@property (nonatomic, retain) NSArray *keywords;
@property (nonatomic, retain) NSArray *images;
@property (nonatomic, retain) UIScrollView *scrollView;
@property (nonatomic, assign) id<CategoriesViewDelegate> delegate;
@property (retain, nonatomic) NSString *searchString;

- (void)setKeywordSelected:(NSInteger) keywordIndex;
- (void)setSearchString:(NSString *)searchString;
- (void)selectNone;

@end
