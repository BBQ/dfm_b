//
//  RestaurantBestDishesItemController.h
//  dish.fm
//
//  Created by Petr Prokop on 1/20/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SmartJumpingController.h"
#import "HJObjManager.h"
#import "HJManagedImageV.h"

@interface DraftItemController : NSObject<SmartJumpingDelegate>
{
    UILabel *_label;
    NSInteger _jumpIndex;
    HJObjManager *_objMan;
    UIImageView *_iv;
    UIImageView *_placeholderView;
    
    BOOL _withLabel;
    BOOL _labelIsCentral;
}

@property (readwrite, assign) NSInteger jumpIndex;
@property (nonatomic, retain) UIView *view;
@property (nonatomic, retain) NSArray *imagesArray;
@property (nonatomic, assign) id delegate;

@property (nonatomic) SEL delegateTapCallback;
@property (nonatomic) SEL delegateTapCallbackWithSender;

@property (nonatomic, retain) NSNumber *row;

- (id)init;

- (void)setJumpIndex:(NSInteger) index;
- (void)setJumpIndexWithNumber:(NSNumber *)index;

@end
