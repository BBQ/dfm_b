#define LOADING_VIEW_TAG 666666667

#import "ConvenientPopups.h"
#import <QuartzCore/QuartzCore.h> //for rounded corners
#import "Config.h"

static NSMutableArray  *_animatedElements;
static UIAlertView * alertView;

@implementation ConvenientPopups

@synthesize url;

+ (void)closePopup
{
	if(alertView != nil)
	{
		[alertView dismissWithClickedButtonIndex:0 animated:YES];
		[alertView release]; 
		alertView = nil;
	}
}

+ (void)showLoadingPopupWithTitle:(NSString *) title
{
	if(alertView != nil)
	{
		[ConvenientPopups closePopup];
	}
	
	alertView = [[UIAlertView alloc] initWithTitle:title message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
	UIActivityIndicatorView *activityIndicator=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
	[activityIndicator startAnimating];
	[activityIndicator setFrame:CGRectMake(125, 70, 36, 36)];
	[alertView addSubview:activityIndicator];
	[activityIndicator release];
	[alertView show];
}

+ (void)showAlertWithTitle:(NSString *) title 
				andMessage:(NSString *) message
{
    if(alertView != nil)
	{
		[ConvenientPopups closePopup];
	}
    
	UIAlertView *newAlertView = [[UIAlertView alloc] initWithTitle:title 
										   message:message 
										  delegate:self 
								 cancelButtonTitle:@"OK" 
								 otherButtonTitles:nil
				 ];
	
	[newAlertView show];
	[newAlertView release];
}

#define kRotatingArrowTag 369369
+ (void)showNonBlockingPopupOnView:(UIView *)aView
						  withText:(NSString *)aText
{
    
    
    if(_animatedElements == nil)
        _animatedElements = [[NSMutableArray alloc] init];
    
	static const CGFloat height = 70.0f;
    static const CGFloat width = 240.0f;
    static const CGFloat cornerRadius = 10.0f;
    
    __block UIView *loadingView = 
    [[UIView alloc] initWithFrame:CGRectMake((aView.bounds.size.width-width)/2, 
                                             140,//(aView.bounds.size.height-height)/2, 
                                             width, 
                                             height)];
	loadingView.tag = LOADING_VIEW_TAG;
    loadingView.layer.cornerRadius = cornerRadius;
	loadingView.backgroundColor = kDialogBeigeBGColor;
    
    UIImage *iconImage = [UIImage imageNamed:@"refreshArrow.png"];
	UIImageView *iconIV = [[UIImageView alloc] initWithImage:iconImage];
    iconIV.tag = kRotatingArrowTag;
    
    CGFloat iconOffset = (loadingView.frame.size.height - iconImage.size.height)/2.0f;
    iconIV.frame = CGRectMake(iconOffset, iconOffset, iconImage.size.width, iconImage.size.height);
    [loadingView addSubview:iconIV];
    
    // Adding animation
    CABasicAnimation* animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    animation.fromValue = [NSNumber numberWithFloat:0.0f];
    animation.toValue = [NSNumber numberWithFloat: 2*M_PI];
    animation.duration = 0.5f;
    animation.repeatCount = HUGE_VAL;
    [iconIV.layer addAnimation:animation forKey:@"MyAnimation"];
    [_animatedElements addObject:iconIV];
    [iconIV release];
    
    CGFloat labelOffset = iconOffset * 2 + iconImage.size.width;
    
	UILabel *loadingLabel = 
    [[UILabel alloc] initWithFrame:CGRectMake(labelOffset, 
                                              iconOffset, 
                                              width - labelOffset - iconOffset, 
                                              iconImage.size.height)];
    loadingLabel.numberOfLines = 0;
	loadingLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:12.0f];
	loadingLabel.text = aText;
	loadingLabel.textColor = kBrownTextColor;
    loadingLabel.shadowColor = [UIColor whiteColor];
    loadingLabel.shadowOffset = CGSizeMake(0, 1);
	loadingLabel.backgroundColor = [UIColor clearColor];
	[loadingView addSubview:loadingLabel];
    
    CGSize constraintSize = CGSizeMake(loadingLabel.frame.size.width, 120);
    CGFloat delta = [aText sizeWithFont:loadingLabel.font 
                      constrainedToSize:constraintSize 
                          lineBreakMode:loadingLabel.lineBreakMode].height - loadingLabel.frame.size.height;
    delta = MAX(delta, 0);
    CGRect frame;
    
    frame = loadingLabel.frame;
    frame.size.height += delta;
    loadingLabel.frame = frame;
    
    frame = loadingView.frame;
    frame.size.height += delta;
    loadingView.frame = frame;
    
    
	[loadingLabel release];
	
	[aView addSubview:loadingView];
}

// Old variant
/*
+ (void)showNonBlockingPopupOnView:(UIView *)aView
						  withText:(NSString *)aText
{
	UIView *loadingView = 
        [[UIView alloc] initWithFrame:CGRectMake((aView.bounds.size.width-240)/2, 
                                                 (aView.bounds.size.height-80)/2, 
                                                 240, 
                                                 80)];
	
    loadingView.layer.cornerRadius = 10;
	loadingView.tag = LOADING_VIEW_TAG;
	loadingView.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:0.7f];
	
	UIActivityIndicatorView *activityView = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(20, 30, 20, 20)];
	[activityView startAnimating];
	[loadingView addSubview:activityView];
	[activityView release];
	
	UILabel *loadingLabel = [[UILabel alloc] initWithFrame:CGRectMake(50, 30, 180, 20)];
    loadingLabel.numberOfLines = 0;
	loadingLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:12.0f];
	loadingLabel.text = aText;
	loadingLabel.textColor = [UIColor whiteColor];
	loadingLabel.backgroundColor = [UIColor clearColor];
	[loadingView addSubview:loadingLabel];
	[loadingLabel release];
	
	[aView addSubview:loadingView];
	[loadingView release];
}
*/

+ (void)centerPopupOnView:(UIView *)view
{
    UIView *loadingView = [view viewWithTag:LOADING_VIEW_TAG];
    loadingView.center = CGPointMake(view.frame.size.width/2, 
                                     view.frame.size.height/2);
}


+ (void)showNonBlockingPopupOnView:(UIView *)aView
						  withText:(NSString *)aText
                     shiftVertical:(CGFloat)shiftVertical
{
    [ConvenientPopups showNonBlockingPopupOnView:aView withText:aText];
    
    UIView *loadingView = [aView viewWithTag:LOADING_VIEW_TAG];
    CGRect frame = loadingView.frame;
    frame.origin.y += shiftVertical;
    loadingView.frame = frame;
}

+ (void)resetAnimations
{
    for(UIView *v in _animatedElements)
    {
        [v.layer removeAllAnimations]; 
        CABasicAnimation* animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
        animation.fromValue = [NSNumber numberWithFloat:0.0f];
        animation.toValue = [NSNumber numberWithFloat: 2*M_PI];
        animation.duration = 0.5f;
        animation.repeatCount = HUGE_VAL;
        [v.layer addAnimation:animation forKey:@"MyAnimation"];
    }
}

+ (void)closeNonBlockingPopupOnView:(UIView *)aView
{
    UIView *loadingView = [aView viewWithTag:LOADING_VIEW_TAG];
    UIView *animatedView = [loadingView viewWithTag:kRotatingArrowTag];
    [_animatedElements removeObject:animatedView];
	[loadingView removeFromSuperview];
}

+ (void)showToastLikeMessage:(NSString *)message
                      onView:(UIView *)aView
{
    static const CGFloat height = 70.0f;
    static const CGFloat width = 240.0f;
    static const CGFloat cornerRadius = 10.0f;
    
    __block UIView *blockerView = 
    [[UIView alloc] initWithFrame:CGRectMake(0, 
                                             0, 
                                             aView.bounds.size.width, 
                                             aView.bounds.size.height)];
    blockerView.backgroundColor = [UIColor blackColor];
    blockerView.alpha = 0.5f;
    [aView addSubview:blockerView];
    
    __block UIView *loadingView = 
    [[UIView alloc] initWithFrame:CGRectMake((aView.bounds.size.width-width)/2, 
                                             (aView.bounds.size.height-height)/2, 
                                             width, 
                                             height)];
	
    loadingView.layer.cornerRadius = cornerRadius;
	loadingView.backgroundColor = kDialogBeigeBGColor;

    UIImage *iconImage = [UIImage imageNamed:@"acceptIcon.png"];
	UIImageView *iconIV = [[UIImageView alloc] initWithImage:iconImage];
    
    CGFloat iconOffset = (loadingView.frame.size.height - iconImage.size.height)/2.0f;
    iconIV.frame = CGRectMake(iconOffset, iconOffset, iconImage.size.width, iconImage.size.height);
    [loadingView addSubview:iconIV];
    [iconIV release];
    
    CGFloat labelOffset = iconOffset * 2 + iconImage.size.width;
    
	UILabel *loadingLabel = 
    [[UILabel alloc] initWithFrame:CGRectMake(labelOffset, 
                                              iconOffset, 
                                              width - labelOffset - iconOffset, 
                                              iconImage.size.height)];
    loadingLabel.numberOfLines = 0;
	loadingLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:12.0f];
	loadingLabel.text = message;
	loadingLabel.textColor = kBrownTextColor;
    loadingLabel.shadowColor = [UIColor whiteColor];
    loadingLabel.shadowOffset = CGSizeMake(0, 1);
	loadingLabel.backgroundColor = [UIColor clearColor];
	[loadingView addSubview:loadingLabel];
    
    CGSize constraintSize = CGSizeMake(loadingLabel.frame.size.width, 120);
    CGFloat delta = [message sizeWithFont:loadingLabel.font 
                      constrainedToSize:constraintSize 
                          lineBreakMode:loadingLabel.lineBreakMode].height - loadingLabel.frame.size.height;
    delta = MAX(delta, 0);
    CGRect frame;
    
    frame = loadingLabel.frame;
    frame.size.height += delta;
    loadingLabel.frame = frame;
    
    frame = loadingView.frame;
    frame.size.height += delta;
    loadingView.frame = frame;
    
	[loadingLabel release];
	
	[aView addSubview:loadingView];
	
    
    [UIView animateWithDuration:1.0f 
                          delay:1.0f 
                        options:nil
                     animations:^{
                         loadingView.alpha = 0.0f;
                         blockerView.alpha = 0.0f;
                     } 
                     completion:^(BOOL finished) {
                         [loadingView removeFromSuperview];
                         [blockerView removeFromSuperview];
                         
                         [loadingView release];
                         [blockerView release];
                     }];
}


+ (void)showToastLikeMessage:(NSString *)message
                      onView:(UIView *)aView
                   imageName:(NSString *)imageName
               verticalShift:(CGFloat)verticalShift
{
    static const CGFloat height = 70.0f;
    static const CGFloat width = 240.0f;
    static const CGFloat cornerRadius = 10.0f;
    
    __block UIView *blockerView = 
    [[UIView alloc] initWithFrame:CGRectMake(0, 
                                             0, 
                                             aView.bounds.size.width, 
                                             aView.bounds.size.height)];
    blockerView.backgroundColor = [UIColor blackColor];
    blockerView.alpha = 0.5f;
    [aView addSubview:blockerView];
    
    __block UIView *loadingView = 
    [[UIView alloc] initWithFrame:CGRectMake((aView.bounds.size.width-width)/2, 
                                             (aView.bounds.size.height-height)/2 + verticalShift, 
                                             width, 
                                             height)];
	
    loadingView.layer.cornerRadius = cornerRadius;
	loadingView.backgroundColor = [UIColor colorWithRed:242/255.0f 
                                                  green:239/255.0f 
                                                   blue:234/255.0f 
                                                  alpha:1.0f];
    
    UIImage *iconImage = [UIImage imageNamed:imageName];
	UIImageView *iconIV = [[UIImageView alloc] initWithImage:iconImage];
    
    CGFloat iconOffset = (loadingView.frame.size.height - iconImage.size.height)/2.0f;
    iconIV.frame = CGRectMake(iconOffset, iconOffset, iconImage.size.width, iconImage.size.height);
    [loadingView addSubview:iconIV];
    [iconIV release];
    
    CGFloat labelOffset = iconOffset * 2 + iconImage.size.width;
    
	UILabel *loadingLabel = 
    [[UILabel alloc] initWithFrame:CGRectMake(labelOffset, 
                                              iconOffset, 
                                              width - labelOffset - iconOffset, 
                                              iconImage.size.height)];
    loadingLabel.numberOfLines = 0;
	loadingLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:12.0f];
	loadingLabel.text = message;
	loadingLabel.textColor = kBrownTextColor;
    loadingLabel.shadowColor = [UIColor whiteColor];
    loadingLabel.shadowOffset = CGSizeMake(0, 1);
	loadingLabel.backgroundColor = [UIColor clearColor];
	[loadingView addSubview:loadingLabel];
    
    CGSize constraintSize = CGSizeMake(loadingLabel.frame.size.width, 120);
    CGFloat delta = [message sizeWithFont:loadingLabel.font 
                        constrainedToSize:constraintSize 
                            lineBreakMode:loadingLabel.lineBreakMode].height - loadingLabel.frame.size.height;
    delta = MAX(delta, 0);
    CGRect frame;
    
    frame = loadingLabel.frame;
    frame.size.height += delta;
    loadingLabel.frame = frame;
    
    frame = loadingView.frame;
    frame.size.height += delta;
    loadingView.frame = frame;
    
	[loadingLabel release];
	
	[aView addSubview:loadingView];
	
    
    [UIView animateWithDuration:1.0f 
                          delay:1.0f 
                        options:nil
                     animations:^{
                         loadingView.alpha = 0.0f;
                         blockerView.alpha = 0.0f;
                     } 
                     completion:^(BOOL finished) {
                         [loadingView removeFromSuperview];
                         [blockerView removeFromSuperview];
                         
                         [loadingView release];
                         [blockerView release];
                     }];    
}

+ (void)showToastLikeMessage:(NSString *)message
                      onView:(UIView *)aView
                   imageName:(NSString *)imageName
{
    [ConvenientPopups showToastLikeMessage:message
                                    onView:aView
                                 imageName:imageName
                             verticalShift:0];
}

- (id)init
{
	self = [super init];
	
	if(self)
	{
		self.url = nil;
	}
	
	return self;
}

- (void)alertView: (UIAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
	if(self.url != nil)
		if(buttonIndex != 0)
			[[UIApplication sharedApplication] openURL:self.url];
}


//method shows alert with url
- (void)showAlertWithTitle:(NSString *) title 
				andMessage:(NSString *) message
{	
	UIAlertView *newAlertView = [[UIAlertView alloc] initWithTitle:title 
														   message:message 
														  delegate:self 
												 cancelButtonTitle:@"OK" 
												 otherButtonTitles:@"Перейти", nil
								 ];
	
	[newAlertView show];
	[newAlertView release];
}



@end
