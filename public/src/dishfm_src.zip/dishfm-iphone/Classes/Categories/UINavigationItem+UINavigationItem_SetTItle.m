//
//  UINavigationItem+UINavigationItem_SetTItle.m
//  dish.fm
//
//  Created by Petr Prokop on 2/9/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "UINavigationItem+UINavigationItem_SetTItle.h"

@implementation UINavigationItem (UINavigationItem_SetTItle)

- (void)setTitle:(NSString *)title
{
    static const CGFloat width = 160;
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, 44)];
    titleLabel.text = title;
    titleLabel.textColor = [UIColor colorWithRed:97.0/255 green:40.0/255 blue:15.0/255 alpha:1.0];
    titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:24.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.adjustsFontSizeToFitWidth = YES;
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.shadowOffset = CGSizeMake(0, 1);
    titleLabel.shadowColor = [UIColor whiteColor];
    
    CGSize titleConstraintSize = CGSizeMake(width, 100);
    CGSize actualTitleSize = [title sizeWithFont:[UIFont fontWithName:@"HelveticaNeue-Bold" size:14.0]
                               constrainedToSize:titleConstraintSize];
    
    
    if(actualTitleSize.height > 24.0f)
    {
        titleLabel.numberOfLines = 2;
        titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:14.0];
    }
    if(actualTitleSize.height > 28.0f)
    {
        titleLabel.numberOfLines = 3;
        titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:10.0];
    }
    
    self.titleView = titleLabel;
    
    CGRect frame = self.titleView.frame;
    frame.origin.x = (320 - frame.size.width)/2;
    self.titleView.frame = frame;
    
    [titleLabel release];
}

@end
