//
//  UINavigationItem+UINavigationItem_SetTItle.h
//  dish.fm
//
//  Created by Petr Prokop on 2/9/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationItem (UINavigationItem_SetTItle)

- (void)setTitle:(NSString *)title;

@end
