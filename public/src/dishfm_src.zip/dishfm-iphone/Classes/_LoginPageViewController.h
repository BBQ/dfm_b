//
//  LoginPageViewController.h
//  dish.fm
//
//  Created by Petr Prokop on 2/6/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface _LoginPageViewController : UIViewController
{
    IBOutletCollection(UIView) NSArray *_viewsToRound;
    IBOutletCollection(UIView) NSArray *_viewsToShadow;
}
- (IBAction)cancel:(id)sender;

- (IBAction)loginWithFacebook:(id)sender;
- (IBAction)loginWithTwitter:(id)sender;
- (IBAction)loginWithEmail:(id)sender;

@end
