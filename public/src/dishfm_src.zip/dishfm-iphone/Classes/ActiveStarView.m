//
//  ActiveStarView.m
//  dish.fm
//
//  Created by Petr Prokop on 1/5/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "ActiveStarView.h"
#import "StarView.h"

@implementation ActiveStarView

@synthesize onImage;
@synthesize offImage;
@synthesize halfImage;

@synthesize delegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) 
    {
        self.onImage = [UIImage imageNamed:@"starBig.png"];
        self.offImage = [UIImage imageNamed:@"starBigOff.png"];
        self.halfImage = [UIImage imageNamed:@"starBigHalf.png"];
        
        NSInteger spaceBetweenStars = (frame.size.width - self.onImage.size.width*5)/6 ;
        _imageViews = [[NSMutableArray alloc] initWithCapacity:5];
        
        for(NSInteger i=0; i<5; i++)
        {
            UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake((self.offImage.size.width + spaceBetweenStars)*i + spaceBetweenStars, 
                                                                            (frame.size.height - self.offImage.size.height)/2, 
                                                                            self.offImage.size.width, 
                                                                            self.offImage.size.height)];
            iv.image = self.offImage;
            [self addSubview:iv];
            [_imageViews addObject:iv];
            [iv release];
        }
    }
    return self;
}

- (void)dealloc
{
    [_imageViews release];
    [super dealloc];
}

- (void)updateRating:(NSNumber *)rating
{
    StarView *starView = [[StarView alloc] init];
    [starView updateStarSize:kBigStars];
    [starView updateRating:rating
                   inArray:_imageViews];
    [starView release];
}

- (void)handleTouchAtLocation:(CGPoint)touchLocation {

    for(int i = _imageViews.count - 1; i >= 0; i--) 
    {
        UIImageView *imageView = [_imageViews objectAtIndex:i];        

        if (CGRectContainsPoint(imageView.frame, touchLocation))
        {
            CGPoint relativePoint = [self convertPoint:touchLocation toView:imageView];
            
            if(relativePoint.x > imageView.frame.size.width/2)
                _rating = i + 1;
            else
                _rating = i + 0.5f;
            
            StarView *starView = [[StarView alloc] init];
            [starView updateStarSize:kBigStars];
            [starView updateRating:[NSNumber numberWithFloat:_rating]
                            inArray:_imageViews];
            [starView release];
            return;
        }
    }
    
    //touch is outside of star
    for(int i = _imageViews.count - 1; i >= 0; i--) 
    {
        UIImageView *imageView = [_imageViews objectAtIndex:i];        
        
        if (touchLocation.x >= imageView.frame.origin.x + imageView.frame.size.width)
        {
            _rating = i + 1;
            StarView *starView = [[StarView alloc] init];
            [starView updateStarSize:kBigStars];
            [starView updateRating:[NSNumber numberWithFloat:_rating]
                           inArray:_imageViews];
            [starView release];
            return;
        }
    }
    
    //touch to the left from first star
    _rating = 0.5f;
    StarView *starView = [[StarView alloc] init];
    [starView updateStarSize:kBigStars];
    [starView updateRating:[NSNumber numberWithFloat:_rating]
                   inArray:_imageViews];
    [starView release];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event 
{
    UITouch *touch = [touches anyObject];
    CGPoint touchLocation = [touch locationInView:self];
    [self handleTouchAtLocation:touchLocation];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event 
{
    UITouch *touch = [touches anyObject];
    CGPoint touchLocation = [touch locationInView:self];
    [self handleTouchAtLocation:touchLocation];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event 
{
    if(self.delegate)
        [self.delegate rateView:self ratingDidChange:(double)_rating];
}


@end
