//
//  AddCommentController.h
//  dish.fm
//
//  Created by Petr Prokop on 11/21/11.
//  Copyright (c) 2011 Dish.FM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FeedController.h"

@interface AddCommentController : UIViewController<UITextViewDelegate>
{
    NSInteger _reviewId;
    BOOL _isSendingComment;
}

@property (retain, nonatomic) IBOutlet UITextView *textView;
@property (retain, nonatomic) IBOutlet UILabel *charactersLeftCount;
@property (assign, nonatomic) FeedController *delegate;
//@property (retain, nonatomic) UIButton *parentButton;
@property (assign, readwrite) NSInteger row;

- (IBAction)sendComment:(id)sender;
- (IBAction)cancel:(id)sender;

- (id)initWithReviewId:(NSInteger) aReviewId;

@end
