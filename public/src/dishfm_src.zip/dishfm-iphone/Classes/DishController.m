#define kDishNameLabelTag 1000
#define kAddressTag 1001
#define kDistanceTag 1002
#define kLikesTag 1003
#define kCommentsTag 1004
#define kRestaurantNameTag 1005
#define kDishImageTag 1006
#define kAvatarTag 1007
#define kManagedAvatarTag 1008
#define kAtSymbolTag 1009
#define kHearthButtonTag 1010
#define kHearthActivityIndicatorTag 1011
#define kDishMiniatureTag 1012
#define kRestaurantMiniatureTag 1013
#define kManagedIVTag 2000
#define kPhotoButtonTag 2001
#define kCellBackgroundIVTag 10000
#define kQuickReviewStarsShift 6000
#define kBLockerVIewTag 789456456

#import "DishController.h"
#import <QuartzCore/QuartzCore.h>
#import "Config.h"
#import "Utils.h"
#import "ConvenientPopups.h"
#import "LoginController.h"
#import "AddCommentController.h"
#import "DataSource.h"
#import "RequestProcessor.h"
#import "LocationManager.h"
#import "CustomAnnotation.h"
//#import "RestaurantController.h"
#import "NewRestaurantController.h"
#import "MenuController.h"
#import "LoginController.h"
#import "Config.h"
#import "UserReviewsController.h"
#import "StarView.h"
#import "ProfileController.h"
#import "TellFriendController.h"
#import "FeedItemModel.h"
#import "Crittercism.h"
#import "GeneralMapController.h"
#import "SmartJumpingController.h"
#import "DishControllerSmartJumpingItem.h"
#import "LoggerController.h"

@implementation DishController
@synthesize yourReviewsView;
@synthesize yourReviewStars;
@synthesize yourReviewPhoto;
@synthesize yourReviewsText;
@synthesize allUserReviewsButton;
@synthesize quickReviewCommentView;
@synthesize quickReviewLabel;
@synthesize quickReviewText;
@synthesize quickReviewView;
@synthesize ratingRestaurantPosition;
@synthesize ratingRestaurantSubtitle;
@synthesize ratingTypePosition;
@synthesize ratingTypeSubtitle;

@synthesize ratingStars;
@synthesize restaurantRatingButton;
@synthesize categoryRatingButton;

@synthesize mapView;
@synthesize restaurantName;
@synthesize restaurantAddress;
@synthesize restaurantPhone;
@synthesize restaurantWorkingHours;
@synthesize restaurantButton;
@synthesize restaurantButton2;
@synthesize detailsPhotoPlaceholder;
@synthesize detailText;

@synthesize roundableViews;

@synthesize scrollViewContent;
@synthesize ratingLabel;
@synthesize reviewScrollView;
@synthesize pageControl;
@synthesize topExpertAvatarPlaceholder;
@synthesize topExpertName;
@synthesize reviewDishPhotoPlaceholder;

@synthesize reviewUsernameButton;
@synthesize reviewText;
@synthesize reviewStars;
@synthesize quickReviewStars;

@synthesize viewsToHide;

@synthesize scrollView,
            dishId,
            requestProcessor,
            dishInRP,
            dishName;

@synthesize currentReviewID;
@synthesize restaurants;
@synthesize isFound;

- (void)dealloc
{       
    [Crittercism leaveBreadcrumb:@"DishController dealloc"];
    
    self.mapView.delegate = nil;
    
    
    // Cancel requests
    [RequestProcessor cancelAllRequestsFromDelegate:self];
    
    if(self.requestProcessor)
        [self.requestProcessor cancelRequest];
        
    
    
    self.requestProcessor = nil;
    
    if(self.dishInRP)
        [self.dishInRP cancelRequest];
    
    self.dishInRP = nil;
    
    self.dishName = nil;
        
    [scrollViewContent release];
    [ratingLabel release];
    [reviewScrollView release];

    [topExpertAvatarPlaceholder release];
    [topExpertName release];
    [reviewDishPhotoPlaceholder release];
    [reviewUsernameButton release];
    [reviewText release];
    [detailsPhotoPlaceholder release];
    [detailText release];
    [restaurantName release];
    [restaurantAddress release];
    [restaurantPhone release];
    [restaurantWorkingHours release];
    [mapView release];
    [ratingRestaurantSubtitle release];
    [ratingRestaurantPosition release];
    [ratingTypePosition release];
    [ratingTypeSubtitle release];
    [pageControl release];
    [restaurantButton release];
    [restaurantRatingButton release];
    [categoryRatingButton release];
    [quickReviewView release];
    [quickReviewCommentView release];
    [quickReviewLabel release];
    [quickReviewText release];
    [yourReviewsView release];
    [yourReviewsText release];
    [allUserReviewsButton release];
    [yourReviewPhoto release];
    [restaurantButton2 release];
    [_readAllReviewsView release];
    [_dishNameLabel release];
    [_dishDescriptionLabel release];
    [_allLocationsButton release];
    [_cuteDotsPlaceholder release];
    [_addReviewWithPhotoButton release];
    [_detailsView release];
    [_reviewCommentsCountLabel release];
    [_reviewLikesCountLabel release];
    [_priceLabel release];
    [super dealloc];
}

- (id)init
{
    self = [super init];
    
    if(self)
    {
        self.requestProcessor = nil;
        self.dishInRP = nil;
        
        self.dishName = @"";
        
        _firstTimeReviewSet = YES;
        _isSendingReview = NO;
        
        _navBar = nil;
                
        _homeCooked = NO;
        
        self.isFound = NO;
    }
    
    return self;
}


//deprecated
- (id)initWithDishId:(NSInteger)aDishId
{
    self = [self init];
    
    if(self)
    {
        self.dishId = aDishId;
    }
    
    return self;
}

//deprecated
- (id)initWithDishId:(NSInteger)aDishId
          homeCooked:(BOOL)homeCooked
{
    self = [self init];
    
    if(self)
    {
        self.dishId = aDishId;
        _homeCooked = homeCooked;
    }
    
    return self;
}

- (id)initWithDishId:(NSInteger)aDishId
          type:(CheckinType)type
{
    self = [self init];
    
    if(self)
    {
        self.dishId = aDishId;
        _homeCooked = (type == kCheckInListTypeFriends);
        _type = type;
    }
    
    return self;
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [Crittercism leaveBreadcrumb:@"DishController viewDidLoad"];

    if(![LoginController isLoggedIn])
        [LoggerController logEvent:@"NR user clicked get_dish"];
    else
        [LoggerController logEvent:@"User clicked get_dish"];
    
    [[NSBundle mainBundle] loadNibNamed: @"QuickReviewView" owner:self options:nil];
    
    [[NSBundle mainBundle] loadNibNamed:@"_DishControllerContents" owner:self options:nil];
    [[NSBundle mainBundle] loadNibNamed:@"DishControllerNewReview" owner:self options:nil];
    
    _addReviewView.alpha = 0.0f;
    [self.reviewScrollView addSubview:_addReviewView];
    
    _activeStarView = [[ActiveStarView alloc] initWithFrame:CGRectMake(0,
                                                                       0,
                                                                       quickReviewView.frame.size.width, 
                                                                       quickReviewView.frame.size.height)];
    [quickReviewView addSubview:_activeStarView];
    _activeStarView.delegate = self;
    [_activeStarView release];
    
    self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 460-44-49)];
    self.scrollViewContent.alpha = 0.0f;
    [self.scrollView addSubview:self.scrollViewContent];
    self.scrollView.contentSize = CGSizeMake(self.scrollViewContent.frame.size.width, 
                                             self.scrollViewContent.frame.size.height);
    self.scrollView.scrollEnabled = YES;
    [self.view addSubview:self.scrollView];
    
    for(UIView *view in self.roundableViews)
    {
        view.layer.masksToBounds = YES;
        view.layer.cornerRadius = 3;
    }

    _cuteDotsController = [[CuteDotsController alloc] initWithFrame:CGRectMake(0, 
                                                                               0, 
                                                                               _cuteDotsPlaceholder.frame.size.width, 
                                                                               _cuteDotsPlaceholder.frame.size.height)];
    [_cuteDotsPlaceholder addSubview:_cuteDotsController.view];

    
    [ConvenientPopups showNonBlockingPopupOnView:self.view withText:@"Loading..."];
    
    CheckinType type;
    
    if(_homeCooked)
        type = kCheckInListTypeFriends;
    else
        type = _type;
    
    self.requestProcessor = [[RequestProcessor alloc] init];
    self.requestProcessor.delegate = self;
    [self.requestProcessor getDishById:self.dishId
                                  type:type
                               isFound:self.isFound];
    [self.requestProcessor release];
    
    
    if(_homeCooked)
    {
        for(UIView *view in _placeSpecificViews)
        {
            view.hidden = YES;
            
            [Utils moveUpViewsInView:self.scrollViewContent
                           belowView:view 
                               delta:view.frame.size.height];
            
            CGSize contentSize = self.scrollView.contentSize;
            contentSize.height -= view.frame.size.height;
            self.scrollView.contentSize = contentSize;
        }
    }
    
    //adding share button
    UIImage *shareButtonImage = [UIImage imageNamed:@"CancelBtn.png"];
    UIImage *shareButtonImageTap = [UIImage imageNamed:@"CancelBtnTap.png"];
    UIButton *shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
    shareButton.frame = CGRectMake(0, 0, shareButtonImage.size.width, shareButtonImage.size.height);
    [shareButton setTitle:@"Share" forState:UIControlStateNormal];
    shareButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0f];
    [shareButton setTitleColor:kBrownTextColor forState:UIControlStateNormal];
    [shareButton setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    [shareButton setTitleShadowColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [shareButton setTitleShadowColor:[UIColor clearColor] forState:UIControlStateHighlighted];
    shareButton.titleLabel.shadowOffset = CGSizeMake(0, 1);
    [shareButton setBackgroundImage:shareButtonImage forState:UIControlStateNormal];
    [shareButton setBackgroundImage:shareButtonImageTap forState:UIControlStateHighlighted];
    [shareButton addTarget:self action:@selector(shareReview:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithCustomView:shareButton] autorelease];
    
    if(self.title && [self.title isKindOfClass:[NSString class]] && ![self.title isEqualToString:@""])
        [self.navigationItem setTitle:self.title];
}

- (void)viewDidUnload 
{
    _firstTimeReviewSet = YES;
    
    [self setScrollViewContent:nil];
    [self setRatingLabel:nil];
    [self setReviewScrollView:nil];

    [self setTopExpertAvatarPlaceholder:nil];
    [self setTopExpertName:nil];
    [self setReviewDishPhotoPlaceholder:nil];

    [self setReviewUsernameButton:nil];
    [self setReviewText:nil];
    [self setDetailsPhotoPlaceholder:nil];
    [self setDetailText:nil];
    [self setRestaurantName:nil];
    [self setRestaurantAddress:nil];
    [self setRestaurantPhone:nil];
    [self setRestaurantWorkingHours:nil];
    [self setMapView:nil];
    [self setRatingRestaurantSubtitle:nil];
    [self setRatingRestaurantPosition:nil];
    [self setRatingTypePosition:nil];
    [self setRatingTypeSubtitle:nil];
    [self setPageControl:nil];
    [self setRestaurantButton:nil];
    [self setRestaurantRatingButton:nil];
    [self setCategoryRatingButton:nil];
    [self setQuickReviewView:nil];
    [self setQuickReviewCommentView:nil];
    [self setQuickReviewLabel:nil];
    [self setQuickReviewText:nil];
    [self setYourReviewsView:nil];
    [self setYourReviewsText:nil];
    [self setAllUserReviewsButton:nil];
    [self setYourReviewPhoto:nil];
    [self setRestaurantButton2:nil];
    [_readAllReviewsView release];
    _readAllReviewsView = nil;
    [_dishNameLabel release];
    _dishNameLabel = nil;
    [_dishDescriptionLabel release];
    _dishDescriptionLabel = nil;
    [_allLocationsButton release];
    _allLocationsButton = nil;
    [_cuteDotsPlaceholder release];
    _cuteDotsPlaceholder = nil;
    [_addReviewWithPhotoButton release];
    _addReviewWithPhotoButton = nil;
    [_detailsView release];
    _detailsView = nil;
    [_reviewCommentsCountLabel release];
    _reviewCommentsCountLabel = nil;
    [_reviewLikesCountLabel release];
    _reviewLikesCountLabel = nil;
    [_priceLabel release];
    _priceLabel = nil;
    [super viewDidUnload];
}

#pragma mark - Notification processing

- (void)userFavouritedDishFromController:(NSNotification *)notification
{
    if(notification.object == self)
        return;
    else
    {
        NSNumber *dID = [notification.userInfo objectForKey:@"dish_id"];
        
        if(self.dishId == [dID intValue])
        {
            _saveButton.selected = !_saveButton.selected;
        }
    }
}

#pragma mark - RequestProcessor delegate

-(void)requestProcessorSuccessCallback:(RequestProcessor *) requestProcessor
{	   
    if(requestProcessor == self.dishInRP)
    {
        self.dishInRP = nil;
        _isSendingReview = NO;
        
        [ConvenientPopups closeNonBlockingPopupOnView:self.view];
        
        [ConvenientPopups showAlertWithTitle:@"Yay!" 
                                  andMessage:@"Your review has been posted successfully! Unfortunately we do not show reviews without photo in our feed..."];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"quickReviewPosted" object:self];
        [[DataSource instance].tabBar.feedNavigationController popToRootViewControllerAnimated:NO];
        [[DataSource instance].tabBar changeTabToIndex:0];
        
        
        return;
    }
    else
    {
        self.scrollView.scrollEnabled = YES;
        
        

        _dishDetails = requestProcessor.processedJSON;
        [_dishDetails retain];
        
        /*
         Setting values
         */
        
        // Saved ribbon
        NSNumber *saved = [_dishDetails objectForKey:@"favourite"];
        if([saved isKindOfClass:[NSNumber class]] && [saved boolValue])
            _saveButton.selected = YES;
        
        //top expert
        NSDictionary *topExpert = [_dishDetails objectForKey:@"top_expert"];
        
        if([topExpert isKindOfClass:[NSDictionary class]])
        {
            topExpertName.text = [topExpert objectForKey:@"user_name"];
            
            HJManagedImageV *topExpertAvatar = [[HJManagedImageV alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
            topExpertAvatar.url = [NSURL URLWithString:[topExpert objectForKey:@"user_photo"]];
            [self.topExpertAvatarPlaceholder addSubview:topExpertAvatar];
            [topExpertAvatar setCallbackOnImageTap:self method:@selector(showUserProfile:)];
            [topExpertAvatar showLoadingWheel];
            [[DataSource instance].objMan manage:topExpertAvatar];
        }
        else
        {
            self.topExpertName.text = @"No expert";
            [self.topExpertAvatarPlaceholder removeFromSuperview];
        }
        

        
        /*
         Reviews
         */
        NSArray *reviews = [_dishDetails objectForKey:@"reviews"];
        
        
        //moving review w/o photo to the end
        /*
        NSMutableArray *reviewsToMove = [[NSMutableArray alloc] init];
        for(NSInteger i=0; i<[reviews count]; i++)
        {
            NSDictionary *review = [reviews objectAtIndex:i];
            
            if([[review objectForKey:@"image_hd"] isEqualToString:@""])
            {
                [reviewsToMove addObject:review];
            }
        }
        for(id review in reviewsToMove)
        {    
            [review retain];
            [reviews removeObject:review];
            [reviews insertObject:review atIndex:[reviews count]];
            [review release];
        }
        [reviewsToMove release];
        */
        
        _reviewsWithPhoto = [[NSMutableArray alloc] init];
        for(NSInteger i=0; i<[reviews count]; i++)
        {
            NSDictionary *review = [reviews objectAtIndex:i];
            
            if(![[review objectForKey:@"image_hd"] isEqualToString:@""] ||
               ![[review objectForKey:@"image_sd"] isEqualToString:@""]
            )
            {
                [_reviewsWithPhoto addObject:review];
            }
        }

        if([reviews count] > 0)
        {
            self.pageControl.numberOfPages = [_reviewsWithPhoto count]+1;
            if([_reviewsWithPhoto count])
            {
                [_cuteDotsController setNumberOfDots:[_reviewsWithPhoto count] andPhoto:YES];
            }
            
            /*
            self.reviewScrollView.contentSize = CGSizeMake(self.reviewScrollView.frame.size.width * (1 + [_reviewsWithPhoto count]), 
                                                           self.reviewScrollView.frame.size.height);
             */
        }
        else
        {
            for(UIView *currentView in self.viewsToHide)
            {
                currentView.hidden = YES;
            }
            
            [Utils moveDownViewsInView:self.scrollViewContent 
                             belowView:_readAllReviewsView 
                                 delta:-_readAllReviewsView.frame.size.height];
            
            CGSize currentSize = self.scrollView.contentSize;
            
            self.scrollView.contentSize = CGSizeMake(currentSize.width, 
                                                     currentSize.height - 2.7*_readAllReviewsView.frame.size.height);
        }
        
        _SJC = 
        [[SmartJumpingController alloc] initWithFrame:CGRectMake(0, 
                                                                 0, 
                                                                 _SJCPlaceholder.frame.size.width,
                                                                 _SJCPlaceholder.frame.size.height)];
        //SJC.view.tag = kSJCViewTag;
        _SJC.cuteDotsController = _cuteDotsController;
        _SJC.spaceBetweenItems = 0.0f;
        _SJC.itemSize = CGSizeMake(300, 387);
        [_SJCPlaceholder insertSubview:_SJC.view atIndex:0];
        _SJC.itemCount = [_reviewsWithPhoto count]+1;
        
        for(NSInteger i=0; i<=_SJC.itemCount-1; i++)
        {
            DishControllerSmartJumpingItem *dcsji = 
            [[DishControllerSmartJumpingItem alloc] init];
            dcsji.delegate = self;
            dcsji.itemDataArray = _reviewsWithPhoto;
            //dcsji.row = [NSNumber numberWithInt:row];
            
            dcsji.jumpIndex = i;
            
            
            [_SJC addItem:dcsji];
        }
        
        [_SJC alignItems];
        [_SJC setPagingEnabled:YES];
        
        //self.reviewScrollView.delegate = self;
        //self.reviewScrollView.pagingEnabled = YES;
        //[self updateReview:0];
        
        //dish details
        HJManagedImageV *dishPhoto = [[HJManagedImageV alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
        dishPhoto.url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@", [DataSource instance].imageBaseURL, [_dishDetails objectForKey:@"photo"]]];
        [self.detailsPhotoPlaceholder addSubview:dishPhoto];
        [dishPhoto showLoadingWheel];
        [[DataSource instance].objMan manage:dishPhoto];
        
        self.detailText.text = [_dishDetails objectForKey:@"description"];
        
        //restaurant
        if([[_dishDetails objectForKey:@"restaurant_name"] isKindOfClass:[NSString class]])
        {
            [self.restaurantButton setTitle:[_dishDetails objectForKey:@"restaurant_name"] 
                                   forState:UIControlStateNormal];
            [self.restaurantButton2 setTitle:[_dishDetails objectForKey:@"restaurant_name"] 
                                   forState:UIControlStateNormal];
        }
        else
        {
            [self.restaurantButton setTitle:@"Restaurant" 
                                   forState:UIControlStateNormal];
            [self.restaurantButton2 setTitle:@"Restaurant" 
                                   forState:UIControlStateNormal];
        }
        
        id restaurants = [_dishDetails objectForKey:@"restaurants"];
        
        CLLocation *userLocation = [[LocationManager instance] getLastLocation];
        
        float minDistance = FLT_MAX;
        
        _nearestRestaurant = nil;
        
        if(userLocation != nil)
        {
            if([restaurants isKindOfClass:[NSArray class]])
            {
                NSInteger restaurantsCount = [restaurants count];
                
                if(restaurantsCount > 1)
                {
                    [_allLocationsButton setTitle:[NSString stringWithFormat:@"All %i locations", restaurantsCount]
                                         forState:UIControlStateNormal];
                }
                else
                {
                    [_allLocationsButton setTitle:@"Show full screen map"
                                         forState:UIControlStateNormal];
                }
                
                CLLocation *nearestLocation = nil;
                
                for(NSDictionary *restaurant in restaurants)
                {
                    if([[restaurant objectForKey:@"lat"] isKindOfClass:[NSNumber class]] &&
                       [[restaurant objectForKey:@"lon"] isKindOfClass:[NSNumber class]]
                       )
                    {
                        CLLocation *currentLocation = 
                        [[CLLocation alloc] initWithLatitude:[[restaurant objectForKey:@"lat"] doubleValue] 
                                                   longitude:[[restaurant objectForKey:@"lon"] doubleValue]];
                        
                        float currentDistance = [Utils distanceFromLocation:currentLocation toLocation:userLocation];
                        if(currentDistance < minDistance)
                        {
                            minDistance = currentDistance;
                            _nearestRestaurant = restaurant;
                            
                            [nearestLocation release];
                            nearestLocation = currentLocation;
                            [nearestLocation retain];
                        }
                        
                        [currentLocation release];
                    }
                }
                
                CustomAnnotation *annotation = 
                [[CustomAnnotation alloc] initWithCoordinates:nearestLocation.coordinate
                                                        title:[_nearestRestaurant objectForKey:@"address"]
                                                     subtitle:@""];
                
                [self.mapView addAnnotations:[NSArray arrayWithObject:annotation]];
                
                MKCoordinateRegion regionToSet;
                //regionToSet = [Utils centerRegionForAnnotations:self.mapView.annotations];
                regionToSet = MKCoordinateRegionMake(nearestLocation.coordinate, MKCoordinateSpanMake(0.001f, 0.001f));
                [self.mapView setRegion:regionToSet animated:YES];
            }
        }
        else
        {
            if([restaurants isKindOfClass:[NSArray class]])
            {
                _nearestRestaurant = [restaurants objectAtIndex:0];
            }
            
            if([restaurants isKindOfClass:[NSArray class]])
            {
                NSInteger restaurantsCount = [restaurants count];
                
                if(restaurantsCount > 1)
                {
                    [_allLocationsButton setTitle:[NSString stringWithFormat:@"All %i locations", restaurantsCount]
                                         forState:UIControlStateNormal];
                }
                else
                {
                    [_allLocationsButton setTitle:@"Show full screen map"
                                         forState:UIControlStateNormal];
                }
                
                for(NSDictionary *restaurant in restaurants)
                {
                    if([[restaurant objectForKey:@"lat"] isKindOfClass:[NSNumber class]] &&
                       [[restaurant objectForKey:@"lon"] isKindOfClass:[NSNumber class]]
                       )
                    {
                        CLLocation *currentLocation = 
                        [[CLLocation alloc] initWithLatitude:[[restaurant objectForKey:@"lat"] doubleValue] 
                                                   longitude:[[restaurant objectForKey:@"lon"] doubleValue]];
                        
                        CustomAnnotation *annotation = 
                        [[CustomAnnotation alloc] initWithCoordinates:currentLocation.coordinate
                                                                title:[restaurant objectForKey:@"address"]
                                                             subtitle:@""];
                        
                        [self.mapView addAnnotations:[NSArray arrayWithObject:annotation]];
                    }
                }
                
                MKCoordinateRegion regionToSet;
                regionToSet = [Utils centerRegionForAnnotations:self.mapView.annotations];
                [self.mapView setRegion:regionToSet animated:YES];
            }
        }
        
        CGSize labelSize;
        
        if(_nearestRestaurant)
        {
            NSString *phoneString = [_nearestRestaurant objectForKey:@"phone"];
            if([phoneString isKindOfClass:[NSString class]])
                self.restaurantPhone.text = phoneString;
            else
                self.restaurantPhone.text = @"";
            
            NSString *addressString = [_nearestRestaurant objectForKey:@"address"];
            if([addressString isKindOfClass:[NSString class]])
                self.restaurantAddress.text = addressString;
            else
                self.restaurantAddress.text = @"";
            
            //working hours
            NSString *workingHoursString = [_nearestRestaurant objectForKey:@"working_hours"];
            if([workingHoursString isKindOfClass:[NSString class]])
                self.restaurantWorkingHours.text = workingHoursString;
            else
                self.restaurantWorkingHours.text = @"";
            
            labelSize = [self.restaurantWorkingHours.text sizeWithFont:self.restaurantWorkingHours.font 
                                                     constrainedToSize:CGSizeMake(self.restaurantWorkingHours.frame.size.width, 
                                                                                  self.restaurantWorkingHours.frame.size.height)];
            CGRect originalFrame = self.restaurantWorkingHours.frame;
            self.restaurantWorkingHours.frame = CGRectMake(originalFrame.origin.x,
                                                           originalFrame.origin.y,
                                                           labelSize.width, 
                                                           labelSize.height);
            
            
        }
        
        //rating
        float overallRating = [[_dishDetails objectForKey:@"rating"] floatValue];
        NSInteger votes = [[_dishDetails objectForKey:@"votes"] intValue];
        
        if(votes != 0)
        {
            self.ratingLabel.text = [NSString stringWithFormat:@"%.1f (%i votes)", overallRating, votes];
        }
        else
            self.ratingLabel.text = @"";
        
        StarView *starView = [[StarView alloc] init];
        [starView updateStarSize:kMediumStars];
        [starView updateRating:[NSNumber numberWithFloat:overallRating] 
                       inArray:self.ratingStars];
        [starView release];

        //old rating stuff
        /*
        self.ratingRestaurantPosition.text = [NSString stringWithFormat:@"#%@ in", [_dishDetails objectForKey:@"position_in_network"]];    
        
        if([[_dishDetails objectForKey:@"restaurant_name"] isKindOfClass:[NSString class]])
        {
            [self.restaurantRatingButton setTitle:[_dishDetails objectForKey:@"restaurant_name"] 
                                         forState:UIControlStateNormal];
        }
        else
        {
            [self.restaurantRatingButton setTitle:@"Restaurant" 
                                         forState:UIControlStateNormal];
        }
        
        NSString *typeName = [_dishDetails objectForKey:@"type_name"];
        
        
        if(![typeName isEqualToString:@"добавлено пользователем"])
        {
            self.ratingTypePosition.text = [NSString stringWithFormat:@"#%@ in", [_dishDetails objectForKey:@"position_in_type"]];
            
            [self.categoryRatingButton setTitle:typeName forState:UIControlStateNormal];
            
            self.ratingTypeSubtitle.text = [NSString stringWithFormat:@"%@ of %@", [_dishDetails objectForKey:@"position_in_type"], [_dishDetails objectForKey:@"dishes_in_type"]];
        }
        else
        {
            self.ratingTypePosition.text = [NSString stringWithFormat:@"#%@ in", [_dishDetails objectForKey:@"position_in_all"]];
            
            [self.categoryRatingButton setTitle:@"All" forState:UIControlStateNormal];
            
            self.ratingTypeSubtitle.text = [NSString stringWithFormat:@"%@ of %@", [_dishDetails objectForKey:@"position_in_all"], [_dishDetails objectForKey:@"dishes_count"]];
        }
            
        self.ratingRestaurantSubtitle.text = [NSString stringWithFormat:@"%@ of %@", [_dishDetails objectForKey:@"position_in_network"], [_dishDetails objectForKey:@"dishes_in_network"]];
        */
        
        
        _dishNameLabel.text = self.dishName = [_dishDetails objectForKey:@"name"];
        _dishDescriptionLabel.text = [_dishDetails objectForKey:@"description"];
        
        
        //now make all this stuff flexible
        CGSize constraintSize = CGSizeMake(_dishDescriptionLabel.frame.size.width,
                                           9999);
        CGSize newSize = [_dishDescriptionLabel.text sizeWithFont:_dishDescriptionLabel.font 
                                         constrainedToSize:constraintSize 
                                             lineBreakMode:_dishDescriptionLabel.lineBreakMode];
        
        CGFloat delta = - _dishDescriptionLabel.frame.size.height + newSize.height;
        
        [Utils moveDownViewsInView:_detailsView 
                       belowView:_dishDescriptionLabel 
                           delta:delta];
        
        [Utils moveDownViewsInView:self.scrollViewContent
                         belowView:_detailsView 
                             delta:delta];
        
        CGRect frame;
        
        frame = _dishDescriptionLabel.frame;
        frame.size.height += delta;
        _dishDescriptionLabel.frame = frame;
        
        frame = _detailsView.frame;
        frame.size.height += delta;
        _detailsView.frame = frame;
        
        self.scrollView.contentSize = CGSizeMake(self.scrollView.contentSize.width, 
                                                 self.scrollView.contentSize.height + delta);
        
        //navigation bar title
        NSString *titleString;
        
        if(_homeCooked)
            titleString = [NSString stringWithFormat:@"%@ (home-cooked)", self.dishName];
        else
            titleString = self.dishName;
        
        
        [self.navigationItem setTitle:titleString];
        //title - old
        /*
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
        titleLabel.text = titleString;
        titleLabel.textColor = [UIColor colorWithRed:97.0/255 green:40.0/255 blue:15.0/255 alpha:1.0];
        titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:24.0];
        titleLabel.minimumFontSize = 10;
        titleLabel.adjustsFontSizeToFitWidth = YES;
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.textAlignment = UITextAlignmentCenter;
        titleLabel.shadowOffset = CGSizeMake(0, 1);
        titleLabel.shadowColor = [UIColor whiteColor];
        
        CGSize titleConstraintSize = CGSizeMake(200, 100);
        CGSize actualTitleSize = [self.dishName sizeWithFont:[UIFont fontWithName:@"HelveticaNeue-Bold" size:14.0]
                                           constrainedToSize:titleConstraintSize];
        
        
        if(actualTitleSize.height > 14.0f)
        {
            titleLabel.numberOfLines = 2;
            titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:14.0];
        }
        if(actualTitleSize.height > 28.0f)
        {
            titleLabel.numberOfLines = 3;
            titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:10.0];
        }
        
        self.navigationItem.titleView = titleLabel;
        [titleLabel release];
        */
        
        //price
        NSNumber *price = [_dishDetails objectForKey:@"price"];
        NSString *currency = [_dishDetails objectForKey:@"currency"];
        
        if([currency isKindOfClass:[NSString class]] &&
           [price isKindOfClass:[NSNumber class]]
           )
        {
            _priceLabel.text = [NSString stringWithFormat:@"%@ %@", price, currency];
        }
        else
            _priceLabel.text = @"";
            
        [self updateUserReviews];
        
        for(UIView *view in _viewsWithShadow)
        {
            if(view.hidden || ![view superview])
                continue;
            
            UIView *shadow = [[UIView alloc] initWithFrame:view.frame];
            shadow.layer.cornerRadius = 3.0f;
            shadow.layer.shadowOffset = CGSizeMake(0, 1);
            shadow.layer.shadowRadius = 1;
            shadow.layer.shadowOpacity = 0.3;
            shadow.layer.shadowPath = [UIBezierPath bezierPathWithRect:shadow.bounds].CGPath;
            [self.scrollViewContent insertSubview:shadow atIndex:0];
            [shadow release];
        }
        
        /*
         end of setting values
         */

        self.requestProcessor = nil;
        
        [ConvenientPopups closeNonBlockingPopupOnView:self.view];
        
        [UIView beginAnimations:@"" context:nil];
        [UIView setAnimationDuration:0.7f];
        
        dlog(@"_reviewsWithPhoto %@", _reviewsWithPhoto);
        
        if(self.currentReviewID)
        {
            dlog(@"self.currentReviewID %@", self.currentReviewID);
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"review_id == %@", self.currentReviewID];
            
            NSArray *filteredArray = [_reviewsWithPhoto filteredArrayUsingPredicate:predicate];
            
            if([filteredArray count])
            {
                id item = [filteredArray objectAtIndex:0];
                NSInteger index = [_reviewsWithPhoto indexOfObject:item];
                [_SJC scrollToItemAtIndex:index animated:YES];
            }
        }
        
        self.scrollViewContent.alpha = 1.0f;
        
        [UIView commitAnimations];
    }
}

- (void)requestProcessorFailedCallback:(RequestProcessor *)requestProcessor
{
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    
    if(requestProcessor == self.dishInRP)
    {
        self.dishInRP = nil;
        _isSendingReview = NO;
    }
    else
    if(requestProcessor == self.requestProcessor)
        self.requestProcessor = nil;
}


- (void)shareReview:(UIButton *)button
{
    //NSArray *reviews = [_dishDetails objectForKey:@"reviews"];
    
    NSString *baseURL = [[DataSource instance].APIBaseURL stringByReplacingOccurrencesOfString:@"/api/" withString:@""];
    
    if(_SJC.currentPage >= 0 &&
       _SJC.currentPage < [_reviewsWithPhoto count])
    {
        // Share review not dish
        
        NSNumber *reviewId = [[_reviewsWithPhoto objectAtIndex:_SJC.currentPage] objectForKey:@"review_id"];
        BOOL selfReview = [[[_reviewsWithPhoto objectAtIndex:_SJC.currentPage] objectForKey:@"self_review"] boolValue];
        
        if(![reviewId isKindOfClass:[NSNumber class]])
            return;
        
        NSString *reviewURLString = 
        [NSString stringWithFormat:@"%@/reviews/%@", baseURL, reviewId];
        
        dlog(@"reviewURLString %@", reviewURLString);
        
        TellFriendController *tellFriendController = [[TellFriendController alloc] initWithParent:self 
                                                                                        andString:@"Yo! Check this out!"
                                                                                     andURLString:reviewURLString];
        
        tellFriendController.reviewID = reviewId;
        tellFriendController.isSelfReview = selfReview;
        
        //tellFriendController.pinterestURLString = [NSString stringWithFormat:@"%@/reviews/%@#pinme", baseURL, reviewId];
        [tellFriendController show];
    }
    else
    {
        NSNumber *reviewId = [[_reviewsWithPhoto objectAtIndex:0] objectForKey:@"review_id"];
        BOOL selfReview = [[[_reviewsWithPhoto objectAtIndex:0] objectForKey:@"self_review"] boolValue];
        
        if(![reviewId isKindOfClass:[NSNumber class]])
            return;
        
        NSString *reviewURLString = 
        [NSString stringWithFormat:@"%@/reviews/%@", baseURL, reviewId];
        
        dlog(@"reviewURLString %@", reviewURLString);
        
        TellFriendController *tellFriendController = [[TellFriendController alloc] initWithParent:self 
                                                                                        andString:@"Yo! Check this out!"
                                                                                     andURLString:reviewURLString];
        
        tellFriendController.reviewID = reviewId;
        tellFriendController.isSelfReview = selfReview;
        
        //tellFriendController.pinterestURLString = [NSString stringWithFormat:@"%@/reviews/%@#pinme", baseURL, reviewId];
        [tellFriendController show];
        
        /*
         // Old code - dish sharing
        NSString *reviewURLString = 
        [NSString stringWithFormat:@"%@/dishes/%i", baseURL, self.dishId];
        
        dlog(@"reviewURLString %@", reviewURLString);
        
        TellFriendController *tellFriendController = [[TellFriendController alloc] initWithParent:self 
                                                                                        andString:@"Yo! Check this out!"
                                                                                     andURLString:reviewURLString];
        tellFriendController.pinterestURLString = [NSString stringWithFormat:@"%@/dishes/%i#pinme", baseURL, self.dishId];
        [tellFriendController show];
         */
    }
}


- (NSArray *)userReviews
{
    NSArray *reviews = [_dishDetails objectForKey:@"reviews"];

    NSArray *userReviews = nil;
    
    if([LoginController instance].userInfo != nil && [[LoginController instance].userInfo objectForKey:@"system_user_id"] != nil)
    {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"user_id == %@", [[LoginController instance].userInfo objectForKey:@"system_user_id"]];
        
        userReviews = [reviews filteredArrayUsingPredicate:predicate];
        
        //dlog(@"userReviews %@", userReviews);
    }
    
    return userReviews;
}

- (void)updateUserReviews
{
    NSArray *userReviews = [self userReviews];
    
    if(userReviews && [userReviews count] > 0)
    {
        NSDictionary *userReview = [userReviews objectAtIndex:0];
        
        self.yourReviewsText.text = [userReview objectForKey:@"text"];
        
        NSString *reviewPhotoString = [userReview objectForKey:@"image_sd"];
        
        
        //photo
        if(![reviewPhotoString isEqualToString:@""])
        {
            HJManagedImageV *managedIV = [[HJManagedImageV alloc] initWithFrame:CGRectMake(0, 
                                                                                           0, 
                                                                                           self.yourReviewPhoto.frame.size.width, 
                                                                                           self.yourReviewPhoto.frame.size.height)];
            managedIV.url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@", [DataSource instance].imageBaseURL, reviewPhotoString]];
            [self.yourReviewPhoto addSubview:managedIV];
            [managedIV showLoadingWheel];
            [[DataSource instance].objMan manage:managedIV];
        }
        
        //rating
        float rating = [[userReview objectForKey:@"rating"] floatValue];
        
        StarView *starView = [[StarView alloc] init];
        [starView updateStarSize:kMediumStars];
        [starView updateRating:[NSNumber numberWithFloat:rating] 
                       inArray:self.yourReviewStars];
        [starView release];
        
        /*
        NSArray *sortedStars = [Utils sortViewsArrayByX:self.yourReviewStars];
        
        
        for(NSInteger i = 0; i < MIN([sortedStars count], rating); i++)
        {
            [[sortedStars objectAtIndex:i] setHighlighted:YES];
        }
         */
    }
    else
    {
        self.yourReviewsText.text = @"You haven't reviewed this dish yet!";
        
        for(UIImageView *image in self.yourReviewStars)
        {
            image.hidden = YES;
        }
        
        allUserReviewsButton.enabled = NO;
    }
}

#pragma mark -
#pragma mark Actions

- (IBAction)addReviewWithPhoto:(id)sender
{
    [LoggerController logEvent:@"User added a quick review in a dish"];
    [[DataSource instance] cleanNewReviewData];
    
    if(_homeCooked)
    {
        [DataSource instance].homeCookedPlace = @"Home";
        [DataSource instance].checkinType = kCheckInListTypeFriends;
    }
    else
    {
        [DataSource instance].restaurantName = [_dishDetails objectForKey:@"restaurant_name"];
        [DataSource instance].restaurantID = [_dishDetails objectForKey:@"restaurant_id"];
    }
    
    [DataSource instance].dishName = [_dishDetails objectForKey:@"name"];
    [DataSource instance].dishID = self.dishId;
    
    [[DataSource instance].tabBar addReviewWithPhoto];
}


- (void)rateView:(ActiveStarView *)view ratingDidChange:(double)rating
{
    if(_isSendingReview)
        return;
    
    
    if([self.quickReviewCommentView superview] == nil)
    {
        CGFloat width = self.quickReviewCommentView.frame.size.width;
        CGFloat height = self.quickReviewCommentView.frame.size.height;
        
        self.quickReviewCommentView.frame = CGRectMake((self.view.bounds.size.width - width)/2, 
                                                       (self.view.bounds.size.height - height)/2, 
                                                       width, 
                                                       height);
        
        self.quickReviewCommentView.layer.masksToBounds = YES;
        self.quickReviewCommentView.layer.cornerRadius = 3;
        self.quickReviewCommentView.alpha = 0.0f;
        
        [self.view addSubview:self.quickReviewCommentView];
    }   
    
    if([self.view viewWithTag:kBLockerVIewTag] == nil)
    {
        UIView *blocker = [[UIView alloc] initWithFrame:self.scrollViewContent.frame];
        blocker.backgroundColor = [UIColor blackColor];
        blocker.tag = kBLockerVIewTag;
        blocker.alpha = 0.0f;
        
        [self.scrollViewContent addSubview:blocker];
        self.scrollView.scrollEnabled = NO;
        [self.scrollViewContent bringSubviewToFront:self.quickReviewView];
        
        [blocker release];
        
        [UIView beginAnimations:@"" context:nil];
        [UIView setAnimationDuration:0.5f];
        
        CGRect rectToScroll = self.quickReviewView.frame;
        rectToScroll.origin.y -= 24.0f;
        rectToScroll.size.height = 367.0f;
        [self.scrollView scrollRectToVisible:rectToScroll animated:NO];
        
        blocker.alpha = 0.5f;
        self.quickReviewCommentView.alpha = 1.0f;
        
        [UIView commitAnimations];
    }
    
    //UIView *tappedStarButton = (UIView *)sender;

    
    //float ratingToSet = tappedStarButton.tag - 2000;
    
    //ratingToSet = (ratingToSet + 1)/2;
    

    //_rating = ratingToSet;
    
    _rating = rating;
    
    /*
    StarView *starView = [[StarView alloc] init];
    [starView updateStarSize:kBigStars];
    [starView updateRating:[NSNumber numberWithFloat:ratingToSet] 
                    onView:self.quickReviewView];
    [starView release];
     */
}

- (void)starTap:(id)sender
{    
    if(_isSendingReview)
        return;
    
    if([self.quickReviewCommentView superview] == nil)
    {
        
        
        CGFloat width = self.quickReviewCommentView.frame.size.width;
        CGFloat height = self.quickReviewCommentView.frame.size.height;
        
        self.quickReviewCommentView.frame = CGRectMake((self.view.bounds.size.width - width)/2, 
                                                       (self.view.bounds.size.height - height)/2, 
                                                       width, 
                                                       height);
        
        self.quickReviewCommentView.layer.masksToBounds = YES;
        self.quickReviewCommentView.layer.cornerRadius = 3;
        self.quickReviewCommentView.alpha = 0.0f;
        
        [self.view addSubview:self.quickReviewCommentView];
    }   
    
    if([self.view viewWithTag:kBLockerVIewTag] == nil)
    {
        UIView *blocker = [[UIView alloc] initWithFrame:self.scrollViewContent.frame];
        blocker.backgroundColor = [UIColor blackColor];
        blocker.tag = kBLockerVIewTag;
        blocker.alpha = 0.0f;
        
        [self.scrollViewContent addSubview:blocker];
        self.scrollView.scrollEnabled = NO;
        [self.scrollViewContent bringSubviewToFront:self.quickReviewView];
        
        [blocker release];
        
        [UIView beginAnimations:@"" context:nil];
        [UIView setAnimationDuration:0.5f];
        
        blocker.alpha = 0.5f;
        self.quickReviewCommentView.alpha = 1.0f;
        
        
        
        [UIView commitAnimations];
    }
    
    UIView *tappedStarButton = (UIView *)sender;
    
    //dlog(@"tappedStarButton.tag  %i", tappedStarButton.tag);
    
    float ratingToSet = tappedStarButton.tag - 2000;
    
    ratingToSet = (ratingToSet + 1)/2;
    
    //self.rating = ratingToSet;
    _rating = ratingToSet;
    
    //dlog(@"ratingToSet %f", ratingToSet);
    
    StarView *starView = [[StarView alloc] init];
    [starView updateStarSize:kBigStars];
    [starView updateRating:[NSNumber numberWithFloat:ratingToSet] 
                    onView:self.quickReviewView];
    [starView release];
}

- (void)closeQuickReview
{
    self.scrollView.scrollEnabled = YES;
    
    UIView *blocker = [self.view viewWithTag:kBLockerVIewTag];
    [UIView beginAnimations:@"" context:nil];
    [UIView setAnimationDuration:0.5f];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(yourAnimationHasFinished:finished:context:)];
    
    StarView *starView = [[StarView alloc] init];
    [starView updateStarSize:kBigStars];
    [starView updateRating:[NSNumber numberWithFloat:0.0f] 
                    onView:self.quickReviewView];
    [starView release];
    
    blocker.alpha = 0.0f;
    self.quickReviewCommentView.alpha = 0.0f;
    
    [UIView commitAnimations];
}

- (void)yourAnimationHasFinished:(NSString *)animationID finished:(BOOL)finished context:(void *)context
{
    UIView *blocker = [self.view viewWithTag:kBLockerVIewTag];
    [blocker removeFromSuperview];
}

- (IBAction)cancelQuickReview:(id)sender
{
    StarView *starView = [[StarView alloc] init];
    [starView updateStarSize:kBigStars];
    [starView cleanArray:_activeStarView.subviews];
    [starView release];
    
    /*
    for(UIView *star in self.quickReviewView.subviews)
    {
        if([star isKindOfClass:[UIImage class]])
            [(UIImageView *)star setSelected:NO];
        
    }
    */
    
    [self closeQuickReview];
}

- (IBAction)postQuickReview:(id)sender
{
    if(![[LoginController instance] isLoggedIn])
    {
        [[LoginController instance] login];
        return;
    }
    
    [self closeQuickReview];
    
    _isSendingReview = YES;
    
    [ConvenientPopups showNonBlockingPopupOnView:self.view withText:@"We're dishing in..."];
    
    //create a new UUID
	NSString *uuidString = [Utils newUUID];
    
    if(_homeCooked)
        [DataSource instance].checkinType = kCheckInListTypeFriends;
    
    self.dishInRP = [[RequestProcessor alloc] init];
    self.dishInRP.delegate = self;
    [self.dishInRP addReviewForUUID:uuidString
                       restaurantId:[[_dishDetails objectForKey:@"restaurant_id"] intValue]
                   foursqareVenueID:nil
                         reviewText:self.quickReviewText.text
                       reviewRating:[NSNumber numberWithFloat:_rating] 
                     postOnFacebook:NO
                      postOnTwitter:YES
                             dishId:self.dishId];
    [self.dishInRP release];
}

/*
- (void)updateReview:(NSInteger)reviewIndex
{
    static NSMutableDictionary *originalXPositions;
    NSArray *reviews = _reviewsWithPhoto;//[_dishDetails objectForKey:@"reviews"];
    
    if(reviewIndex == [reviews count])
    {
        for(UIView *view in self.reviewScrollView.subviews)
        {
            if(view != _addReviewView)
                view.hidden = YES;
        }
        
        [UIView beginAnimations:@"_addReviewView appears" context:nil];
        [UIView setAnimationDuration:0.3f];
        
        _addReviewView.alpha = 1.0f;
        
        [UIView commitAnimations];
        
        //return;
    }
    else
    {
        if(_addReviewView.alpha != 0.0f)
        {
            for(UIView *view in self.reviewScrollView.subviews)
            {
                if(view != _addReviewView)
                    view.hidden = NO;
            }
            
            [UIView beginAnimations:@"_addReviewView disappears" context:nil];
            [UIView setAnimationDuration:0.3f];
            
            _addReviewView.alpha = 0.0f;
            
            [UIView commitAnimations];
        }
        
        NSDictionary *review = [reviews objectAtIndex:reviewIndex];
        
        dlog(@"review %@", review);
        
        //avatar
        [_reviewAvatar clear];
        //NSString *avatarURLString = [Utils getFacebookAvatarURLStringByID:[[review objectForKey:@"user_facebook_id"] stringValue]];
        
        NSString *avatarURLString = [review objectForKey:@"user_photo"];
        _reviewAvatar.url = [NSURL URLWithString:avatarURLString];
        [_reviewAvatar showLoadingWheel];
        [[DataSource instance].objMan manage:_reviewAvatar];
        
        NSString *photoString = @"";
        
        if([Utils isRetinaDisplay])
            photoString = [review objectForKey:@"image_hd"];
        else
            photoString = [review objectForKey:@"image_sd"];
        
        
        //photo
        [_reviewPhoto clear];
        
        if(![photoString isEqualToString:@""])
        {
            NSString *photoURLString = [NSString stringWithFormat:@"%@%@", [DataSource instance].imageBaseURL, photoString];
            
            _reviewPhoto.url = [NSURL URLWithString:photoURLString];
            
            [_reviewPhoto showLoadingWheel];
            [[DataSource instance].objMan manage:_reviewPhoto];
        }
        
        //username
        [self.reviewUsernameButton setTitle:[review objectForKey:@"user_name"] 
                                   forState:UIControlStateNormal];
        
        //text
        self.reviewText.text = [review objectForKey:@"text"];
        
        CGSize constraintSize = CGSizeMake(self.reviewText.frame.size.width, 
                                           32.0f);
        CGSize actualSize = [self.reviewText.text sizeWithFont:self.reviewText.font 
                                             constrainedToSize:constraintSize];
        CGRect frame = self.reviewText.frame;
        frame.size.height = actualSize.height;
        self.reviewText.frame = frame;
        
        if(_firstTimeReviewSet)
        {
            _firstTimeReviewSet = NO;
            
            originalXPositions = [[NSMutableDictionary alloc] init];
            
            for(UIView *view in [self.reviewScrollView subviews])
            {
                [originalXPositions setObject:[NSNumber numberWithFloat:view.frame.origin.x ] forKey:[NSValue valueWithNonretainedObject:view]];
            }
        }

        float rating = [[review objectForKey:@"review_rating"] floatValue];
        
        StarView *starView = [[StarView alloc] init];
        [starView updateRating:[NSNumber numberWithFloat:rating] 
                       inArray:self.reviewStars];
        [starView release];
        
        //counts
        _reviewLikesCountLabel.text = [[review objectForKey:@"likes"] stringValue];
        _reviewCommentsCountLabel.text = [[review objectForKey:@"comments"] stringValue];
    }
    
    NSInteger shift = self.pageControl.currentPage - _previousPage;

    
    for(UIView *view in [self.reviewScrollView subviews])
    {
        view.frame = 
        CGRectMake([[originalXPositions objectForKey:[NSValue valueWithNonretainedObject:view]] floatValue] + 
                   self.reviewScrollView.frame.size.width * (reviewIndex + shift), 
                   view.frame.origin.y, 
                   view.frame.size.width, 
                   view.frame.size.height);
    }
    
    [UIView beginAnimations:@"" context:nil];
    [UIView setAnimationDuration:0.2f];
    
    for(UIView *view in [self.reviewScrollView subviews])
    {
        view.frame = 
        CGRectMake([[originalXPositions objectForKey:[NSValue valueWithNonretainedObject:view]] floatValue] + 
                   self.reviewScrollView.frame.size.width * reviewIndex, 
                   view.frame.origin.y, 
                   view.frame.size.width, 
                   view.frame.size.height);
    }
    
    [UIView commitAnimations];
}
*/

- (IBAction)restaurantClick:(id)sender
{
    NSInteger restaurantID = [[_dishDetails objectForKey:@"restaurant_id"] intValue];
    
    RestaurantModel *rm = [[RestaurantModel alloc] init];
    rm.restaurantId = restaurantID;
    rm.type = _type;
    
    NewRestaurantController *restaurantController = [[NewRestaurantController alloc] initWithRestaurant:rm];
    [self.navigationController pushViewController:restaurantController animated:YES];
    [restaurantController release];
}

/*
- (IBAction)restaurantPositionClick:(id)sender
{
    MenuController *menuController = [[MenuController alloc] initWithRestaurantId:[[_dishDetails objectForKey:@"restaurant_id"] intValue]];
    
    [self.navigationController pushViewController:menuController animated:YES];
    [menuController release];
}
*/

- (IBAction)showOnMap:(id)sender
{
    /*
    NSMutableArray *restaurants = [[NSMutableArray alloc] init];

    for(NSDictionary *currentRestaurant in [_dishDetails objectForKey:@"restaurants"])
    {
        RestaurantModel *restaurant = [[RestaurantModel alloc] initWithDictionary:currentRestaurant];
        
        [restaurants addObject:restaurant];
        
        [restaurant release];
    }

    MapForRestaurants *mapForRestaurants = [[MapForRestaurants alloc] initWithRestaurants:restaurants];
    [restaurants release];
    [self.navigationController pushViewController:mapForRestaurants animated:YES];
    [mapForRestaurants release];
     */
    
    GeneralMapController *mapC = [[GeneralMapController alloc] init];
    
    if(self.restaurants == nil)
        self.restaurants = [[NSMutableArray alloc] init];
    else
        [self.restaurants removeAllObjects];
    

    {
        NSArray *restaurants = [_dishDetails objectForKey:@"restaurants"];
        
        if([restaurants isKindOfClass:[NSArray class]])
            for(NSMutableDictionary *currentRestaurant in restaurants)
            {
                if(currentRestaurant == _nearestRestaurant)
                {
                    mapC.objectIndex = [self.restaurants count];
                    dlog(@"currentRestaurant %@", currentRestaurant);
                }
                
                [currentRestaurant setObject:[_dishDetails objectForKey:@"restaurant_name"] forKey:@"name"];
                RestaurantModel *restaurant = [[RestaurantModel alloc] initWithDictionary:currentRestaurant];
                [self.restaurants addObject:restaurant];
                [restaurant release];
                
            }
    }
    
    mapC.delegate = self;

    [mapC.mapAnnotations removeAllObjects];
    [mapC delegateFinishedUpdating];
    
    for(RestaurantModel *currentRestaurant in self.restaurants)
    {		
        if(currentRestaurant.location != nil)
        {
            
            NSString *title = [NSString stringWithFormat:@"#%i(%.1f) %@", [self.restaurants indexOfObject:currentRestaurant]+1,
                               currentRestaurant.rating,
                               currentRestaurant.name];
            NSString *subtitle = [NSString stringWithFormat:@" %@", currentRestaurant.address];
            
            if(title == nil)
                title = @"";
            
            if(subtitle == nil)
                subtitle = @"";
            
            CustomAnnotation *annotation = 
            [[CustomAnnotation alloc] initWithCoordinates:currentRestaurant.location.coordinate
                                                    title:title
                                                 subtitle:subtitle];
            
            annotation.tag = [self.restaurants indexOfObject:currentRestaurant];
            [mapC.mapAnnotations addObject:annotation];
            [annotation release];   
        }
    }
    
    
    [self.navigationController pushViewController:mapC animated:YES];
    [mapC release];
}

- (IBAction)showDishesInCategory:(id)sender
{
    
}

- (IBAction)showUserReviews:(id)sender
{
    UserReviewsController *userReviewsController = [[UserReviewsController alloc] initWithReviews:[self userReviews]];
    [self.navigationController pushViewController:userReviewsController animated:YES];
    [userReviewsController release];
}

- (IBAction)showAllReviews:(id)sender
{
    [LoggerController logEvent:@"User clicked all reivews in a dish"];
    
    FeedController *feedController = [[FeedController alloc] initWithReviews:[_dishDetails objectForKey:@"reviews"]];
    feedController.userCanClickOnPhoto = NO;
    
    if(_homeCooked)
        feedController.title = [NSString stringWithFormat:@"%@ (home-cooked)", [_dishDetails objectForKey:@"name"]];
    else
        feedController.title = [NSString stringWithFormat:@"%@ @ %@", [_dishDetails objectForKey:@"name"], 
                                [_dishDetails objectForKey:@"restaurant_name"]];
    
    [self.navigationController pushViewController:feedController animated:YES];
    [feedController release];
}

- (void)showReview:(NSInteger)objectIndex
{
    NSDictionary *dictionary = [_reviewsWithPhoto objectAtIndex:objectIndex];
    
    FeedController *feedController;
    
    if([[dictionary objectForKey:@"self_review"] boolValue])
    {
        NSArray *reviewArray = [NSArray arrayWithObject:dictionary];
        feedController = [[FeedController alloc] initWithReviews:reviewArray];
        feedController.isOneReviewMode = YES;
    }
    else
        feedController = [[FeedController alloc] initWithReviewID:[dictionary objectForKey:@"review_id"]];
    
    /*
    feedController.title = [NSString stringWithFormat:@"%@ @ %@", [_dishDetails objectForKey:@"name"], 
                            [_dishDetails objectForKey:@"restaurant_name"]];
    */
    feedController.userCanClickOnPhoto = NO;
    [self.navigationController pushViewController:feedController animated:YES];
    [feedController release];
}

- (IBAction)showUserProfile:(id)sender
{
    NSDictionary *topExpert = [_dishDetails objectForKey:@"top_expert"];
    
    if([topExpert isKindOfClass:[NSDictionary class]])
    {
        ProfileController *profileController = [[ProfileController alloc] init];
        profileController.userSystemID = [topExpert objectForKey:@"user_id"];
        profileController.userName = [topExpert objectForKey:@"user_name"];
        profileController.userAvatarURLString = [topExpert objectForKey:@"user_photo"];
        [self.navigationController pushViewController:profileController animated:YES];
        [profileController release];
    }
}

- (void)showReviewUserProfile:(NSInteger)objectIndex
{
    NSDictionary *topExpert = [_reviewsWithPhoto objectAtIndex:objectIndex];
    
    ProfileController *profileController = [[ProfileController alloc] init];
    profileController.userSystemID = [topExpert objectForKey:@"user_id"];
    profileController.userName = [topExpert objectForKey:@"user_name"];
    profileController.userAvatarURLString = [topExpert objectForKey:@"user_photo"];
    [self.navigationController pushViewController:profileController animated:YES];
    [profileController release];
}

- (IBAction)addToFavourites:(id) sender
{    
    if(![[LoginController instance] isLoggedIn])
    {
        [LoggerController logEvent:@"NR user clicked save to favourites"];
        
        [[LoginController instance] login];
        return;
    }
    
    [LoggerController logEvent:@"User clicked save to favourites"];
    
    UIButton *currentButton = (UIButton *)sender;
    
    CheckinType type;
    
    if(_homeCooked)
        type = kCheckInListTypeFriends;
    else
        type = _type;

    
    // TODO: add fail callback
    RequestProcessor *rp = [RequestProcessor saveDishToFavourites:self.dishId type:type];
    [rp startRequest];
    
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"userFavouritedDishFromController" 
                                                        object:self 
                                                      userInfo:[NSDictionary dictionaryWithObject:[NSNumber numberWithInt:self.dishId] 
                                                                                           forKey:@"dish_id"]];

    currentButton.selected = !currentButton.selected;
}

#pragma mark -
#pragma mark UITextViewDelegate

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range 
 replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"]) 
    {
        [textView resignFirstResponder];
        
        return NO;
    }
    
    return YES;
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    self.quickReviewLabel.hidden = YES;
    
    return YES;
}

#pragma mark -
#pragma mark MKMapViewDelegate

static const NSInteger kPinImageTag = 565656;
static const NSInteger kLabelTag = 323232;

- (MKAnnotationView *)mapView:(MKMapView *)theMapView viewForAnnotation:(CustomAnnotation *)annotation
{	
    //if it's the user location, just return nil.
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
    
    static NSString *annotationViewID = @"RestaurantPin";
    
    MKAnnotationView *annotationView = (MKAnnotationView *)[self.mapView  dequeueReusableAnnotationViewWithIdentifier:annotationViewID];
    
    if (annotationView == nil)
    {
        MKPinAnnotationView *pin = [[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:annotationViewID] autorelease];
        
        pin.image = nil;
        UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mapPointer02.png"] 
                                            highlightedImage:[UIImage imageNamed:@"mapPointer05.png"]];
        
        [pin addSubview:iv];
        
        pin.centerOffset = CGPointMake(0, -pin.frame.size.height / 2);
        
        annotationView = pin;
        
        
        static const CGFloat labelSize = 16.0f;
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake((annotationView.frame.size.width-labelSize)/2-7, 
                                                                   8, 
                                                                   labelSize+6, 
                                                                   10.0)];
        label.backgroundColor = [UIColor clearColor];
        
        label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:8.0f];
        label.shadowColor = [UIColor whiteColor];
        label.shadowOffset = CGSizeMake(0, 1);
        label.tag = kLabelTag;
        label.textAlignment = UITextAlignmentCenter;
        [annotationView addSubview:label];
        [label release];
    }
    
    
    UILabel *label = (UILabel *)[annotationView viewWithTag:kLabelTag];
    
    annotationView.tag = annotation.tag;
    
    label.text = [NSString stringWithFormat:@"%i", annotation.tag + 1];
    label.textColor = kBlueTextColor;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    button.tag = annotation.tag;
    [button addTarget:self action:@selector(disclosureClick:) forControlEvents:UIControlEventTouchUpInside];
    annotationView.rightCalloutAccessoryView = button;
    
    return annotationView;
}

@end