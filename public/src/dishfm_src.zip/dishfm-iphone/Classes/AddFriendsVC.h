//
//  AddFriendsVC.h
//  dish.fm
//
//  Created by Petr Prokop on 3/5/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PullRefreshTableViewController.h"
#import "RequestProcessor.h"
#import "AddReviewController.h"

@interface AddFriendsVC : UIViewController<UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate>
{
    PullRefreshTableViewController *_TVC;
    UISearchBar *_searchBar;
    RequestProcessor *_requestProcessor;
    
    NSMutableArray *_currentFeedUsers;
    UITableViewCell *_cell;
    UIScrollView *_withWhomScrollView;
    UILabel *_withWhomLabel;
    
    NSMutableArray *_addedUsers;
    IBOutlet UITableViewCell *_bindTwitterCell;
}

@property (nonatomic, assign) AddReviewController *delegate;

- (IBAction)bindTwitterClicked:(id)sender;

@end
