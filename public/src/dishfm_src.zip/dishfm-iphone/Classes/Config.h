/*
 Notification names:
 
 currentUserInfoArrived - user is logged in - update likes and so on
 currentUserRelationsChanged - user followed or unfollowed someone
 appplicationBecameActiveWithPushNotification - open "news" window
 quickReviewPosted - change to "my" feed, scroll to top and update
 updateNotificationNumber - push notification arrived, update notification count
 userLikedReviewFromController
 updateDrafts
 updateLoadingReviews

 userFavouritedDishFromController
 userFavouritedRestaurantFromController
 
 Defaults keys:
    neverShowRateInAppStoreDialog
    askForLocationDialogIsShown
    askForPushTokenDialogIsShown
    isIntroShown
    askToBindSocialAccountsAfterEmailRegistrationDialogIsShown
 
 */

// If app is started this number of times - ask for rating
#define kNUmberOfApplicationStartsBeforeAskForRating 3

#define kNUmberOfApplicationStartsBeforeAskToShare 4

#define kRequestTimeout 180

#define kNavigationBarLogoTag 456456123
#define kGlobal_likesAvatarTagShift 258258
#define kGlobal_commentsAvatarTagShift 963963

#define kNewReviewTabBarIndex 2
#define kProfileTabBarIndex 4

#define kImageChachePathSuffix @"/Library/Caches/imgcache/dish.fm"
#define kSingletonImageChachePathSuffix @"/Library/Caches/imgcache/dish.fm-common"
#define kUploadPhotoSize CGSizeMake(600, 600)
#define kFeedItemsPerPage 25

// New York
#define kDefaultUserLocation [[[CLLocation alloc] initWithLatitude:40.764340 longitude:-73.977213] autorelease]

/*
 URLS
 */

#define URL_PREFIX @"http://dish.fm"

static NSString* const URL_SUPPORT = URL_PREFIX @"/support";
static NSString* const URL_TERMS = URL_PREFIX @"/about/terms/";
static NSString* const URL_PRIVACY = URL_PREFIX @"/about/privacy/";

/*
 colors
 */

#define kTintColor [UIColor colorWithRed:223.0/255 green:213.0/255 blue:200.0/255 alpha:1.0]
#define kDarkBrownTextColor [UIColor colorWithRed:54.0/255 green:36.0f/255 blue:18.0/255 alpha:1.0f]
#define kBrownTextColor [UIColor colorWithRed:115.0/255 green:90.0f/255 blue:75.0/255 alpha:1.0f]
#define kBlueTextColor [UIColor colorWithRed:66.0/255 green:142.0f/255 blue:165.0/255 alpha:1.0f]
#define kRedTextColor [UIColor colorWithRed:193/255.0 green:29/255.0 blue:17/255.0 alpha:1.0f]
#define kBeigeBGColor [UIColor colorWithRed:246.0/255 green:245.0f/255 blue:243.0/255 alpha:1.0f]
#define kDialogBeigeBGColor [UIColor colorWithRed:242/255.0f green:239/255.0f blue:234/255.0f alpha:1.0f]
#define kPlaceholderBGColor [UIColor colorWithRed:213/255.0f green:204/255.0f blue:184/255.0f alpha:1.0f]

/*
 metric
 */
#define kGlobalMetricDistanceOptions [NSArray arrayWithObjects:@"0.5", @"2", @"5", @"25", @"global", nil]
#define kMetricDistanceLabelText [NSArray arrayWithObjects:@"500 m", @"2 km", @"5 km", @"25 km", nil]

#define kMilesDistanceLabelText [NSArray arrayWithObjects:@"¼ mi", @"1 mi", @"5 mi", @"15 mi", nil]
#define kGlobalMilesDistanceOptions [NSArray arrayWithObjects:@"0.402", @"1.609", @"8.046", @"24.14", @"global", nil]

#define kMetersToMi 0.000621371192f

//restaurant options
#define kGlobalOptionsArray [NSArray arrayWithObjects:@"open_now", @"terrace", @"wifi", @"accept_bank_cards", nil]


/*
 server options
 */
#define DEVSERVER 1

#if DEVSERVER

static NSString* const kTestAPIBaseURL = @"http://dev.dish.fm/api/";
static NSString* const kTestImageBaseURL = @"http://dev.dish.fm";

#else

static NSString* const kTestAPIBaseURL = @"http://test.dish.fm/api/";
static NSString* const kTestImageBaseURL = @"http://test.dish.fm";

#endif

static NSString* const kProductionAPIBaseURL = @"http://dish.fm/api/";
static NSString* const kProductionImageBaseURL = @"http://dish.fm";


//emails
#define kSupportEmail @"support@dish.fm"

/*
 AppStore stuff
 */

#define kAppStoreID @"530449856"

//#define kAppStoreID @"488515478" // It's we <3 pics app store id
#define kItunesURL @"http://itunes.apple.com/app/id" kAppStoreID

/*
 3rd party stuff
 */

static NSString* const kFourSquareClientID = @"0JWDGVS0JRP4TTDORCLGXDTEHHIM5ENWZSNJMA11EYNCLR2C";
static NSString* const kFourSquareSecret = @"MB2DWZR0VLPM4M1M4XY5SJGGY3IJBCP0MRLNGHIVDBXLNZOD";


// Facebook
static NSString* kAppId = @"224070640979332";
//static NSString* kAppId = @"271752676215424"; //old one

static NSString* kTwitterOAuthConsumerKey = @"1DQYnbvFrRFfbmm0SU9IVg";
static NSString* kTwitterOAuthConsumerSecret = @"ixUaNcyUlAUUVc6KXKMWUZudqMWkVNbrbseYKckbjI";
