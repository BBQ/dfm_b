#import "AlertView.h"

@implementation AlertView

-(id)initWithTitle:(NSString*)title message:(NSString*)msg
{
    self = [super initWithTitle:title message:msg delegate:nil cancelButtonTitle:nil otherButtonTitles:nil];
    if( self )
    {
        self.delegate = self;
        buttonCallbackArray = [[NSMutableArray alloc] init];
    }
    return self;
}

-(void)dealloc
{
    [cancel release];
    [willPresent release];
    [didPresent release];
    [willDismiss release];
    [didDismiss release];
    [buttonCallbackArray release];
    [super dealloc];
}

-(void)addButtonWithTitle:(NSString*)title block:(void(^)(AlertView*, NSInteger))block
{
    [self addButtonWithTitle:title];
    [buttonCallbackArray addObject:block];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    ((void(^)(AlertView*, NSInteger))[buttonCallbackArray objectAtIndex:buttonIndex])((AlertView*)alertView, buttonIndex);
}

-(void)alertViewCancel:(UIAlertView *)alertView
{
    if( cancel )
    {
        cancel((AlertView*)alertView);
    }
    else
    {
        [self dismissWithClickedButtonIndex:self.cancelButtonIndex animated:NO];
    }
}

-(void)willPresentAlertView:(UIAlertView *)alertView
{
    if( willPresent )
        willPresent((AlertView*)alertView);
}

-(void)didPresentAlertView:(UIAlertView *)alertView
{
    if( didPresent )
        didPresent((AlertView*)alertView);
}

-(void)alertView:(UIAlertView *)alertView willDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if( willDismiss )
        willDismiss((AlertView*)alertView, buttonIndex);
}

-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if( didDismiss )
        didDismiss((AlertView*)alertView, buttonIndex);
}

-(void)setAlertViewCancelBlock:(void(^)(AlertView*))block
{
    [cancel release];
    cancel = [block retain];
}

-(void)setWillPresentAlertViewBlock:(void(^)(AlertView*))block
{
    [willPresent release];
    willPresent = [block retain];
}

-(void)setDidPresentAlertViewBlock:(void(^)(AlertView*))block
{
    [didPresent release];
    didPresent = [block retain];
}

-(void)setAlertViewWillDismissWithButtonIndexBlock:(void(^)(AlertView*, NSInteger))block
{
    [willDismiss release];
    willDismiss = [block retain];
}

-(void)setAlertViewDidDismissWithButtonIndexBlock:(void(^)(AlertView*, NSInteger))block
{
    [didDismiss release];
    didDismiss = [block retain];
}

@end