//
//  CustomNavigationController.h
//  dish.fm
//
//  Created by Petr Prokop on 11/14/11.
//  Copyright (c) 2011 Dish.FM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomNavigationController : UINavigationController

//- (void)setCustomTitle: (NSString *)title;

@end
