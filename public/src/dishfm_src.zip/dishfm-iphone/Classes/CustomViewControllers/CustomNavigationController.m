//
//  CustomNavigationController.m
//  dish.fm
//
//  Created by Petr Prokop on 11/14/11.
//  Copyright (c) 2011 Dish.FM. All rights reserved.
//

#import "CustomNavigationController.h"

@implementation CustomNavigationController

/*
- (void)setCustomTitle: (NSString *)title
{
    UIImageView *navBarBg = nil;
    UILabel *navBarLabel = nil;
    
    for(UIView *view in [self.navigationBar subviews])
    {
        dlog(@"view %@", view);
        
        if([view isKindOfClass:[UIImageView class]])
        {
            [self.navigationBar sendSubviewToBack:view];
            view.hidden = YES;
            navBarBg = (UIImageView *) view;
        }
        
        if([view isKindOfClass:[UILabel class]])
        {
            [self.navigationBar bringSubviewToFront:view];
            navBarLabel = (UILabel *)view;
        }
    }
    [self.view bringSubviewToFront:navBarLabel];
    [self.view sendSubviewToBack:navBarBg];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    titleLabel.text = title;
    titleLabel.textColor = [UIColor colorWithRed:97.0/255 green:40.0/255 blue:15.0/255 alpha:1.0];
    titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:24.0];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    self.navigationItem.title = title;
    self.navigationItem.titleView = titleLabel;
    
}

- (void)drawRect:(CGRect)rect {
    UIImage *image = [UIImage imageNamed: @"headerBg.png"];
    [image drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
}
*/

@end
