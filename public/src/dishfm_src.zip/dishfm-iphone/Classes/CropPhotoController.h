#import <UIKit/UIKit.h>

//new aviary headers
#import "AFPhotoEditorController.h"
#import "RestaurantListController.h"

@interface CropPhotoController : UIViewController<UIScrollViewDelegate, AFPhotoEditorControllerDelegate> 
{
    UIImage *_croppedImage;
    RestaurantListController *_restaurantListController;
    
    IBOutlet UIButton *_cancelButton;
    IBOutlet UIButton *_proceedButton;
    IBOutlet UIButton *_filtersdButton;
}

@property (nonatomic, retain) UIScrollView *scrollView;
@property (nonatomic, retain) UIImage *photo;
@property (nonatomic, retain) UIImageView *imageView;

@property (nonatomic, retain) UIImage *fullsizePhoto;

- (id)initWithPhoto:(UIImage *)aPhoto;
- (void)setImage:(UIImage *)anImage;
- (IBAction)submitPhoto;
- (IBAction)cancel:(id)sender;
- (IBAction)applyFilters:(id)sender;

@end
