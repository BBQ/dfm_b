#import <UIKit/UIKit.h>
#import "RestaurantModel.h"
#import "RequestProcessor.h"
#import "ActiveStarView.h"

@interface AddReviewController : UIViewController {
    IBOutlet UITextView *reviewTextField;
    IBOutlet UIView *_starViewPlaceholder;
    
    BOOL _isSendingReview;
    
    NSInteger _typeId;
    NSInteger _subtypeId;
    ActiveStarView *_activeStarView;
    
    float _rating;
    
    IBOutletCollection(UIImageView) NSArray *_viewsToShadow;
    BOOL _shareOnFacebook;
    BOOL _shareOnTwitter;
    BOOL _shareOnPinterest;
    
    BOOL _photoIsLoaded;
    BOOL _isDishInClicked;
    
    IBOutlet UIButton *_iamWithButton;
    IBOutlet UILabel *_friendsLabel;
    
    IBOutlet UIButton *_shareOnFacebookButton;
    IBOutlet UIButton *_shareOnTwitterButton;
    IBOutlet UIButton *_shareOnPinterestButton;
    
    IBOutlet UIButton *_dishInButton;
    IBOutlet UIButton *_saveToDraftsButton;
}

@property (nonatomic, retain) IBOutletCollection(UIView) NSArray *roundableViews;
@property (nonatomic, copy) NSString *uuid;
@property (nonatomic, retain) UIImage *photo;
@property (nonatomic, retain) RestaurantModel *restaurant;
@property (nonatomic, retain) NSDictionary *dish;
//@property (readwrite, assign) CGFloat rating;
@property (nonatomic, copy) NSString *dishName;
@property (nonatomic, retain) RequestProcessor *photoRP;
@property (nonatomic, retain) NSString *foursquareVenueID;
@property (nonatomic, retain) NSMutableArray *addedUsers;
@property (nonatomic, retain) NSMutableArray *currentUserFriends; 
@property (nonatomic, retain) NSMutableIndexSet *addedUsersIndexSet;

@property (readwrite, assign) BOOL isCheckInMode;
@property (nonatomic, retain) NSString *reviewText;
@property (nonatomic, retain) NSNumber *reviewRating;

- (id)initWithPhoto:(UIImage *)aPhoto
               UUID:(NSString *)anUUID;

- (void)updateDishWithName:(NSString *) aDishName
                    typeId:(NSInteger) aTypeId
                 subtypeId:(NSInteger) aSubtypeId;

- (void)updateFriends;

- (IBAction)saveReviewToDrafts;

- (IBAction)changeFacebookPosting:(UIButton *)sender;
- (IBAction)changeTwitterPosting:(UIButton *)sender;
- (IBAction)changePinterestPosting:(UIButton *)sender;

- (IBAction)chooseRestaurant;
- (IBAction)addFriendsClick:(id)sender;

@end
