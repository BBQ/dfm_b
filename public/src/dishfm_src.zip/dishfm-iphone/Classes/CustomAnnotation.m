#import "CustomAnnotation.h"

@implementation CustomAnnotation

@synthesize latitude;
@synthesize longitude;
@synthesize title;
@synthesize subtitle;
@synthesize deal;
@synthesize realTitle;
@synthesize realSubtitle;
@synthesize tag;

/*
NSString *title;
NSString *subtitle;
*/

- (CustomAnnotation *) initWithCoordinates:(CLLocationCoordinate2D) coordinates
							   title:(NSString *) initTitle
							subtitle:(NSString *) initSubtitle

{
	self = [super init];
	
	if(self)
	{
		self.latitude = coordinates.latitude;
		self.longitude = coordinates.longitude;
		self.title = initTitle;
		self.subtitle = initSubtitle;
        
        self.realTitle = @"";
        self.realSubtitle = @"";
	}
	
	return self;
}

- (CLLocationCoordinate2D)coordinate;
{
    CLLocationCoordinate2D theCoordinate;
    theCoordinate.latitude = self.latitude;
    theCoordinate.longitude = self.longitude;

    return theCoordinate; 
}

- (void)dealloc
{
    [super dealloc];
}

@end