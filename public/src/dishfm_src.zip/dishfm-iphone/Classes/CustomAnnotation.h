#import <MapKit/MapKit.h>

@interface CustomAnnotation : NSObject <MKAnnotation>
{
	
}

@property (readwrite, assign) float latitude;
@property (readwrite, assign) float longitude;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
@property (nonatomic, retain) id deal;
@property (nonatomic, retain) NSString *realTitle;
@property (nonatomic, retain) NSString *realSubtitle;

@property (readwrite, assign) NSInteger tag;

- (CustomAnnotation *) initWithCoordinates:(CLLocationCoordinate2D) coordinates
                                     title:(NSString *) initTitle
                                  subtitle:(NSString *) initSubtitle;

@end