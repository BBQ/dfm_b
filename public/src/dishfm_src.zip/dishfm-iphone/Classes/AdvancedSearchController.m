#define kFistRangeLabelTag 2001
#define kRangeOptionsCount 5
#define kRangeButtonLabelShift 1000
//#define kRefineSearchShift 280.0f
#define kRefineSearchShift 320.0f

#define kPlaceSearchShift 50.0f
//#define kHeaderViewShift 285.0f
#define kHeaderViewShift 325.0f

#define kDistanceOptions [NSArray arrayWithObjects:@"500 m", @"2 km", @"5 km", @"City", @"Globally", nil]
#define kPriceRangeOptions [NSArray arrayWithObjects:@"p1", @"p2", @"p3", @"p4", @"p5", nil]
#define kPriceRangeButtonShift 4000
#define kOptionTagsShift 6000

#import "AdvancedSearchController.h"
#import "DataSource.h"
#import "Config.h"
#import "Utils.h"

@implementation AdvancedSearchController

@synthesize headerView;
@synthesize selectRangeBullet;
@synthesize refineSearchView;
@synthesize refineSearchBackground;
@synthesize refineSearchButton;
@synthesize searchField;
@synthesize locationField;
@synthesize searchView;
@synthesize placeView;

@synthesize delegate, 
            priceRanges;
@synthesize restaurantMode;


- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) 
    {
        _refineSearchIsOpen = NO;
        _rangeOptionChanged = NO;
        _currentRangeOption = 0;
        _tips = [DataSource instance].searchTips;
        _sortingString = @"rating";
        _options = [[NSMutableArray alloc] initWithCapacity:4];
        //self.priceRanges = [[NSMutableArray alloc] initWithCapacity:5];
        self.priceRanges = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithInt:0],
                            [NSNumber numberWithInt:0], 
                            [NSNumber numberWithInt:0], 
                            [NSNumber numberWithInt:0], 
                            [NSNumber numberWithInt:0], 
                            nil];
        self.restaurantMode = NO;
        [self.priceRanges release];
    }
    return self;
}

- (void)dealloc {
    [selectRangeBullet release];
    [refineSearchView release];
    [refineSearchBackground release];
    [refineSearchButton release];
    [searchField release];
    [locationField release];
    [searchView release];
    [placeView release];
    
    self.priceRanges = nil;
    
    [_sortByRatingButton release];
    [_sortByDistanceButton release];
    [_restaurantSpecificViews release];
    [_options release];
    [_topSearchButton release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

    [[NSBundle mainBundle] loadNibNamed:@"RestaurantSearch" owner:self options:nil];
    
    [headerView setAutoresizingMask:UIViewAutoresizingNone];
    CGRect headerViewOriginalFrame = headerView.frame;
    headerView.frame = CGRectMake(headerViewOriginalFrame.origin.x, 
                                  headerViewOriginalFrame.origin.y, 
                                  headerViewOriginalFrame.size.width, 
                                  headerViewOriginalFrame.size.height - kHeaderViewShift);
    
    
    self.tableView.tableHeaderView = headerView;
    self.tableView.tableFooterView = [UIView new];
    self.tableView.backgroundColor = [UIColor clearColor];
    
    self.tableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Background.png"]];
    
    
    /*
     setting values from parent controller
     */
    self.searchField.text = [self.delegate searchString];
    
    NSArray *distancesArray;
    
    if([Utils shouldUseMetricSystem])
    {
        distancesArray = kGlobalMetricDistanceOptions;
    }
    else
    {
        distancesArray = kGlobalMilesDistanceOptions;
    }
    
    _currentRangeOption = [distancesArray indexOfObject:[self.delegate distanceFilter]];
    
    for(NSInteger i=0; i<[[self.delegate priceRanges] count]; i++)
    {
        if([[[self.delegate priceRanges] objectAtIndex:i] boolValue])
        {
            NSInteger tag = i + kPriceRangeButtonShift;
            dlog(@"tag %i", tag);
            UIButton *button = (UIButton *)[self.view viewWithTag:tag];
            button.selected = YES;
        }
    }
    
    if([[self.delegate searchSorting] isEqualToString:@"distance"])
    {
        [self sortingClick:_sortByDistanceButton];
    }
    
    if(self.restaurantMode)
    {
        [self refineSearchButtonClick:nil];
        self.searchView.hidden = YES;
        self.placeView.frame = CGRectMake(5, 
                                          self.searchView.frame.origin.y, 
                                          310, 
                                          self.placeView.frame.size.height);
        
        for(UIView *view in _restaurantSpecificViews)
            view.hidden = NO;
        
        //setting restaurant options
        
        for(NSString *currentOption in [self.delegate options])
        {
            NSInteger tag = [kGlobalOptionsArray indexOfObject:currentOption] + kOptionTagsShift;
            [self optionClick:[self.view viewWithTag:tag]]; 
        }
    }
}

- (void)viewDidUnload
{
    [self setSelectRangeBullet:nil];
    [self setRefineSearchView:nil];
    [self setRefineSearchBackground:nil];
    [self setRefineSearchButton:nil];
    [self setSearchField:nil];
    [self setLocationField:nil];
    [self setSearchView:nil];
    [self setPlaceView:nil];
    [_sortByRatingButton release];
    _sortByRatingButton = nil;
    [_sortByDistanceButton release];
    _sortByDistanceButton = nil;
    [_restaurantSpecificViews release];
    _restaurantSpecificViews = nil;
    [_topSearchButton release];
    _topSearchButton = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if(!self.restaurantMode)
        [self.searchField becomeFirstResponder];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (void)setSearchString:(NSString *)aSearchString
{
    [aSearchString retain];
    [_searchString release];
    _searchString = aSearchString;
    [self.tableView reloadData];
}

- (NSArray *)currentTips
{
    //NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains[cd] %@", _searchString];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF BEGINSWITH[cd] %@", _searchString];
    
    NSArray *filteredArray = [_tips filteredArrayUsingPredicate:predicate];
    
    return filteredArray;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.searchField.isFirstResponder)
    if(_tips)
        return [[self currentTips] count];
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"TipCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    cell.textLabel.text = [[self currentTips] objectAtIndex:indexPath.row];
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *chosenWord = [[self currentTips] objectAtIndex:indexPath.row];
    
    /*
    if(self.delegate)
    {
        [self.delegate setSearchString:chosenWord];
        [self.delegate searchFromSearchBar];
    }
     */
    
    if(self.searchField.isFirstResponder)
    {
        self.searchField.text = chosenWord;
        [self.searchField resignFirstResponder];
    }
    
    [self.tableView reloadData];
}




#pragma mark -
#pragma mark Actions

- (IBAction)sortingClick:(id)sender
{
    UIButton *button = (UIButton *)sender;
    
    _sortByRatingButton.selected = NO;
    _sortByDistanceButton.selected = NO;
    
    button.selected = YES;
    
    if(_sortByDistanceButton.selected)
        _sortingString = @"distance";
    
    if(_sortByRatingButton.selected)
        _sortingString = @"rating";
}

- (IBAction)optionClick:(id)sender
{
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    
    NSInteger optionIndex = button.tag - kOptionTagsShift;
    
    NSString *currentOption = [kGlobalOptionsArray objectAtIndex:optionIndex];
    
    if(button.selected)
        [_options addObject:currentOption];
    else
        [_options removeObject:currentOption];
}

- (IBAction)priceRangeClick:(id)sender
{
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    
    NSInteger priceRangeIndex = button.tag - kPriceRangeButtonShift;
    
    NSString *currentPriceRange = [kPriceRangeOptions objectAtIndex:priceRangeIndex];
    
    [self.priceRanges replaceObjectAtIndex:priceRangeIndex withObject:[NSNumber numberWithBool:button.selected]];
    
    /*
    if([self.priceRanges containsObject:currentPriceRange])
        [self.priceRanges removeObject:currentPriceRange];
    else
        [self.priceRanges addObject:currentPriceRange];
     */
}

- (void)setRangeOption:(NSInteger)option
{
    _rangeOptionChanged = YES;
    UIButton *button = (UIButton *)[self.view viewWithTag:option + 1001];
    
    dlog(@"button %@, option %i", button, option);
    
    UILabel *label = (UILabel *)[self.view viewWithTag:button.tag + kRangeButtonLabelShift];
    CGFloat duration = 0.5f * abs(self.selectRangeBullet.center.x - button.center.x) / 250.0f;
    
    [UIView beginAnimations:@"" context:nil];
    [UIView setAnimationDuration:duration];
    
    self.selectRangeBullet.center = button.center;
    
    for(NSInteger i = kFistRangeLabelTag; i < kFistRangeLabelTag + kRangeOptionsCount; i++)
    {
        UILabel *currentLabel = (UILabel *)[self.view viewWithTag:i];
        currentLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:14.0f];
    }
    
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:14.0f];
    
    [UIView commitAnimations];
}

- (IBAction)selectRangeButtonClick:(id)sender
{
    UIButton *button = (UIButton *)sender;
    _currentRangeOption = button.tag - 1001;
    
    [self setRangeOption:_currentRangeOption];
}

- (IBAction)refineSearchButtonClick:(id)sender
{
    static BOOL firstTimeShown = YES;
    
    [self.searchField resignFirstResponder];
    [self.locationField resignFirstResponder];
    
    
    self.refineSearchView.alpha = 0.0f;
    self.refineSearchView.hidden = NO;
    
    [UIView beginAnimations:@"" context:nil];
    [UIView setAnimationDuration:0.5f];
    
    _topSearchButton.alpha = 0.0;
    self.refineSearchButton.alpha = 0.0f;
    self.refineSearchView.alpha = 1.0f;
    
    CGRect headerViewOriginalFrame = headerView.frame;
    headerView.frame = CGRectMake(headerViewOriginalFrame.origin.x, 
                                  headerViewOriginalFrame.origin.y, 
                                  headerViewOriginalFrame.size.width, 
                                  headerViewOriginalFrame.size.height + kHeaderViewShift);
    
    CGRect originalFrame = self.refineSearchBackground.frame;
    self.refineSearchBackground.frame = CGRectMake(originalFrame.origin.x,
                                                   originalFrame.origin.y, 
                                                   originalFrame.size.width, 
                                                   originalFrame.size.height + kRefineSearchShift);
    
    [UIView commitAnimations];
    
    self.tableView.tableHeaderView = headerView;
    
    _refineSearchIsOpen = YES;
    
    if(!_rangeOptionChanged)
    {
        [self setRangeOption:_currentRangeOption];
    }
}

- (IBAction)close
{
    //[self.navigationController popViewControllerAnimated:YES];
    [self dismissModalViewControllerAnimated:YES];
    [[DataSource instance].tabBar showTabBar];
}

- (IBAction)search
{
    self.delegate.searchString = self.searchField.text;
    self.delegate.priceRanges = self.priceRanges;
    self.delegate.searchSorting = _sortingString;
    [self.delegate setRangePage:_currentRangeOption];
    
    if([self.delegate respondsToSelector:@selector(setOptions:)])
    {
        [self.delegate setOptions:_options];
    }
    
    [self.delegate searchFromSearchBar];
    [self close];
}

#pragma mark -
#pragma mark UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if(_refineSearchIsOpen)
    {
        /*
         set refine search title
         */
        
        NSString *refineSearchTitle = [NSString stringWithFormat:@" %@", [kDistanceOptions objectAtIndex:_currentRangeOption]];
        BOOL priceRangesAdded = NO;
        
        for(NSInteger i=0; i<5; i++)
        {
            if([[self.priceRanges objectAtIndex:i] boolValue])
            {
                refineSearchTitle = [refineSearchTitle stringByAppendingString:@", "];
                
                for(NSInteger j=0; j<=i ;j++)
                    refineSearchTitle = [refineSearchTitle stringByAppendingString:@"$"];
                
                
                priceRangesAdded = YES;
            }       
        }
        
        if(priceRangesAdded)
            refineSearchTitle = [refineSearchTitle stringByAppendingFormat:@" "];
        
        //if([refineSearchTitle length] > 0)
        //    refineSearchTitle = [refineSearchTitle substringToIndex:[refineSearchTitle length] - 2];
        
        //sorting 
        refineSearchTitle = [refineSearchTitle stringByAppendingFormat:@", by %@ ", _sortingString];
        
        [self.refineSearchButton setTitle:refineSearchTitle forState:UIControlStateNormal];
        
        [UIView beginAnimations:@"" context:nil];
        [UIView setAnimationDuration:0.5f];
        
        _topSearchButton.alpha = 1.0;
        self.refineSearchButton.alpha = 1.0f;
        self.refineSearchView.alpha = 0.0f;
        
        CGRect headerViewOriginalFrame = headerView.frame;
        headerView.frame = CGRectMake(headerViewOriginalFrame.origin.x, 
                                      headerViewOriginalFrame.origin.y, 
                                      headerViewOriginalFrame.size.width, 
                                      headerViewOriginalFrame.size.height - kHeaderViewShift);

        
        CGRect originalFrame = self.refineSearchBackground.frame;
        self.refineSearchBackground.frame = CGRectMake(originalFrame.origin.x,
                                                       originalFrame.origin.y, 
                                                       originalFrame.size.width, 
                                                       originalFrame.size.height - kRefineSearchShift);
        
        [UIView commitAnimations];
        
        _refineSearchIsOpen = NO;
    }
    
    self.tableView.tableHeaderView = headerView;
   
    
    //animation for search fields - come back later here
    /*
    if(textField == locationField)
    {
        [UIView beginAnimations:@"" context:nil];
        [UIView setAnimationDuration:0.5f];
        
        CGRect placeViewFrame = placeView.frame;
        placeView.frame = CGRectMake(placeViewFrame.origin.x - kPlaceSearchShift, 
                                     placeViewFrame.origin.y, 
                                     placeViewFrame.size.width + kPlaceSearchShift, 
                                     placeViewFrame.size.height);
        
        CGRect searchViewFrame = searchView.frame;
        searchView.frame = CGRectMake(searchViewFrame.origin.x, 
                                     searchViewFrame.origin.y, 
                                     searchViewFrame.size.width - kPlaceSearchShift, 
                                     searchViewFrame.size.height);
        
        
        [UIView commitAnimations];
        
    }
    */
    
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
        
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self search];
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if(textField == self.searchField)
        [self setSearchString:newString];
    
    return YES;
}

@end