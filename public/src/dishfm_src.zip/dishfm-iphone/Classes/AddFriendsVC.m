//
//  AddFriendsVC.m
//  dish.fm
//
//  Created by Petr Prokop on 3/5/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "AddFriendsVC.h"
#import "Config.h"
#import "ConvenientPopups.h"
#import "LoginController.h"
#import "HJManagedImageV.h"
#import <QuartzCore/QuartzCore.h>
#import "DataSource.h"
#import "Utils.h"
#import "CustomSearchBar.h"


#define kAddedFriendsScrollViewHeight 32.0f

@implementation AddFriendsVC

@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    if(_requestProcessor)
        [_requestProcessor cancelRequest];
    
    [super dealloc];
}

#pragma mark - View lifecycle

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];

    
    dlog(@"self.delegate.addedUsers %@", self.delegate.addedUsers);
    
    [self.navigationItem setTitle:@"Tag friends"];
    
    UIImage *backgroundImage = [UIImage imageNamed:@"Background"];
    UIImageView *backgroundIV = [[UIImageView alloc] initWithImage:backgroundImage];
    [self.view addSubview:backgroundIV];
	
	_TVC = [[PullRefreshTableViewController alloc] initWithStyle:UITableViewStylePlain];
    _TVC.tableView.frame = CGRectMake(0, kAddedFriendsScrollViewHeight+43, 320, 460-kAddedFriendsScrollViewHeight-43);
    //_TVC.parent = self;
    _TVC.tableView.dataSource = self;
    _TVC.tableView.delegate = self;
	_TVC.tableView.backgroundColor = [UIColor clearColor];
	_TVC.tableView.opaque = NO;

    _TVC.tableView.separatorColor = [UIColor clearColor];
    [self.view addSubview:_TVC.tableView];
    
    _searchBar = [[CustomSearchBar alloc] init];
    _searchBar.frame = CGRectMake(0, kAddedFriendsScrollViewHeight, 320, 43);
    _searchBar.placeholder = @"Find: friend name";
    _searchBar.delegate = self;
    [self.view addSubview:_searchBar];
    
    _withWhomScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(10, 0, 300, kAddedFriendsScrollViewHeight)];
    _withWhomScrollView.showsHorizontalScrollIndicator = NO;
    _withWhomScrollView.contentSize = CGSizeMake(300, kAddedFriendsScrollViewHeight);
    [self.view addSubview:_withWhomScrollView];


    UIImage *buttonBackground = [UIImage imageNamed:@"HeaderButtonSquare.png"];
    UIButton *okButton = [UIButton buttonWithType:UIButtonTypeCustom];
    okButton.frame = CGRectMake(0, 0, buttonBackground.size.width, buttonBackground.size.height);
    [okButton setTitleShadowColor:[UIColor grayColor] forState:UIControlStateNormal];
    [okButton setBackgroundImage:buttonBackground forState:UIControlStateNormal];
    [okButton setTitle:@"Ok" forState:UIControlStateNormal];
    okButton.titleLabel.shadowOffset = CGSizeMake(0, -1);    
    okButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0f];
    [okButton addTarget:self action:@selector(checkinButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:okButton];
    
    
    if(!self.delegate.currentUserFriends || ![self.delegate.currentUserFriends count])
        [self update];
    else
    {
        [self updateWithWhom];
        [_TVC.tableView reloadData];
    }
}


#pragma mark - UI

- (IBAction)bindTwitterClicked:(id)sender
{
    [LoginController instance].socialNetworkBindingMode = YES;
    [[LoginController instance] loginWithTwitter];
}

- (void)checkinButtonClicked
{
    /*
    NSMutableArray *fb = [[DataSource instance].homeCookedFriends objectForKey:@"facebook"];
    NSMutableArray *tw = [[DataSource instance].homeCookedFriends objectForKey:@"twitter"];
    
    [fb removeAllObjects];
    [tw removeAllObjects];
    
    NSString *friendsDescription = @"";
    NSInteger numberOfFriends = 0;
    
    for(NSDictionary *currentUser in self.delegate.addedUsers)
    {
        //NSStrings OR NSNumbers!
        NSString *currentFacebook = [currentUser objectForKey:@"facebook"];
        NSString *currentTwitter = [currentUser objectForKey:@"twitter"];
        
        if([currentFacebook intValue])
        {
            numberOfFriends++;
            
            if(numberOfFriends<3)
                friendsDescription = [friendsDescription stringByAppendingFormat:@"%@ ", [Utils shortUserName:[currentUser objectForKey:@"name"]]];
            else if(numberOfFriends == 3)
                friendsDescription = [friendsDescription stringByAppendingFormat:@"and others"];
            
            [fb addObject:currentFacebook];
            
            continue; //facebook preference for time being
        }
        
        if([currentTwitter intValue])
        {
            numberOfFriends++;
            
            if(numberOfFriends<3)
                friendsDescription = [friendsDescription stringByAppendingFormat:@"%@ ", [Utils shortUserName:[currentUser objectForKey:@"name"]]];
            else if(numberOfFriends == 3)
                friendsDescription = [friendsDescription stringByAppendingFormat:@"and others"];
            
            [tw addObject:currentTwitter];
        }
    }
         
    if(self.delegate)
    {
        [self.delegate updateFriends:friendsDescription];
        [self.navigationController popViewControllerAnimated:YES];
    }
     */
    
    [self.delegate updateFriends];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)addUserClick:(UIButton *)sender
{
    if(!self.delegate.addedUsers)
        self.delegate.addedUsers = [[NSMutableArray alloc] init];
    
    UITableViewCell *cell = (UITableViewCell *) sender;
    while (cell && ![cell isKindOfClass:[UITableViewCell class]]) 
    {
        cell = (UITableViewCell *) [cell superview];
    }
    
    if(!cell)
        return;
    
    /*
    UIImage *checkImage = [UIImage imageNamed:@"checkGreen.png"];
    [sender setBackgroundImage:nil forState:UIControlStateSelected];
    [sender setImage:checkImage forState:UIControlStateSelected];
    [sender setTitle:@"" forState:UIControlStateSelected];
    */
    
    sender.selected = !sender.selected;
    
    NSIndexPath *ip = [_TVC.tableView indexPathForCell:cell];
    
    NSDictionary *user = [[self filteredUsers] objectAtIndex:ip.row];
    
    if(![self.delegate.addedUsers containsObject:user])
        [self.delegate.addedUsers addObject:user];
    else
        [self.delegate.addedUsers removeObject:user];
    
    if(![self.delegate.addedUsersIndexSet containsIndex:ip.row])
        [self.delegate.addedUsersIndexSet addIndex:ip.row];
    else    
        [self.delegate.addedUsersIndexSet removeIndex:ip.row];
        
    [self updateWithWhom];
}

#pragma mark - Internal

- (void)updateWithWhom
{
    for(UIView *view in _withWhomScrollView.subviews)
        [view removeFromSuperview];
    
    NSInteger userNamesCount = 0;
    CGFloat horizontalOffset = 0.0f;
    CGSize constraintSize = CGSizeMake(9999, 14);
    
    for(NSDictionary *currentUser in self.delegate.addedUsers)
    {
        //[userNames addObject:];
        
        UILabel *withWhomLabel = [[UILabel alloc] init];
        
        CGFloat labelSize = 16.0f;
        
        withWhomLabel.frame = CGRectMake(horizontalOffset, (kAddedFriendsScrollViewHeight-labelSize)/2, 0, labelSize);
        
        withWhomLabel.textColor = kBrownTextColor;
        withWhomLabel.shadowColor = [UIColor whiteColor];
        withWhomLabel.shadowOffset = CGSizeMake(0, 1);
        withWhomLabel.backgroundColor = [UIColor clearColor];
        withWhomLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:labelSize];
        withWhomLabel.textAlignment = UITextAlignmentLeft;
        withWhomLabel.text = [Utils shortUserName:[currentUser objectForKey:@"name"]];
        CGSize actualSize = [withWhomLabel.text sizeWithFont:withWhomLabel.font 
                                           constrainedToSize:constraintSize];
        withWhomLabel.frame = CGRectMake(horizontalOffset, 0, actualSize.width, kAddedFriendsScrollViewHeight);
        [_withWhomScrollView addSubview:withWhomLabel];
        horizontalOffset += actualSize.width;
        
        horizontalOffset += 2;
        
        CGFloat buttonSize = 18.0f;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.tag = userNamesCount;
        button.frame = CGRectMake(horizontalOffset, 
                                  (kAddedFriendsScrollViewHeight - buttonSize)/2, 
                                  buttonSize, 
                                  buttonSize);
        
        [button setImage:[UIImage imageNamed:@"closeBtn.png"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(removeFriend:) forControlEvents:UIControlEventTouchUpInside];
        [_withWhomScrollView addSubview:button];
        horizontalOffset += button.frame.size.width;
        
        horizontalOffset += 12;
        
        dlog(@"withWhomLabel %@ button %@", withWhomLabel, button);
        
        userNamesCount++;
    }    
    _withWhomScrollView.contentSize = CGSizeMake(horizontalOffset, 14);
    
    CGRect rectToScroll = CGRectMake(MAX(0, horizontalOffset - _withWhomScrollView.frame.size.width),
                                     0,
                                     _withWhomScrollView.frame.size.width,
                                     _withWhomScrollView.frame.size.height);
    [_withWhomScrollView scrollRectToVisible:rectToScroll animated:YES];
}

- (void)removeFriend:(UIButton *)sender
{
    NSInteger indexOfFriendToRemove = sender.tag;
    
    if(indexOfFriendToRemove < [self.delegate.addedUsers count])
        [self.delegate.addedUsers removeObjectAtIndex:indexOfFriendToRemove];
    
    [self updateWithWhom];
    [_TVC.tableView reloadData];
}

- (void)getItems
{    
    if(_requestProcessor != nil)
    {
        [_requestProcessor cancelRequest];
        _requestProcessor = nil;
        [_TVC stopLoading];
    }
    
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    [ConvenientPopups showNonBlockingPopupOnView:self.view withText:@"Scanning for friends..."];
    
    _requestProcessor = [[RequestProcessor alloc] init];
    _requestProcessor.delegate = self;
    _requestProcessor.successCallback = @selector(friendsLoaded:);
    _requestProcessor.failCallback = @selector(friendsFailedToLoad:);
    [_requestProcessor findFriendsForFacebookToken:[LoginController instance].facebook.accessToken 
                                        OAuthToken:[LoginController getTwitterOAuthToken] 
                                  OAuthTokenSecret:[LoginController getTwitterOAuthTokenSecret]];
    [_requestProcessor release];
}


- (void)update
{    

    [self getItems];
}

#pragma mark -
#pragma mark Internal

- (NSArray *)filteredUsers
{
    if(_searchBar.text && ![_searchBar.text isEqualToString:@""])
    {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name CONTAINS[cd] %@", _searchBar.text];
        return [self.delegate.currentUserFriends filteredArrayUsingPredicate:predicate];
    }
    
    return self.delegate.currentUserFriends;
}


#pragma mark -
#pragma mark UITableViewDataSource Protocol

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
	return 2;
}

- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section
{
    if(section == 0)
    {
        if([LoginController isTwitterBinded])
            return 0;
        else
            return 1;
    }
    
    if(section == 1)
        return [[self filteredUsers] count];
    
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60.0f;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView 
		 cellForRowAtIndexPath:(NSIndexPath *)indexPath
{	
	NSInteger row = [indexPath row];
	NSInteger section = [indexPath section];
    

    static const NSInteger kUsersBackgroundTag = 1001;
    static const NSInteger kAvatarPlaceholderTag = 1002;
    static const NSInteger kUserNameTag = 1003;
    static const NSInteger kButtonTag = 1004;
    static const NSInteger kMIVTag = 1005;
    
    static const NSInteger kBgTopTag = 1006;
    static const NSInteger kBgBottomTag = 1007;
    
    static const NSInteger kSeparatorTag = 1008;
     
    if(section == 0)
    {
        static NSString *cellIdentifier= @"Bind Twitter Cell";
        UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil)
        {
            [[NSBundle mainBundle] loadNibNamed:@"AddFriendsAddTwitterCell" 
                                          owner:self 
                                        options:nil];
            
            cell = _bindTwitterCell;
            _bindTwitterCell = nil;
            
            UIImageView *bgTop = (UIImageView *)[cell viewWithTag:kBgTopTag];
            UIImageView *bgBottom = (UIImageView *)[cell viewWithTag:kBgBottomTag];
            
            bgTop.layer.cornerRadius = 3.0f;
            bgBottom.layer.cornerRadius = 3.0f;
            bgBottom.layer.shadowOffset = CGSizeMake(0, 3);
            bgBottom.layer.shadowRadius = 1;
            bgBottom.layer.shadowOpacity = 0.3;
            bgBottom.layer.shadowPath = [UIBezierPath bezierPathWithRect:bgBottom.bounds].CGPath;
            
        }
        
        return cell;
    }
    else if(section == 1)
    {
        static NSString *cellIdentifier= @"User Relations Cell";
        UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil)
        {
            [[NSBundle mainBundle] loadNibNamed:@"UserRelationsCell" owner:self options:nil];
            cell = _cell;
            _cell = nil;
            
            cell.selectedBackgroundView = [[UIView new] autorelease];
            cell.backgroundColor = [UIColor clearColor];
            cell.backgroundView.backgroundColor = [UIColor clearColor];
            cell.contentView.backgroundColor = [UIColor clearColor];
            
            UIView *avatarPlaceholder = (UIView *)[cell viewWithTag:kAvatarPlaceholderTag];
            UIButton *button = (UILabel *)[cell viewWithTag:kButtonTag];
            
            avatarPlaceholder.layer.cornerRadius = 3.0f;
            avatarPlaceholder.layer.masksToBounds = YES;
            HJManagedImageV *miv = [[HJManagedImageV alloc] initWithFrame:CGRectMake(0, 
                                                                                     0, 
                                                                                     avatarPlaceholder.frame.size.width,
                                                                                     avatarPlaceholder.frame.size.height)];
            miv.tag = kMIVTag;
            [avatarPlaceholder addSubview:miv];
            
            [button addTarget:self action:@selector(addUserClick:) forControlEvents:UIControlEventTouchUpInside];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        
        
        //return cell;
        
        UIImageView *background = (UIImageView *)[cell viewWithTag:kUsersBackgroundTag];
        UIView *avatarPlaceholder = (UIView *)[cell viewWithTag:kAvatarPlaceholderTag];
        UILabel *userNameLabel = (UILabel *)[cell viewWithTag:kUserNameTag];
        UIButton *button = (UIButton *)[cell viewWithTag:kButtonTag];
        HJManagedImageV *miv = (HJManagedImageV *)[cell viewWithTag:kMIVTag];
        
        UIImageView *bgTop = (UIImageView *)[cell viewWithTag:kBgTopTag];
        UIImageView *bgBottom = (UIImageView *)[cell viewWithTag:kBgBottomTag];
        
        UIView *separator = (UIView *)[cell viewWithTag:kSeparatorTag];
        
        userNameLabel.text = @"";
        bgTop.layer.cornerRadius = 0.0f;
        bgBottom.layer.cornerRadius = 0.0f;
        [miv clear];
        separator.hidden = NO;
        
        dlog(@"self.delegate.addedUsersIndexSet %@", self.delegate.addedUsersIndexSet);
        
        NSDictionary *user = [[self filteredUsers] objectAtIndex:indexPath.row];
        
        [button setTitle:@"Add" forState:UIControlStateNormal];
        button.selected = NO;
        
        //set check image
        if(self.delegate.addedUsers)
        {
            //button.selected = (([self.delegate.addedUsers indexOfObject:user]) != NSNotFound);
            
            if([self.delegate.addedUsers containsObject:user])
            {
                dlog(@"selected");
                button.selected = YES;
            }
        }
        
        NSString *userName = [user objectForKey:@"name"];
        
        if([userName isKindOfClass:[NSString class]])
            userNameLabel.text = userName;
        
        //rounded corners for top and bottom cell
        if(indexPath.row == 0)
        {
            bgTop.layer.cornerRadius = 3.0f;
            separator.hidden = YES;
        }
        
        if(indexPath.row == [self.delegate.currentUserFriends count]-1)
        {
            bgBottom.layer.cornerRadius = 3.0f;
            bgBottom.layer.shadowOffset = CGSizeMake(0, 3);
            bgBottom.layer.shadowRadius = 1;
            bgBottom.layer.shadowOpacity = 0.3;
            bgBottom.layer.shadowPath = [UIBezierPath bezierPathWithRect:bgBottom.bounds].CGPath;
        }
        
        //button
        
        
        //user photo
        NSString *userPhotoString = [user objectForKey:@"photo"];
        
        if(userPhotoString && ![userPhotoString isEqualToString:@""])
        {
            HJManagedImageV *miv = [[HJManagedImageV alloc] initWithFrame:CGRectMake(0, 
                                                                                     0, 
                                                                                     avatarPlaceholder.frame.size.width,
                                                                                     avatarPlaceholder.frame.size.height)];
            miv.url = [NSURL URLWithString:userPhotoString];
            [avatarPlaceholder addSubview:miv];
            [[DataSource instance].objMan manage:miv];
            [miv release];
        }

        return cell;
    }
}


- (void)friendsLoaded:(RequestProcessor *)rp
{
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    [_TVC stopLoading];
    _requestProcessor = nil;
    
    self.delegate.currentUserFriends = [[rp.processedJSON objectForKey:@"users"] retain];
    
    [_TVC.tableView reloadData];
    [self updateWithWhom];
}

- (void)friendsFailedToLoad:(RequestProcessor *)rp
{
    _requestProcessor = nil;
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    [_TVC stopLoading];
}

#pragma mark - UISearchBar delegate

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar 
{
	[searchBar resignFirstResponder];
    
	return YES;
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar 
{
    searchBar.text = @"";
    [_TVC.tableView reloadData];
    
    [searchBar resignFirstResponder];
    [searchBar setShowsCancelButton:NO animated:YES];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
    [searchBar setShowsCancelButton:NO animated:YES];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    [_TVC.tableView reloadData];
}

@end
