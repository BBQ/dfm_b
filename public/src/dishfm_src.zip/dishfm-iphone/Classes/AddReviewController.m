//tags 1-10 are for rating stars
#define kWhereButtonId 1001
#define kWhatButtonId 1002
#define kTextFieldId 1003
#define kRestaurantLabelTag 1004
#define kDishLabelTag 1005
#define kTitleLabelTag 1006
#define kProgressViewTag 1007
#define kPhotoTag 1100

#import "AddReviewController.h"
#import "RestaurantListController.h"
#import "RestaurantModel.h"
#import "MenuController.h"
#import "ConvenientPopups.h"
#import "DataSource.h"
#import <QuartzCore/QuartzCore.h>
#import "CustomNavigationController.h"
#import "LoggerController.h"
#import "StarView.h"
#import <QuartzCore/QuartzCore.h>
#import "AddFriendsVC.h"
#import "AddDishController.h"
#import "AlertView.h"
#import "ReviewDraftModel.h"
#import "Config.h"
#import "UIImage+Resize.h"
#import "Utils.h"

@implementation AddReviewController

@synthesize roundableViews;

@synthesize uuid,
            photo,
            restaurant,
            dish,
            //rating,
            dishName,
            photoRP;

@synthesize foursquareVenueID;
@synthesize addedUsers;
@synthesize currentUserFriends;
@synthesize addedUsersIndexSet;
@synthesize isCheckInMode;
@synthesize reviewText;
@synthesize reviewRating;

- (void)dealloc 
{
    dlog(@"AddReviewController dealloc");
    
    [self.view removeFromSuperview];
    
    if(self.photoRP)
    {
        [self.photoRP cancelRequest];
        self.photoRP = nil;
    }
    
    self.uuid = nil;
    
    dlog(@"self.photo rc %i", [self.photo retainCount]);
    
    self.photo = nil;
    self.restaurant = nil;
    self.dish = nil;
    self.dishName = nil;
    
    
    
    [_starViewPlaceholder release];
    [_iamWithButton release];
    [_friendsLabel release];
    [super dealloc];
}

- (id)init
{
	self = [super initWithNibName:@"AddReviewController" bundle:nil];
	
	if(self)
	{
		self.photo = nil;
        _rating = 0;
        self.uuid = nil;
        self.restaurant = nil;
        self.dish = nil;
        self.dishName = nil;
        self.photoRP = nil;
        self.foursquareVenueID = nil;
        self.isCheckInMode = YES;
        
        _shareOnFacebook = NO;
        _shareOnTwitter = NO;
        
        dlog(@"restaurantName %@ restaurantID %@ restaurantFoursquareVenueID %@", 
             [DataSource instance].restaurantName,
             [DataSource instance].restaurantID,
             [DataSource instance].restaurantFoursquareVenueID
             );
        
        if([DataSource instance].restaurantName && [DataSource instance].restaurantID)
        {
            self.restaurant = 
            [[RestaurantModel alloc] initWithDictionary:
             [NSDictionary dictionaryWithObjectsAndKeys:[DataSource instance].restaurantName, @"name",
              [DataSource instance].restaurantID, @"id", nil]];
        }
        else if([DataSource instance].restaurantName && [DataSource instance].restaurantFoursquareVenueID)
        {
            self.restaurant = [[RestaurantModel alloc] initWithFoursquareInfo:nil];
            self.restaurant.isFoursquareOnly = YES;
            self.restaurant.foursquareVenueId = [DataSource instance].restaurantFoursquareVenueID;
            self.foursquareVenueID = [DataSource instance].restaurantFoursquareVenueID;
            self.restaurant.name = [DataSource instance].restaurantName;
        }
        
        if([DataSource instance].dishName && ([DataSource instance].dishID != -1))
        {
            self.dish = 
            [NSDictionary dictionaryWithObjectsAndKeys:[DataSource instance].dishName, @"name",
             [NSNumber numberWithInt:[DataSource instance].dishID], @"id", nil];
        }
        else if([DataSource instance].dishName)
        {
            /*
            [self updateDishWithName:[DataSource instance].dishName
                              typeId:0
                           subtypeId:0];
             */

            self.dishName = [DataSource instance].dishName;
            _typeId = 0;
            _subtypeId = 0;
            self.dish = nil;
        }
        
        if([DataSource instance].imageUUID)
        {
            self.uuid = [DataSource instance].imageUUID; 
        }
        
        if([DataSource instance].reviewImage)
        {
            self.photo = [DataSource instance].reviewImage;
        }
        
        _isSendingReview = NO;
        
        /*
        if(self.photo != nil)
        {
            self.photoRP = [[RequestProcessor alloc] init];
            self.photoRP.delegate = self;
            [self.photoRP addPhoto:self.photo 
                          withUUID:self.uuid];
            [self.photoRP release];
            
            [LoggerController logEvent:@"userVisitedAddReviewPage"];
        }
         */
        
        _photoIsLoaded = NO;
        _isDishInClicked = NO;
        self.addedUsersIndexSet = [[NSMutableIndexSet alloc] init];
        
        if([DataSource instance].addedUsers)
            self.addedUsers = [DataSource instance].addedUsers;
        
        if(![DataSource instance].homeCookedFriends)
        {
            [DataSource instance].homeCookedFriends = [[NSMutableDictionary alloc] init];
            
            NSMutableArray *fb = [[NSMutableArray alloc] init];
            NSMutableArray *tw = [[NSMutableArray alloc] init];
            
            [[DataSource instance].homeCookedFriends setObject:tw
                                                        forKey:@"twitter"];
            [[DataSource instance].homeCookedFriends setObject:fb
                                                        forKey:@"facebook"];
            
            [fb release];
            [tw release];
        }
	}
	
	return self;	
}

- (id)initWithPhoto:(UIImage *)aPhoto
               UUID:(NSString *)anUUID
{
    [self init];
    
    if(self)
    {
        self.photo = aPhoto;
        self.uuid = anUUID;
        
        /*
        if(self.photo != nil && !self.photoRP)
        {
            self.photoRP = [[RequestProcessor alloc] init];
            self.photoRP.delegate = self;
            [self.photoRP addPhoto:self.photo 
                          withUUID:self.uuid];
            [self.photoRP release];
            
            [LoggerController logEvent:@"userVisitedAddReviewPage"];
        }
         */
    }
    
    return self;
}

- (void)editPhoto
{
    //[self.navigationController setNavigationBarHidden:YES animated:NO];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
	
    dlog(@"AddReviewController viewDidLoad");
    
    /*
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Edit photo" 
                                                                              style:UIBarButtonItemStylePlain
                                                                             target:self 
                                                                             action:@selector(editPhoto)];
    */
    _activeStarView = [[ActiveStarView alloc] initWithFrame:_starViewPlaceholder.frame];
    
    /*
     CGRectMake(0,
     0,
     _starViewPlaceholder.frame.size.width, 
     _starViewPlaceholder.frame.size.height)
     */
    
    [self.view addSubview:_activeStarView];
    _activeStarView.delegate = self;
    [_activeStarView release];
    
    for(UIView *view in self.roundableViews)
    {
        view.layer.masksToBounds = YES;
        view.layer.cornerRadius = 3;
    }
    
    for(UIView *viewToShadow in _viewsToShadow)
    {
        UIView *shadowView = [[UIView alloc] initWithFrame:viewToShadow.frame];
        
        CGRect frame = shadowView.frame;
        frame.origin.y += 1;
        shadowView.frame = frame;
        
        shadowView.layer.cornerRadius = 10.0f;
        shadowView.layer.masksToBounds = YES;
        shadowView.layer.shadowOffset = CGSizeMake(0, 1);
        shadowView.layer.shadowRadius = 1;
        shadowView.layer.shadowOpacity = 0.3;
        shadowView.layer.shadowPath = [UIBezierPath bezierPathWithRect:viewToShadow.bounds].CGPath;
        
        [[viewToShadow superview] insertSubview:shadowView belowSubview:viewToShadow];
    }
    
	UIButton *whereButton = (UIButton *)[self.view viewWithTag:kWhereButtonId];
	[whereButton addTarget:self action:@selector(chooseRestaurant) forControlEvents:UIControlEventTouchUpInside];
	
    
    UIButton *whatButton = (UIButton *)[self.view viewWithTag:kWhatButtonId];
	[whatButton addTarget:self action:@selector(chooseDish) forControlEvents:UIControlEventTouchUpInside];

    
	//UITextField *reviewTextField = (UITextField *)[self.view viewWithTag:kTextFieldId];
    UILabel *restaurantLabel = (UILabel *)[self.view viewWithTag:kRestaurantLabelTag];
    UILabel *dishLabel = (UILabel *)[self.view viewWithTag:kDishLabelTag];
    UIImageView *photoIV = (UIImageView *)[self.view viewWithTag:kPhotoTag];
	
    restaurantLabel.text = @"";
    dishLabel.text = @"";
	
    if(self.photo != nil)
    {
        /*
        CGFloat croppedImageHeight = self.photo.size.width * (photoIV.frame.size.height/photoIV.frame.size.width);
        
        CGRect visibleRect = CGRectMake(0, 
                                        (self.photo.size.height - croppedImageHeight)/2, 
                                        self.photo.size.width, 
                                        croppedImageHeight);
        
        CGImageRef cr = CGImageCreateWithImageInRect([self.photo CGImage], visibleRect);
        UIImage* croppedImage = [[[UIImage alloc] initWithCGImage:cr] autorelease];
        CGImageRelease(cr);

        photoIV.image = croppedImage;
        */
        photoIV.image = self.photo;
        photoIV.layer.masksToBounds = YES;
        photoIV.layer.cornerRadius = 3;

        UIProgressView *progressView = (UIProgressView *) [self.view viewWithTag:kProgressViewTag];
        
        if(self.photoRP != nil)
        {
            dlog(@"self.photoRP != nil");
            self.photoRP.progressView = progressView;
        }
        else
        {
            dlog(@"self.photoRP IS nil");
            progressView.progress = 1.0f;
        }
    }
    
    /*
#define kStarLightDuration 0.1f
#define kInitialDelay 0.0f
    
    for(NSInteger i=1;i<=10;i++)
    {
        UIImageView *starOff = (UIImageView *)[self.view viewWithTag:i];
        UIImageView *starOn = (UIImageView *)[self.view viewWithTag:i+3000];
        
        [UIView beginAnimations:[NSString stringWithFormat:@"%i", i] context:nil];
        [UIView setAnimationDuration:kStarLightDuration];
        //[UIView setAnimationDelay:2.0f + i * 2 * kStarLightDuration];
        [UIView setAnimationDelay:kInitialDelay + i * 0.5 * kStarLightDuration];
        
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(yourAnimationHasFinished:finished:context:)];
        
        starOff.alpha = 0.0f;
        starOn.alpha = 1.0f;
        
        [UIView commitAnimations];
    }
     */
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 120, 24)];
    titleLabel.text = @"Review";
    titleLabel.textColor = [UIColor colorWithRed:97.0/255 green:40.0/255 blue:15.0/255 alpha:1.0];
    titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:24.0];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.shadowColor = [UIColor whiteColor];
    titleLabel.shadowOffset = CGSizeMake(0, 1);
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];
    
    dlog(@"self.dish %@ self.restaurant %@", self.dish, self.restaurant);
    
    
    /*
     Setting values
     */
    if(self.reviewRating)
    {
        [_activeStarView updateRating:self.reviewRating];
        _rating = [self.reviewRating floatValue];
    }
    
    if(self.reviewText)
    {
        reviewTextField.text = self.reviewText;
    }
    
    if(self.dish)
    {
        [self updateDish:self.dish];
    }
    
    if(self.restaurant)
    {
        [self updateRestaurant:self.restaurant];
    }
    
    if([DataSource instance].checkinType == kCheckInListTypeFriends)
    {
        UILabel *restaurantLabel = (UILabel *)[self.view viewWithTag:kRestaurantLabelTag];
        restaurantLabel.text = [DataSource instance].homeCookedPlace;
    }
    
    if(self.dishName)
        dishLabel.text = self.dishName;
    
    NSNumber *shareOnFacebook = [[LoginController instance].userSettings objectForKey:@"share_my_dishin_to_facebook"];
    NSNumber *shareOnTwitter = [[LoginController instance].userSettings objectForKey:@"share_my_dishin_to_twitter"];
    
    if([shareOnFacebook isKindOfClass:[NSNumber class]] && 
       [shareOnFacebook boolValue] && 
       [LoginController isFacebookBinded])
    {
        _shareOnFacebook = YES;
        _shareOnFacebookButton.selected = YES;
    }
    
    if([shareOnTwitter isKindOfClass:[NSNumber class]] && 
       [shareOnTwitter boolValue] && 
       [LoginController isTwitterBinded])
    {
        _shareOnTwitter = YES;
        _shareOnTwitterButton.selected = YES;
    }
    
    if(!self.isCheckInMode)
    {
        UIImage *buttonImage = [UIImage imageNamed:@"closeBtn.png"];
        UIButton *button = [UIButton buttonWithType:(UIButtonTypeCustom)];
        button.frame = CGRectMake(0, 0, buttonImage.size.width, buttonImage.size.height);
        [button setImage:buttonImage forState:(UIControlStateNormal)];
        [button addTarget:self action:@selector(deleteThisDraft:) forControlEvents:(UIControlEventTouchUpInside)];
        
        self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithCustomView:button] autorelease];
    }
    
    UIImage *buttonImage = [UIImage imageNamed:@"buttonXLSmall.png"];
    UIImage *stretchableImage = [buttonImage stretchableImageWithLeftCapWidth:14 topCapHeight:0];
    
    [_saveToDraftsButton setBackgroundImage:stretchableImage forState:UIControlStateNormal];
    [_dishInButton setBackgroundImage:stretchableImage forState:UIControlStateNormal];
    
    if(self.addedUsers)
        [self updateFriends];
    
    if([DataSource instance].shareOnFacebook && [LoginController isFacebookBinded])
    {
        _shareOnFacebook = [[DataSource instance].shareOnFacebook boolValue];
        _shareOnFacebookButton.selected = [[DataSource instance].shareOnFacebook boolValue];
    }
    
    if([DataSource instance].shareOnTwitter && [LoginController isTwitterBinded])
    {
        _shareOnTwitter = [[DataSource instance].shareOnTwitter boolValue];
        _shareOnTwitterButton.selected = [[DataSource instance].shareOnTwitter boolValue];
    }
    
    if([DataSource instance].shareOnPinterest)
    {
        _shareOnPinterest = [[DataSource instance].shareOnPinterest boolValue];
        _shareOnPinterestButton.selected = [[DataSource instance].shareOnPinterest boolValue];
    }
    
}

/*
- (void)yourAnimationHasFinished:(NSString *)animationID finished:(BOOL)finished context:(void *)context
{
    if(animationID == nil)
        return;
    
    NSInteger i = [animationID intValue];
    
    UIImageView *starOff = (UIImageView *)[self.view viewWithTag:i];
    UIImageView *starOn = (UIImageView *)[self.view viewWithTag:i+3000];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:kStarLightDuration];
    [UIView setAnimationDelay:0.5f];
    
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(yourAnimationHasFinished:finished:context:)];
    
    starOff.alpha = 1.0f;
    starOn.alpha = 0.0f;
    
    [UIView commitAnimations];
}
*/

- (void)didReceiveMemoryWarning 
{
    dlog(@"didReceiveMemoryWarning");
    
    if(self.photoRP != nil)
        self.photoRP.progressView = nil;
    [super didReceiveMemoryWarning];

}

- (void)viewDidUnload 
{
    dlog(@"viewDidUnload");
    
    if(self.photoRP != nil)
        self.photoRP.progressView = nil;
    
    [_starViewPlaceholder release];
    _starViewPlaceholder = nil;
    [_iamWithButton release];
    _iamWithButton = nil;
    [_friendsLabel release];
    _friendsLabel = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

#pragma mark -
#pragma mark Actions

- (void)updateFriends
{
    NSMutableArray *fb = [[DataSource instance].homeCookedFriends objectForKey:@"facebook"];
    NSMutableArray *tw = [[DataSource instance].homeCookedFriends objectForKey:@"twitter"];
    
    [fb removeAllObjects];
    [tw removeAllObjects];
    
    NSString *friendsDescription = @"";
    NSInteger numberOfFriends = 0;
    
    for(NSDictionary *currentUser in self.addedUsers)
    {
        //NSStrings OR NSNumbers!
        NSString *currentFacebook = [currentUser objectForKey:@"facebook"];
        NSString *currentTwitter = [currentUser objectForKey:@"twitter"];
        
        if([currentFacebook intValue])
        {
            numberOfFriends++;
            
            if(numberOfFriends<3)
                friendsDescription = [friendsDescription stringByAppendingFormat:@"%@ ", [Utils shortUserName:[currentUser objectForKey:@"name"]]];
            else if(numberOfFriends == 3)
                friendsDescription = [friendsDescription stringByAppendingFormat:@"and others"];
            
            [fb addObject:currentFacebook];
            
            continue; //facebook preference for time being
        }
        
        if([currentTwitter intValue])
        {
            numberOfFriends++;
            
            if(numberOfFriends<3)
                friendsDescription = [friendsDescription stringByAppendingFormat:@"%@ ", [Utils shortUserName:[currentUser objectForKey:@"name"]]];
            else if(numberOfFriends == 3)
                friendsDescription = [friendsDescription stringByAppendingFormat:@"and others"];
            
            [tw addObject:currentTwitter];
        }
    }
    
    _friendsLabel.text = friendsDescription;
}

- (void)updateRestaurant:(RestaurantModel *)aRestaurant
{
    UILabel *restaurantLabel = (UILabel *)[self.view viewWithTag:kRestaurantLabelTag];
    self.restaurant = aRestaurant;
    restaurantLabel.text = aRestaurant.name;
    
    if(aRestaurant.isFoursquareOnly)
    {
        self.foursquareVenueID = aRestaurant.foursquareVenueId;
        dlog(@"self.foursquareVenuID %@", self.foursquareVenueID);
    }
    else
        self.foursquareVenueID = nil;
}

- (void)updateDish:(NSDictionary *)aDish
{
    UILabel *dishLabel = (UILabel *)[self.view viewWithTag:kDishLabelTag];
    self.dish = aDish;
    dishLabel.text = [aDish objectForKey:@"name"];
    
    self.dishName = nil;
}

- (void)updateDishWithName:(NSString *) aDishName
                    typeId:(NSInteger) aTypeId
                 subtypeId:(NSInteger) aSubtypeId
{
    UILabel *dishLabel = (UILabel *)[self.view viewWithTag:kDishLabelTag];
    self.dishName = aDishName;
    dishLabel.text = self.dishName;
    
    _typeId = aTypeId;
    _subtypeId = aSubtypeId;
    
    self.dish = nil;
    
    [self.navigationController popToViewController:self animated:YES];
}

- (void)rateView:(ActiveStarView *)view ratingDidChange:(double)rating
{
    _rating = rating;
}

- (void)cancel
{
    //ask user first
    [self.navigationController popToRootViewControllerAnimated:NO];
    [[DataSource instance].tabBar showTabBar];
    [[DataSource instance].tabBar changeTabToIndex:0];
}

#pragma mark -
#pragma mark Internal

- (void)sendReview
{
    [[DataSource instance] removeDraftWithUUID:self.uuid];
    
    dlog(@"sendReview rc %i", [self retainCount]);
    
    if([reviewTextField.text isEqualToString:@"For example: best dessert downtown"])
        reviewTextField.text = @"";
    
    [LoggerController logEvent:@"User dished in"];
    
    ReviewDraftModel *rdm = [[ReviewDraftModel alloc] init];
    rdm.reviewType = kReviewTypeNormal;
    rdm.checkinType = [DataSource instance].checkinType;
    rdm.taggedFriends = self.addedUsers;
    rdm.authorSystemID = [LoginController currentUserID];
    rdm.dishPrice = [DataSource instance].dishPrice;
    
    if(self.dishName == nil && self.dish != nil)
    {
        rdm.photoData = UIImageJPEGRepresentation([self.photo imageResizedToFit:kUploadPhotoSize 
                                                           interpolationQuality:kCGInterpolationHigh], 0.8);
        rdm.uuid = self.uuid;
        rdm.restaurantName = self.restaurant.name;
        rdm.restaurantID = [NSNumber numberWithInt:self.restaurant.restaurantId];
        
        rdm.foursquareVenueID = self.foursquareVenueID;
        rdm.reviewText = reviewTextField.text;
        rdm.reviewRating = [NSNumber numberWithFloat:_rating];
        rdm.dishID = [self.dish objectForKey:@"id"];
        rdm.dishName = [self.dish objectForKey:@"name"];
    }
    else if(self.dishName != nil && self.dish == nil)
    {
        rdm.photoData = UIImageJPEGRepresentation([self.photo imageResizedToFit:kUploadPhotoSize 
                                                           interpolationQuality:kCGInterpolationHigh], 0.8);
        rdm.uuid = self.uuid;
        rdm.restaurantName = self.restaurant.name;
        rdm.restaurantID = [NSNumber numberWithInt:self.restaurant.restaurantId];
        rdm.foursquareVenueID = self.foursquareVenueID;
        rdm.reviewText = reviewTextField.text;
        rdm.reviewRating = [NSNumber numberWithFloat:_rating];
        rdm.dishName = self.dishName;
        rdm.typeID = [NSNumber numberWithInt:_typeId];
        rdm.subtypeID = [NSNumber numberWithInt:_subtypeId];
    }
    
    rdm.postOnFacebook = [NSNumber numberWithBool:_shareOnFacebook];
    rdm.postOnTwitter = [NSNumber numberWithBool:_shareOnTwitter];
    rdm.postOnPinterest = [NSNumber numberWithBool:_shareOnPinterest];
    
    [[DataSource instance] removeDraftWithUUID:rdm.uuid];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updateDrafts" object:self userInfo:nil];
    [rdm saveToFile];
    [[DataSource instance] addUnloadedReview:rdm];
    
    
    [DataSource instance].imageUUID = nil;
    [DataSource instance].reviewImage = nil;
    [[DataSource instance] cleanNewReviewData];
    [[DataSource instance].feedController scrollToTop];
    
    
    /*
    [ConvenientPopups showToastLikeMessage:@"Your review has been saved to drafts - do not forget to send it!" 
                                    onView:[DataSource instance].tabBar.view];
    */
    
    //[[NSNotificationCenter defaultCenter] postNotificationName:@"updateDrafts" object:self userInfo:nil];
    
    //[self viewWillDisappear:NO];
    
    /*
    [[DataSource instance].tabBar dismissModalViewControllerAnimated:NO];
    [[DataSource instance].tabBar showTabBarAnimated:NO];
    
    //if(self.isCheckInMode)
        [[DataSource instance].tabBar changeTabToIndex:0];
    
    [self.navigationController popToRootViewControllerAnimated:NO];
    */
    
    [self reviewSent];
    
    /*
    if(self.dishName == nil && self.dish != nil)
    {
        
        _isSendingReview = YES;
        
        RequestProcessor *requestProcessor = [[RequestProcessor alloc] init];
        requestProcessor.delegate = self;
        [requestProcessor addReviewForUUID:self.uuid 
                              restaurantId:self.restaurant.restaurantId
                          foursqareVenueID:self.foursquareVenueID
                                reviewText:reviewTextField.text 
                              reviewRating:[NSNumber numberWithFloat:_rating]
                            postOnFacebook:_postOnFacebook
                             postOnTwitter:_postOnTwitter
                                    dishId:[[self.dish objectForKey:@"id"] intValue]];
        [requestProcessor release];
    }
    else if(self.dishName != nil && self.dish == nil)
    {
        _isSendingReview = YES;
        
        RequestProcessor *requestProcessor = [[RequestProcessor alloc] init];
        requestProcessor.delegate = self;
        [requestProcessor addReviewForUUID:self.uuid 
                              restaurantId:self.restaurant.restaurantId
                          foursqareVenueID:self.foursquareVenueID
                                reviewText:reviewTextField.text 
                              reviewRating:[NSNumber numberWithFloat:_rating]
                            postOnFacebook:_postOnFacebook
                             postOnTwitter:_postOnTwitter
                                  dishName:self.dishName
                                    typeId:_typeId
                                 subtypeId:_subtypeId];
        [requestProcessor release];
    }
     */
}

- (void)reviewSent
{
    
    //self.photoRP.delegate = nil;
    
    _isSendingReview = NO;
    //[[DataSource instance] removeDraftWithUUID:self.uuid];
    
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    
    
    [DataSource instance].imageUUID = nil;
    [DataSource instance].reviewImage = nil;
    [[DataSource instance] cleanNewReviewData];
    [[DataSource instance].feedController scrollToTop];
    
    
    // No update
    //[[DataSource instance].feedController update];
    
    /*
    
    [ConvenientPopups showToastLikeMessage:@"Yay! Your review has been posted successfully!" 
                                    onView:[DataSource instance].tabBar.view];
    */
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"quickReviewPosted" object:nil];
    
    [self viewWillDisappear:NO];
    [[DataSource instance].tabBar dismissModalViewControllerAnimated:NO];
    [[DataSource instance].tabBar showTabBar];
    [[DataSource instance].tabBar changeTabToIndex:0];
    [self.navigationController popToRootViewControllerAnimated:NO];
}

#pragma mark -
#pragma mark IBActions

- (IBAction)deleteThisDraft:(id)sender
{
    AlertView* view = [[AlertView alloc] initWithTitle:@"" 
                                               message:@"Are you sure you want to delete this draft?"];
    
    
    [view addButtonWithTitle:@"Yes" block:[[^(AlertView* a, NSInteger i){
        [[DataSource instance] removeDraftWithUUID:self.uuid];
        [[DataSource instance].tabBar dismissModalViewControllerAnimated:NO];
        [[DataSource instance].tabBar showTabBar];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"updateDrafts" object:self userInfo:nil];
        [[DataSource instance] cleanNewReviewData];
    } copy] autorelease]];
    
    [view addButtonWithTitle:@"No" block:[[^(AlertView* a, NSInteger i){} copy] autorelease]];
    
    [view show];
    [view release];
}

- (IBAction)saveReviewToDrafts
{
    if([reviewTextField.text isEqualToString:@"For example: best dessert downtown"])
        reviewTextField.text = @"";
    
    [LoggerController logEvent:@"User saved a draft"];
    
    
    ReviewDraftModel *rdm = [[ReviewDraftModel alloc] init];
    rdm.reviewType = kReviewTypeDraft;
    rdm.checkinType = [DataSource instance].checkinType;
    rdm.taggedFriends = self.addedUsers;
    rdm.authorSystemID = [LoginController currentUserID];
    rdm.dishPrice = [DataSource instance].dishPrice;
    
    dlog(@"rdm.taggedFriends %@", rdm.taggedFriends);
    
    if(self.dishName == nil && self.dish != nil)
    {
        rdm.photoData = UIImageJPEGRepresentation([self.photo imageResizedToFit:kUploadPhotoSize 
                                                           interpolationQuality:kCGInterpolationHigh], 0.8);
        rdm.uuid = self.uuid;
        rdm.restaurantName = self.restaurant.name;
        
        if(self.restaurant.restaurantId)
            rdm.restaurantID = [NSNumber numberWithInt:self.restaurant.restaurantId];
        
        if(self.foursquareVenueID)
            rdm.foursquareVenueID = self.foursquareVenueID;
        
        rdm.reviewText = reviewTextField.text;
        rdm.reviewRating = [NSNumber numberWithFloat:_rating];      
        rdm.dishID = [self.dish objectForKey:@"id"];
        rdm.dishName = [self.dish objectForKey:@"name"];
    }
    else if(self.dishName != nil && self.dish == nil)
    {
        rdm.photoData = UIImageJPEGRepresentation([self.photo imageResizedToFit:kUploadPhotoSize 
                                                           interpolationQuality:kCGInterpolationHigh], 0.8);
        rdm.uuid = self.uuid;
        rdm.restaurantName = self.restaurant.name;
        
        if(self.restaurant.restaurantId)
            rdm.restaurantID = [NSNumber numberWithInt:self.restaurant.restaurantId];
        
        if(self.foursquareVenueID)
            rdm.foursquareVenueID = self.foursquareVenueID;
        
        rdm.reviewText = reviewTextField.text;
        rdm.reviewRating = [NSNumber numberWithFloat:_rating];
        rdm.dishName = self.dishName;
        rdm.typeID = [NSNumber numberWithInt:_typeId];
        rdm.subtypeID = [NSNumber numberWithInt:_subtypeId];
    }
    
    rdm.postOnFacebook = [NSNumber numberWithBool:_shareOnFacebook];
    rdm.postOnTwitter = [NSNumber numberWithBool:_shareOnTwitter];
    rdm.postOnPinterest = [NSNumber numberWithBool:_shareOnPinterest];
    
    [[DataSource instance] removeDraftWithUUID:rdm.uuid];
    [rdm saveToFile];
    [[DataSource instance] addUnloadedReview:rdm];
    
    [DataSource instance].imageUUID = nil;
    [DataSource instance].reviewImage = nil;
    [[DataSource instance] cleanNewReviewData];
    [[DataSource instance].feedController scrollToTop];
    
    
    [ConvenientPopups showToastLikeMessage:@"Your review has been saved to drafts - do not forget to send it!" 
                                    onView:[DataSource instance].tabBar.view];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updateDrafts" object:self userInfo:nil];

    //[self viewWillDisappear:NO];
    [[DataSource instance].tabBar dismissModalViewControllerAnimated:NO];
    [[DataSource instance].tabBar showTabBarAnimated:NO];
    
    if(self.isCheckInMode)
        [[DataSource instance].tabBar changeTabToIndex:4];
    
    [self.navigationController popToRootViewControllerAnimated:NO];
}

- (IBAction)dishIn
{
    dlog(@"dishIn rc %i", [self retainCount]);
    
    if(_isSendingReview)
        return;
    
    if(!(_rating > 0))
    {
        [ConvenientPopups showAlertWithTitle:@"" andMessage:@"Please set a rating before dishing in!"];
        return;
    }
    else if(self.restaurant == nil && !([DataSource instance].checkinType == kCheckInListTypeFriends))
    {
        [ConvenientPopups showAlertWithTitle:@"" andMessage:@"Please choose a restaurant before dishing in!"];
        return;
    }
    
    if(self.dish == nil && self.dishName == nil)
    {
        [ConvenientPopups showAlertWithTitle:@"" andMessage:@"Please choose a dish before dishing in!"];
        return;
    }
    else
    {
        [self.navigationItem setHidesBackButton:YES animated:YES];
        
        [ConvenientPopups showNonBlockingPopupOnView:self.view withText:@"We're dishing in..."];
        
        _isDishInClicked = YES;
        
        //if(_photoIsLoaded)
            [self sendReview];
    }
}

- (IBAction)addFriendsClick:(id)sender
{
    [LoggerController logEvent:@"User tagged friends"];
    
    AddFriendsVC *addFriendsVC = [[AddFriendsVC alloc] init];
    addFriendsVC.delegate = self;
    addFriendsVC.navigationItem.hidesBackButton = YES;
    [self.navigationController pushViewController:addFriendsVC animated:YES];
    [addFriendsVC release];
}

- (IBAction)changeFacebookPosting:(UIButton *)sender
{
    if(!_shareOnFacebook)
    {
        if(![LoginController isFacebookBinded])
        {
            AlertView* view = [[AlertView alloc] initWithTitle:@"" 
                                                       message:@"Your facebook account is not binded, do you want to bind it?"];
            
            [view addButtonWithTitle:@"No" block:[[^(AlertView* a, NSInteger i){} copy] autorelease]];
            
            [view addButtonWithTitle:@"Yes" block:[[^(AlertView* a, NSInteger i){
                [LoginController instance].delegate = nil;
                [LoginController instance].socialNetworkBindingMode = YES;
                [[LoginController instance]  loginWithFacebook];
            } copy] autorelease]];
            
            [view show];
            [view release];
            
            return;
        }
        
        [LoggerController logEvent:@"User enabled facebook"];
    }
    
    _shareOnFacebook = !_shareOnFacebook;
    sender.selected = !sender.selected;
}

- (IBAction)changeTwitterPosting:(UIButton *)sender
{
    if(!_shareOnTwitter)
    {
        if(![LoginController isTwitterBinded])
        {
            AlertView* view = [[AlertView alloc] initWithTitle:@"" 
                                                       message:@"Your twitter account is not binded, do you want to bind it?"];
            
            [view addButtonWithTitle:@"No" block:[[^(AlertView* a, NSInteger i){} copy] autorelease]];
            
            [view addButtonWithTitle:@"Yes" block:[[^(AlertView* a, NSInteger i){
                [LoginController instance].delegate = nil;
                [LoginController instance].socialNetworkBindingMode = YES;
                [[LoginController instance]  loginWithTwitter];
            } copy] autorelease]];
            
            [view show];
            [view release];
            
            return;
        }
        
        [LoggerController logEvent:@"User enabled twitter"];
    }
    
    _shareOnTwitter = !_shareOnTwitter;
    sender.selected = !sender.selected;
}

- (IBAction)changePinterestPosting:(UIButton *)sender
{    
    _shareOnPinterest = !_shareOnPinterest;
    sender.selected = !sender.selected;
}

- (IBAction)chooseRestaurant
{	
    [reviewTextField resignFirstResponder];
    
	RestaurantListController *restaurantListController = [[RestaurantListController alloc] init];
    restaurantListController.isShortList = YES;
	restaurantListController.delegate = self;
	[self.navigationController pushViewController:restaurantListController animated:YES];
	[restaurantListController release];
}

- (IBAction)chooseDish
{
    [reviewTextField resignFirstResponder];
    
    if([DataSource instance].checkinType == kCheckInListTypeFriends)
    {
        AddDishController *addDishController = [[AddDishController alloc] initWithDishName:@""];
        addDishController.delegate = self;
        [self.navigationController pushViewController:addDishController animated:YES];
        [addDishController release];
        return;
    }
    
    if(self.restaurant)
    {
        MenuController *menuController = [[MenuController alloc] initWithRestaurant:self.restaurant];
        menuController.checkinMode = YES;
        menuController.delegate = self;
        [self.navigationController pushViewController:menuController animated:YES];
        [menuController release];
    }
    else
        [ConvenientPopups showAlertWithTitle:@"" andMessage:@"Please select a restaurant first!"];
}


#pragma mark -
#pragma mark TextView delegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if([textView.text isEqualToString:@"For example: best dessert downtown"])
    {
        textView.text = @"";
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range 
 replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"]) 
    {
        [textView resignFirstResponder];
        
        return NO;
    }

    return YES;
}

- (void) animateTextField: (UITextField*) textField up: (BOOL) up
{
    const int movementDistance = 210; // tweak as needed
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations: @"animations" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}





#pragma mark -
#pragma mark RequestProcessor delegate

-(void)requestProcessorSuccessCallback:(RequestProcessor *) requestProcessor
{	
    if(requestProcessor == self.photoRP)
    {
        self.photoRP = nil;
        
        _photoIsLoaded = YES;
        
        if(_isDishInClicked)
            [self sendReview];
        
        return;
    }
    else
    {
        if(self.photoRP == nil)
        {
            [self reviewSent];
        }
    }
}

- (void)requestProcessorFailedCallback:(RequestProcessor *)requestProcessor
{
    [self.navigationItem setHidesBackButton:NO animated:YES];
    
    if(requestProcessor == self.photoRP)
    {
        self.photoRP = nil;
        [ConvenientPopups showAlertWithTitle:@"Error" andMessage:@"Your photo can't be uploaded to server - please try again with faster connection"];
        return;
    }
    else
    {
        _isSendingReview = NO;
    
        [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    }
}

@end
