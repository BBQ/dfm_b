#import "DataSource.h"
#import "Config.h"
#import "RequestProcessor.h"
#import "Crittercism.h"
#import "LoggerController.h"
#import "FeedItemModel.h"
@interface DataSource() 
{
@private
    NSOperationQueue *_operationQueue;
}
@end

@implementation DataSource

@synthesize topLevelScreens;
@synthesize numberOfNotifications;

@synthesize openedWithPushTokenBadge;
@synthesize tabBar, 
            lastImagePickerSourceType,
            feedController,
            newReviewNavController,
            APIBaseURL,
            imageBaseURL,
            dishTypes,
            locationNoticeIsShown;

@synthesize searchTips;
@synthesize restaurantSearchTips;
@synthesize keywords;
@synthesize objMan;

@synthesize restaurantName;
@synthesize restaurantID;
@synthesize restaurantFoursquareVenueID;
@synthesize dishName;
@synthesize dishPrice;
@synthesize dishID;
@synthesize imageUUID;
@synthesize reviewImage;
@synthesize homeCookedFriends;
@synthesize delivery;

@synthesize updateTimestamp;
@synthesize pushToken;
@synthesize checkinType;
@synthesize homeCookedPlace;

@synthesize helpScreensShown;
@synthesize lastChosenRestaurant;
@synthesize unloadedReviews;
@synthesize unloadedReviewsUUIDs;
@synthesize photoLoadingQueue;
@synthesize photoRPs;
@synthesize progressViews;
@synthesize addedUsers;
@synthesize shareOnFacebook;
@synthesize shareOnTwitter;
@synthesize shareOnPinterest;

static DataSource *sharedSingleton;

- (id)init
{
    self = [super init];
    if(self)
    {
        _operationQueue = [[NSOperationQueue alloc] init];
    }
    return self;
}
        
+ (DataSource *)instance
{
	return sharedSingleton;
}

+ (void)initialize
{
    static BOOL initialized = NO;

    if(!initialized)
    {
        initialized = YES;
		
		sharedSingleton = [[DataSource alloc] init];
        sharedSingleton.APIBaseURL = kProductionAPIBaseURL;
        sharedSingleton.imageBaseURL = kProductionImageBaseURL;
        sharedSingleton.locationNoticeIsShown = NO;
        //sharedSingleton.openedWithPushTokenBadge = NO;

        
        sharedSingleton.topLevelScreens = [[[NSMutableArray alloc] init] autorelease];
        sharedSingleton.unloadedReviews = [[[NSMutableArray alloc] init] autorelease];
        sharedSingleton.unloadedReviewsUUIDs = [[[NSMutableArray alloc] init] autorelease];
        sharedSingleton.photoLoadingQueue = [[[NSMutableArray alloc] init] autorelease];
        sharedSingleton.photoRPs = [[[NSMutableArray alloc] init] autorelease];
        sharedSingleton.progressViews = [[[NSMutableDictionary alloc] init] autorelease];
        
        sharedSingleton.objMan = [[HJObjManager alloc] initWithLoadingBufferSize:24 memCacheSize:24];
		NSString* cacheDirectory = [NSHomeDirectory() stringByAppendingString:kImageChachePathSuffix];
		HJMOFileCache* fileCache = [[[HJMOFileCache alloc] initWithRootPath:cacheDirectory] autorelease];
        fileCache.fileCountLimit = 200;
        fileCache.fileAgeLimit = 60*60*24*7; //one week
		sharedSingleton.objMan.fileCache = fileCache;
        
        [sharedSingleton loadFromFile];
    }
}

- (void)loadFromFile
{		
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	
	NSString *dishTypesFile = [documentsDirectory stringByAppendingPathComponent: @"dishTypes.plist"];
    NSString *searchTipsFile = [documentsDirectory stringByAppendingPathComponent: @"searchTips.plist"];
    NSString *keywordsFile = [documentsDirectory stringByAppendingPathComponent: @"keywords.plist"];
    NSString *restaurantSearchTipsFile = [documentsDirectory stringByAppendingPathComponent: @"restaurantSearchTips.plist"];
    NSString *updateTimestampFile = [documentsDirectory stringByAppendingPathComponent: @"updateTimestamp.plist"];
    NSString *pushTokenFile = [documentsDirectory stringByAppendingPathComponent: @"pushToken.plist"];
    NSString *helpScreensShownFile = [documentsDirectory stringByAppendingPathComponent: @"helpScreensShown.plist"];
    
    
	NSFileManager *fileManager = [NSFileManager defaultManager];
        
	if ([fileManager fileExistsAtPath:dishTypesFile]) 
	{
		self.dishTypes = [NSMutableArray arrayWithContentsOfFile:dishTypesFile];
	}    
    
    if ([fileManager fileExistsAtPath:searchTipsFile]) 
	{
		self.searchTips = [NSMutableArray arrayWithContentsOfFile:searchTipsFile];
	}
    
    if ([fileManager fileExistsAtPath:keywordsFile]) 
	{
		self.keywords = [NSMutableArray arrayWithContentsOfFile:keywordsFile];
	}
    
    if ([fileManager fileExistsAtPath:restaurantSearchTipsFile]) 
	{
		self.restaurantSearchTips = [NSMutableArray arrayWithContentsOfFile:restaurantSearchTipsFile];
	}
    
    if ([fileManager fileExistsAtPath:updateTimestampFile]) 
	{
        NSString *updateTimestampString = [NSString stringWithContentsOfFile:updateTimestampFile 
                                                                   encoding:NSUTF8StringEncoding 
                                                                      error:nil];

        NSNumberFormatter * f = [[NSNumberFormatter alloc] init];
        [f setNumberStyle:NSNumberFormatterDecimalStyle];
        self.updateTimestamp = [f numberFromString:updateTimestampString];
        [f release];
        
        dlog(@"updateTimestampString %@ updateTimestamp %@,", updateTimestampString, updateTimestamp);
	}
    else
    {
        dlog(@"updateTimestamp failed");
    }
    
    if ([fileManager fileExistsAtPath:pushTokenFile]) 
	{
        self.pushToken = [NSString stringWithContentsOfFile:pushTokenFile 
                                                   encoding:NSUTF8StringEncoding 
                                                      error:nil];
	}
    
    if ([fileManager fileExistsAtPath:helpScreensShownFile]) 
	{
		self.helpScreensShown = [NSMutableDictionary dictionaryWithContentsOfFile:helpScreensShownFile];
	}
    else
    {
        self.helpScreensShown = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                 [NSNumber numberWithBool:NO], @"feed_screen",
                                 [NSNumber numberWithBool:NO], @"dishes_screen",
                                 [NSNumber numberWithBool:NO], @"restaurants_screen",
                                 [NSNumber numberWithBool:NO], @"map_screen",
                                 [NSNumber numberWithBool:NO], @"profile_screen",
                                 nil];
    }

    [self loadUnloadedReviewsFromFile];
    
    BOOL needsUpdating;
    
    /*
    if(self.dishTypes == nil)
        needsUpdating = YES;
    else
    {
        if(self.updateTimestamp)
            needsUpdating = [updateTimestamp doubleValue] + 60*60*24*30 < [[NSDate date] timeIntervalSince1970];
        else
            needsUpdating = YES;
    }
    
    if(self.searchTips == nil)
        needsUpdating = YES;
    */
    
    //uncomment for testing
    needsUpdating = YES;

    if(needsUpdating)
    {
        [self refreshCommonData];
    }
}

- (void)refreshCommonData
{
    RequestProcessor *requestProcessor = [[RequestProcessor alloc] init];
    requestProcessor.delegate = self;
    [requestProcessor updateCommonDataAfterTimeStamp:self.updateTimestamp];
    [requestProcessor release];
}

- (void)saveToFile
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	
	NSString *dishTypesFile = [documentsDirectory stringByAppendingPathComponent: @"dishTypes.plist"];
    NSString *searchTipsFile = [documentsDirectory stringByAppendingPathComponent: @"searchTips.plist"];
    NSString *keywordsFile = [documentsDirectory stringByAppendingPathComponent: @"keywords.plist"];
    NSString *restaurantSearchTipsFile = [documentsDirectory stringByAppendingPathComponent: @"restaurantSearchTips.plist"];
    NSString *updateTimestampFile = [documentsDirectory stringByAppendingPathComponent: @"updateTimestamp.plist"];
    NSString *pushTokenFile = [documentsDirectory stringByAppendingPathComponent: @"pushToken.plist"];
    NSString *helpScreensShownFile = [documentsDirectory stringByAppendingPathComponent: @"helpScreensShown.plist"];
    
    if(self.dishTypes)
        [self.dishTypes writeToFile:dishTypesFile atomically:NO];
    
    if(self.searchTips)
        [self.searchTips writeToFile:searchTipsFile atomically:NO];
    
    if(self.keywords)
        [self.keywords writeToFile:keywordsFile atomically:NO];
    
    if(self.restaurantSearchTips)
        [self.restaurantSearchTips writeToFile:restaurantSearchTipsFile atomically:NO];
    
    if(self.updateTimestamp)
        [[self.updateTimestamp stringValue] writeToFile:updateTimestampFile 
                                             atomically:NO 
                                               encoding:NSUTF8StringEncoding 
                                                  error:nil];
    if(self.pushToken)
        [self.pushToken writeToFile:pushTokenFile atomically:NO encoding:NSUTF8StringEncoding error:nil];
    
    if(self.helpScreensShown)
        [self.helpScreensShown writeToFile:helpScreensShownFile atomically:NO];
}


#pragma mark - RequestProcessor delegate

- (void)requestProcessorSuccessCallback:(RequestProcessor *)processor
{
    if(self.dishTypes == nil)
    {
        self.dishTypes = [[NSMutableArray alloc] init];
        [self.dishTypes release];
    }
    
    if(self.searchTips == nil)
    {
        self.searchTips = [[NSMutableArray alloc] init];
        [self.searchTips release];
    }
    
    if(self.keywords == nil)
    {
        self.keywords = [[NSMutableArray alloc] init];
        [self.keywords release];
    }
    
    if(self.restaurantSearchTips == nil)
    {
        self.restaurantSearchTips = [[NSMutableArray alloc] init];
        [self.restaurantSearchTips release];
    }
    
    NSArray *typesArray = [processor.processedJSON objectForKey:@"types"];
    
    
    if([typesArray isKindOfClass:[NSArray class]] && [typesArray count])
    {
        [self.dishTypes removeAllObjects];
        for(id type in typesArray)
        {
            NSDictionary *typeContents = [type objectForKey:@"type"];
            if([typeContents isKindOfClass:[NSDictionary class]])
            {
                [self.dishTypes addObject:typeContents];
            }
        }

        //[self.dishTypes setObject:[NSNumber numberWithDouble:[[NSDate date] timeIntervalSince1970]] forKey:@"update_timestamp"];
        
        unsigned long int timestampInt = (unsigned long int) [[NSDate date] timeIntervalSince1970];
        self.updateTimestamp = [NSNumber numberWithUnsignedLong:timestampInt];
        
        //dlog(@"self.dishTypes %@", self.dishTypes);
    }
    
    
    //dish name search tips
    NSArray *tipsArray = [processor.processedJSON objectForKey:@"tags"];
    BOOL dishTipsNeedToCheckDuplicates = self.searchTips && [self.searchTips count];
    
    if([tipsArray isKindOfClass:[NSArray class]])
    {
        for(NSDictionary *tip in tipsArray)
        {
            if([tip isKindOfClass:[NSDictionary class]])
            {
                if(dishTipsNeedToCheckDuplicates)
                {
                    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@", [tip objectForKey:@"name"]];
                    NSArray *filteredArray = [self.searchTips filteredArrayUsingPredicate:predicate];
                    if([filteredArray count])
                    {
                        NSDictionary *oldElement = [filteredArray objectAtIndex:0];
                        if([[oldElement objectForKey:@"id"] isEqual:[tip objectForKey:@"id"]])
                            continue;
                        else
                            [oldElement setValue:[tip objectForKey:@"id"] forKey:@"id"];
                    }
                }
                else
                    [self.searchTips addObject:tip];
            }
        }
    }
    
    //keywords
    NSMutableArray *keywordsArray = [processor.processedJSON objectForKey:@"keywords"];

    if([keywordsArray isKindOfClass:[NSArray class]] && [keywordsArray count])
    {
        [self.keywords removeAllObjects];
        
        [self.keywords addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"All", @"name", 
                                  [NSNumber numberWithInt:0], @"id", nil]];
        
        for(NSDictionary *keyword in keywordsArray)
        {
            NSDictionary *keywordContents = [keyword objectForKey:@"tag"];
            if([keywordContents isKindOfClass:[NSDictionary class]])
                [self.keywords addObject:keywordContents];
        }
    }

    //restaurant name search tips
    NSArray *restaurantTipsArray = [processor.processedJSON objectForKey:@"restaurant_categories"];
    BOOL restaurantTipsNeedToCheckDuplicates = self.restaurantSearchTips && [self.restaurantSearchTips count];
    
    if([restaurantTipsArray isKindOfClass:[NSArray class]])
    {
        for(NSDictionary *tip in restaurantTipsArray)
        {
            NSDictionary *tipContents = [tip objectForKey:@"restaurant_category"];
            if([tipContents isKindOfClass:[NSDictionary class]])
            {
                if(restaurantTipsNeedToCheckDuplicates)
                {
                    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@", [tipContents objectForKey:@"name"]];
                    NSArray *filteredArray = [self.restaurantSearchTips filteredArrayUsingPredicate:predicate];
                    if([filteredArray count])
                        continue;
                }
                else
                    [self.restaurantSearchTips addObject:tipContents];
            }
        }
    }
    
    //old variant
    /*
    NSArray *restaurantTipsArray = [processor.processedJSON objectForKey:@"networks"];
    BOOL restaurantTipsNeedToCheckDuplicates = self.restaurantSearchTips && [self.restaurantSearchTips count];
    
    if([restaurantTipsArray isKindOfClass:[NSArray class]])
    {
        for(NSDictionary *tip in restaurantTipsArray)
        {
            NSDictionary *tipContents = [tip objectForKey:@"network"];
            if([tipContents isKindOfClass:[NSDictionary class]])
            {
                if(restaurantTipsNeedToCheckDuplicates)
                {
                    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@", [tipContents objectForKey:@"name"]];
                    NSArray *filteredArray = [self.restaurantSearchTips filteredArrayUsingPredicate:predicate];
                    if([filteredArray count])
                    {
                        NSDictionary *oldElement = [filteredArray objectAtIndex:0];
                        if([[oldElement objectForKey:@"id"] isEqual:[tipContents objectForKey:@"id"]])
                            continue;
                        else
                            [oldElement setValue:[tipContents objectForKey:@"id"] forKey:@"id"];
                    }
                }
                else
                    [self.restaurantSearchTips addObject:tipContents];
            }
        }
    }
    */
    //dlog(@"self.restaurantSearchTips %@", self.restaurantSearchTips);
    
    
    // Force logout
    NSNumber *forceLogout = [processor.processedJSON objectForKey:@"force_logout"];
    if([forceLogout isKindOfClass:[NSNumber class]] && [forceLogout boolValue])
        [[LoginController instance] logout];
    
    [self saveToFile];
}

- (void)requestProcessorFailedCallback:(RequestProcessor *)processor
{
    
}

//checks if user tapped add new review from restaurant page
- (BOOL)isRestaurantInfoAvailable
{
    if([DataSource instance].restaurantName)
        if([DataSource instance].restaurantID || [DataSource instance].restaurantFoursquareVenueID)
            return YES;
    
    return NO;
}

//checks if user tapped add new review from dish page
- (BOOL)isNewReviewDataAvailable
{
    if ([DataSource instance].restaurantName && [DataSource instance].restaurantID && [DataSource instance].dishName)
        return YES;
    
    if([DataSource instance].checkinType == kCheckInListTypeFriends &&
       [DataSource instance].homeCookedPlace &&
       [DataSource instance].dishName &&
       [DataSource instance].dishID
       )
        return YES;
        
    return NO;
}

- (void)cleanNewReviewData
{
    [DataSource instance].imageUUID = nil;
    [DataSource instance].restaurantName = nil;
    [DataSource instance].restaurantID = nil;
    [DataSource instance].restaurantFoursquareVenueID = nil;
    [DataSource instance].dishName = nil;
    [DataSource instance].dishID = -1;
    [DataSource instance].homeCookedFriends = nil;
    [DataSource instance].delivery = NO;
    [DataSource instance].dishPrice = nil;
    [DataSource instance].homeCookedPlace = nil;
    [DataSource instance].reviewImage = nil;
    [DataSource instance].addedUsers = nil;
    [DataSource instance].shareOnTwitter = nil;
    [DataSource instance].shareOnFacebook = nil;
}

+ (NSArray *)keywordNames
{
    NSMutableArray *keywordNames = [NSMutableArray array];
    
    for(NSDictionary *keyword in sharedSingleton.keywords)
    {
        NSString *keywordName = [keyword objectForKey:@"name"];
        if([keywordName isKindOfClass:[NSString class]])
            [keywordNames addObject:keywordName];
    }
    
    return keywordNames;
}

#define kScreenIndexes [NSArray arrayWithObjects:@"feed_screen", @"dishes_screen", \
    @"restaurants_screen", @"map_screen", @"profile_screen", nil]

+ (void)showHelpScreen:(NSString *)screenName
{
    [self showHelpScreen:screenName
                  onView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
}    

+ (void)showHelpScreen:(NSString *)screenName
                onView:(UIView *)view
{
    NSDictionary *imageNames = [NSDictionary dictionaryWithObjectsAndKeys:
                                @"helpScreens-01.jpg", @"feed_screen",
                                @"helpScreens-02.jpg", @"dishes_screen",
                                @"helpScreens-03.jpg", @"restaurants_screen",
                                @"helpScreens-04.jpg", @"map_screen",
                                @"helpScreens-05.jpg", @"profile_screen",
                                nil];
    
    if(![[sharedSingleton.helpScreensShown objectForKey:screenName] boolValue])
    {
        UIWindow *baseView = [[[UIApplication sharedApplication] windows] objectAtIndex:0];

        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, baseView.bounds.size.width, baseView.bounds.size.height);
        [button addTarget:sharedSingleton 
                   action:@selector(makeHelpScreenVisible:) 
         forControlEvents:UIControlEventTouchUpInside];
        button.tag = [kScreenIndexes indexOfObject:screenName];
        
        if(view == baseView)
        {
            UIImage *image = [UIImage imageNamed:[imageNames objectForKey:screenName]];
            UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, baseView.bounds.size.width, baseView.bounds.size.height)];
            iv.image = image;
            iv.alpha = 0.0f;
            [button addSubview:iv];
            [iv release];
            
            
            if([[DataSource instance].topLevelScreens count])
            {
                [baseView insertSubview:button belowSubview:[[DataSource instance].topLevelScreens lastObject]];
            }
            else
            {
                [baseView addSubview:button];
            }
            
            [[DataSource instance].topLevelScreens addObject:button];
        }
        else
        {
            UIImage *image = [UIImage imageNamed:[imageNames objectForKey:screenName]];
            UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
            iv.image = image;
            iv.alpha = 0.0f;
            [button addSubview:iv];
            [iv release];
            
            [view addSubview:button];
        }
    }
}

- (void)makeHelpScreenVisible:(UIButton *)button
{
    [[DataSource instance].topLevelScreens removeObject:button];
    
    [button removeTarget:self action:nil forControlEvents:UIControlEventAllEvents];
    [button addTarget:sharedSingleton action:@selector(removeHelpScreen:) forControlEvents:UIControlEventTouchUpInside];
    
    UIImageView *iv = nil;
    for(UIImageView *view in button.subviews)
        if([view isKindOfClass:[UIImageView class]])
            iv = view;
    
    [UIView animateWithDuration:1.0f 
                     animations:^{
                         iv.alpha = 1.0f;
                     }];  
}
- (void)removeHelpScreen:(UIButton *)sender
{
    [UIView animateWithDuration:1.0f 
                     animations:^{
                         sender.alpha = 0.0f;
                     } 
                     completion:^(BOOL finished) {
                         [self.helpScreensShown setObject:[NSNumber numberWithBool:YES] 
                                                   forKey:[kScreenIndexes objectAtIndex:sender.tag]];
                         [self saveToFile];
                         [sender removeFromSuperview];
                     }];
}

#pragma mark - Reviews Handling

#pragma mark - Photo uploading

// self.photoLoadingQueue statuses: loading, loaded, failed

- (void)addReviewPhotoDataToQueue:(NSData *)photoData
                         withUUID:(NSString *)uuid
{

    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                 uuid, @"uuid",
                                 @"loading", @"state",
                                 nil];
    [self.photoLoadingQueue addObject:dict];
    
    NSBlockOperation *newop = [NSBlockOperation blockOperationWithBlock:^{
        
        RequestProcessor *photoRP = [[RequestProcessor alloc] init];
        photoRP.delegate = self;
        photoRP.updateProgressDelegate = self;
        photoRP.successCallback = @selector(photoLoaded:);
        photoRP.failCallback = @selector(photoFailedToLoad:);
        photoRP.additionalInfo = uuid;
        [photoRP addPhotoWithData:photoData
                      withUUID:uuid];
        [self.photoRPs addObject:photoRP];
        [photoRP release];
    }];
    
    [_operationQueue addOperation:newop];

}

- (void)photoLoaded:(RequestProcessor *)rp
{
    [self.photoRPs removeObject:rp];
    
    NSString *uuid = (NSString *) rp.additionalInfo;
    
    if(![uuid isKindOfClass:[NSString class]])
        return;
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.uuid == %@", uuid];
    
    NSArray *filteredArray = [self.photoLoadingQueue filteredArrayUsingPredicate:predicate];
    if([filteredArray count])
    {
        [[filteredArray objectAtIndex:0] setObject:@"loaded" forKey:@"state"];
        
        
    }
    
    // Begin to load review for this photo if it's in queue
    predicate = [NSPredicate predicateWithFormat:@"SELF.uuid == %@", (NSString *) uuid];
    filteredArray = [self.unloadedReviews filteredArrayUsingPredicate:predicate];
    if([filteredArray count])
    {
        ReviewDraftModel *rdm = (ReviewDraftModel *)[filteredArray objectAtIndex:0];
        rdm.reviewStatus = kReviewStatusLoading;
        [self beginToLoadReview:rdm];
    }
}

- (void)photoFailedToLoad:(RequestProcessor *)rp
{
    [self.photoRPs removeObject:rp];
    
    NSString *uuid = (NSString *) rp.additionalInfo;
    
    if(![uuid isKindOfClass:[NSString class]])
        return;
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.uuid == %@", uuid];
    
    NSArray *filteredArray = [self.photoLoadingQueue filteredArrayUsingPredicate:predicate];
    if([filteredArray count])
    {
        [[filteredArray objectAtIndex:0] setObject:@"failed" forKey:@"state"];   
    }
    
    // Set review loading status to failed
    predicate = [NSPredicate predicateWithFormat:@"SELF.uuid == %@", (NSString *) uuid];
    filteredArray = [self.unloadedReviews filteredArrayUsingPredicate:predicate];
    if([filteredArray count])
    {
        ReviewDraftModel *rdm = (ReviewDraftModel *)[filteredArray objectAtIndex:0];
        rdm.reviewStatus = kReviewStatusFailed;
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updateLoadingReviews" object:self userInfo:nil];
}

#pragma mark - Review uploading

- (void)beginToLoadReview:(ReviewDraftModel *)review
{
    NSBlockOperation *newop = [NSBlockOperation blockOperationWithBlock:^{
        [LoggerController logEvent:@"User dished in"];
        
        RequestProcessor *requestProcessor = [[RequestProcessor alloc] init];
        requestProcessor.delegate = self;
        requestProcessor.successCallback = @selector(reviewLoaded:);
        requestProcessor.failCallback = @selector(reviewFailedToLoad:);
        requestProcessor.additionalInfo = review.uuid;
        
        requestProcessor.updateProgressDelegate = self;
        
        review.reviewStatus = kReviewStatusLoading;
        
        
        
        // Check in type
        sharedSingleton.checkinType = review.checkinType;
        
        
        /*
         Add tagged friends
         TODO: refactor!
         */
        
        if(![DataSource instance].homeCookedFriends)
        {
            [DataSource instance].homeCookedFriends = [[NSMutableDictionary alloc] init];
            
            NSMutableArray *fb = [[NSMutableArray alloc] init];
            NSMutableArray *tw = [[NSMutableArray alloc] init];
            
            [[DataSource instance].homeCookedFriends setObject:tw
                                                        forKey:@"twitter"];
            [[DataSource instance].homeCookedFriends setObject:fb
                                                        forKey:@"facebook"];
            
            [fb release];
            [tw release];
        }
        
        NSMutableArray *fb = [[DataSource instance].homeCookedFriends objectForKey:@"facebook"];
        NSMutableArray *tw = [[DataSource instance].homeCookedFriends objectForKey:@"twitter"];
        
        [fb removeAllObjects];
        [tw removeAllObjects];
                
        for(NSDictionary *currentUser in review.taggedFriends)
        {
            //NSStrings OR NSNumbers!
            NSString *currentFacebook = [currentUser objectForKey:@"facebook"];
            NSString *currentTwitter = [currentUser objectForKey:@"twitter"];
            
            if([currentFacebook intValue])
            {
                [fb addObject:currentFacebook];
                
                continue; //facebook preference for time being
            }
            
            if([currentTwitter intValue])
            {
                [tw addObject:currentTwitter];
            }
        }
        
        // Dish price
        [DataSource instance].dishPrice = review.dishPrice;
        
        if(review.dishID != nil)
        {
            [requestProcessor addReviewForUUID:review.uuid 
                                  restaurantId:[review.restaurantID intValue]
                              foursqareVenueID:review.foursquareVenueID
                                    reviewText:review.reviewText 
                                  reviewRating:review.reviewRating
                                postOnFacebook:[review.postOnFacebook intValue]
                                 postOnTwitter:[review.postOnTwitter intValue]
                                        dishId:[review.dishID intValue]];
        }
        else if(review.dishName != nil)
        {   
            [requestProcessor addReviewForUUID:review.uuid 
                                  restaurantId:[review.restaurantID intValue]
                              foursqareVenueID:review.foursquareVenueID
                                    reviewText:review.reviewText 
                                  reviewRating:review.reviewRating
                                postOnFacebook:[review.postOnFacebook intValue]
                                 postOnTwitter:[review.postOnTwitter intValue]
                                      dishName:review.dishName
                                        typeId:[review.typeID intValue]
                                     subtypeId:[review.subtypeID intValue]];   
        }
        
        [requestProcessor release];
    }];
    
    [_operationQueue addOperation:newop];
}



- (void)reviewLoaded:(RequestProcessor *)rp
{
    if(![rp.additionalInfo isKindOfClass:[NSString class]])
        return;
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.uuid == %@", (NSString *) rp.additionalInfo];
    
    NSArray *filteredArray = [self.photoLoadingQueue filteredArrayUsingPredicate:predicate];
    if([filteredArray count])
    {
        [self.photoLoadingQueue removeObject:[filteredArray objectAtIndex:0]];
    }
    
    predicate = [NSPredicate predicateWithFormat:@"SELF.uuid == %@", (NSString *) rp.additionalInfo];
    filteredArray = [self.unloadedReviews filteredArrayUsingPredicate:predicate];
    if([filteredArray count])
    {
        ReviewDraftModel *rdm = (ReviewDraftModel *)[filteredArray objectAtIndex:0];
        rdm.reviewStatus = kReviewStatusLoaded;

        FeedItemModel *fim = [[FeedItemModel alloc] initWithReviewDraftModel:rdm];
        fim.reviewId = [[rp.processedJSON objectForKey:@"review_id"] intValue];
        fim.dishId = [[rp.processedJSON objectForKey:@"dish_id"] intValue];

        [[NSNotificationCenter defaultCenter] postNotificationName:@"updateLoadingReviews" 
                                                            object:self
                                                          userInfo:[NSDictionary dictionaryWithObjectsAndKeys:fim, @"review", nil]];
        
        // Remove review info from disk without delay
        if([rdm.postOnPinterest boolValue])
        {
            rdm.reviewStatus = kReviewStatusLoaded;
            rdm.reviewID = [rp.processedJSON objectForKey:@"review_id"];
            [rdm saveToFile];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"updateLoadingReviews" object:self userInfo:nil];
        }
        else
            [self removeDraftWithUUID:(NSString *) rp.additionalInfo];
    }
}

- (void)reviewFailedToLoad:(RequestProcessor *)rp
{
    dlog(@"reviewFailedToLoad %@", rp.processedJSON);
    
    if(![rp.additionalInfo isKindOfClass:[NSString class]])
        return;
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.uuid == %@", (NSString *) rp.additionalInfo];
    
    NSArray *filteredArray = [self.unloadedReviews filteredArrayUsingPredicate:predicate];
    if([filteredArray count])
    {
        ReviewDraftModel *rdm = (ReviewDraftModel *)[filteredArray objectAtIndex:0];
        rdm.reviewStatus = kReviewStatusFailed;
        [rdm saveToFile];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updateLoadingReviews" object:self userInfo:nil];
}

- (void)addUnloadedReview:(ReviewDraftModel *)review
{
    if(review.reviewType == kReviewTypeDraft)
    {
        // Nothing?
    }
    else if(review.reviewStatus == kReviewStatusUndefined ||
            review.reviewStatus == kReviewStatusLoading ||
            review.reviewStatus == kReviewStatusInQueue
    )
    {
        review.reviewStatus = kReviewStatusInQueue;
          
        // Check if photo loaded, is loading or in queue
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(SELF.uuid == %@) AND (SELF.state ==[c] %@)", review.uuid, @"loaded"];
        
        dlog(@"self.photoLoadingQueue %@", self.photoLoadingQueue);
        
        NSArray *filteredArray = [self.photoLoadingQueue filteredArrayUsingPredicate:predicate];
        if([filteredArray count])
        {
            [self beginToLoadReview:review];
        }
        else
        {
            // If photo failed to load - set failed status
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(SELF.uuid == %@) AND (SELF.state ==[c] %@)", review.uuid, @"failed"];
            
            NSArray *filteredArray = [self.photoLoadingQueue filteredArrayUsingPredicate:predicate];
            if([filteredArray count])
            {
                review.reviewStatus = kReviewStatusFailed;
            }
            else
            {
                // Photo is not in the queue - add it
                NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(SELF.uuid == %@) AND (SELF.state ==[c] %@)", review.uuid, @"loading"];
                NSArray *filteredArray = [self.photoLoadingQueue filteredArrayUsingPredicate:predicate];
                if(![filteredArray count])
                {
                    [self addReviewPhotoDataToQueue:review.photoData 
                                           withUUID:review.uuid];
                }
            }
        }
    }

    [self.unloadedReviews addObject:review];
    
    
    if([self.unloadedReviewsUUIDs indexOfObject:review.uuid] == NSNotFound)
        [self.unloadedReviewsUUIDs addObject:review.uuid];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	
	NSString *unloadedReviewsUDIDsfile = [documentsDirectory stringByAppendingPathComponent: @"review_uuids.plist"];

    dlog(@"self.unloadedReviewsUUIDs %@", self.unloadedReviewsUUIDs);
    dlog(@"unloadedReviewsUDIDsfile %@", unloadedReviewsUDIDsfile);
    
    [self.unloadedReviewsUUIDs writeToFile:unloadedReviewsUDIDsfile atomically:NO];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updateLoadingReviews" object:self userInfo:nil];
}

- (void)removeDraftWithUUID:(NSString *)uuid
{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.uuid == %@", uuid];
    
    NSArray *filteredArray = [self.unloadedReviews filteredArrayUsingPredicate:predicate];
    if([filteredArray count])
    {
        [self.unloadedReviews removeObject:[filteredArray objectAtIndex:0]];
        [self.unloadedReviewsUUIDs removeObject:uuid];
    }
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSString *unloadedReviewsUDIDsfile = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.plist", uuid]];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:unloadedReviewsUDIDsfile]) 
    {
        NSError *error;
        if ([fileManager removeItemAtPath:unloadedReviewsUDIDsfile error:&error] != YES)
        {
            dlog(@"Unable to delete file: %@", [error localizedDescription]);
            [Crittercism leaveBreadcrumb:[NSString stringWithFormat:@"Unable to delete file: %@", [error localizedDescription]]];
        }
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updateLoadingReviews" object:self userInfo:nil];
}


- (NSArray *)getReviewsWithType:(ReviewType)type
{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.reviewType == %i", type];
    return [self.unloadedReviews filteredArrayUsingPredicate:predicate];
}

- (NSArray *)getReviewsInLoadingQueue
{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(SELF.reviewType == %i) AND (SELF.reviewStatus !=[c] %@)", kReviewTypeNormal, @"loaded"];
    return [self.unloadedReviews filteredArrayUsingPredicate:predicate];
}

- (void)retryUploadingReviewWithIndex:(NSInteger)index
{
    ReviewDraftModel *review = [[self getReviewsInLoadingQueue] objectAtIndex:index];
    
    review.reviewStatus = kReviewStatusLoading;
    
    // Check if photo loaded, is loading or in queue
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(SELF.uuid == %@) AND (SELF.state ==[c] %@)", review.uuid, @"loaded"];
    
    NSArray *filteredArray = [self.photoLoadingQueue filteredArrayUsingPredicate:predicate];
    if([filteredArray count])
    {
        [self beginToLoadReview:review];
    }
    else
    {
        // Is photo already uploading?
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(SELF.uuid == %@) AND (SELF.state ==[c] %@)", review.uuid, @"loading"];
        
        NSArray *filteredArray = [self.photoLoadingQueue filteredArrayUsingPredicate:predicate];
        
        // If not - begin uploading
        if(![filteredArray count])
        {
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(SELF.uuid == %@)", review.uuid];
            NSArray *filteredArray = [self.photoLoadingQueue filteredArrayUsingPredicate:predicate];
            
            // Remove all photos from queue
            [self.photoLoadingQueue removeObjectsInArray:filteredArray];
            
            [self addReviewPhotoDataToQueue:review.photoData withUUID:review.uuid];
        }
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updateLoadingReviews" object:self userInfo:nil];
}

- (void)removeFromLoadingQueueItemWithIndex:(NSInteger)index
{
    ReviewDraftModel *review = [[self getReviewsInLoadingQueue] objectAtIndex:index];
    
    [self removeDraftWithUUID:review.uuid];
}


- (void)attachProgressView:(UIProgressView *)progressView toReviewWithUUID:(NSString *)uuid
{
    /*
    // Remove progressView from old RP if it's already used
    for(RequestProcessor *rp in self.photoRPs)
    {
        if(rp.progressView == progressView)
            rp.progressView = nil;
    }
    
    // Find request processor by UUID
    for(RequestProcessor *rp in self.photoRPs)
    {
        NSString *rpUUID = rp.additionalInfo;
        
        if(![rpUUID isKindOfClass:[NSString class]])
            continue;
        
        if([rpUUID isEqualToString:uuid])
            rp.progressView = progressView;
    }
     */
    
    [self.progressViews setObject:progressView forKey:uuid];
    
}

- (void)requestProcessor:(RequestProcessor *)rp updatedProgress:(NSNumber *)progressAmount
{
    /*
    if(rp.progressView)
    {
        if([self.photoRPs containsObject:rp])
            rp.progressView.progress = [progressAmount floatValue] * 0.75;
        else
            rp.progressView.progress = 0.75 + [progressAmount floatValue] * 0.25;
    }
     */
    NSString *uuid = (NSString *)rp.additionalInfo;
    if(![uuid isKindOfClass:[NSString class]])
        return;
    
    UIProgressView *progressView = [self.progressViews objectForKey:uuid];
    
    dlog(@"progressView %@ progressAmount %f", progressView, [progressAmount floatValue]);
    
    if([self.photoRPs containsObject:rp])
        progressView.progress = [progressAmount floatValue] * 0.75;
    else
        progressView.progress = 0.75 + [progressAmount floatValue] * 0.25;
}

- (void)loadUnloadedReviewsFromFile
{
    NSMutableArray *reviewsToRemove = [[NSMutableArray alloc] init];
    for(ReviewDraftModel *rdm in self.unloadedReviews)
    {
        if(rdm.reviewType == kReviewTypeDraft && ![rdm.authorSystemID isEqualToNumber:[LoginController currentUserID]])
            [reviewsToRemove addObject:rdm];
    }
    [self.unloadedReviews removeObjectsInArray:reviewsToRemove];
    [reviewsToRemove release];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *unloadedReviewsUDIDsfile = [documentsDirectory stringByAppendingPathComponent: @"review_uuids.plist"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:unloadedReviewsUDIDsfile]) 
	{
		NSMutableArray *unloadedReviewsUUIDsFromFile = [NSMutableArray arrayWithContentsOfFile:unloadedReviewsUDIDsfile];
        
        dlog(@"unloadedReviewsUUIDsFromFile %@", unloadedReviewsUUIDsFromFile);
        
        if([LoginController isLoggedIn] && [LoginController currentUserID])
        for(NSString *rdmUUID in unloadedReviewsUUIDsFromFile)
        {
            NSString *reviewFile = 
            [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.plist", rdmUUID]];
            ReviewDraftModel *rdm = [ReviewDraftModel modelWithContentsOfFile:reviewFile];
            
            if(rdm != nil && rdm.uuid != nil)
            {
                if([rdm.authorSystemID isEqualToNumber:[LoginController currentUserID]])
                    [self addUnloadedReview:rdm];
            }
            
        }
	}
}

@end