//
//  AdvancedSearchDelegate.h
//  dish.fm
//
//  Created by Petr Prokop on 1/19/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CheckinType.h"

@protocol AdvancedSearchDelegate <NSObject>

@property (nonatomic, copy) NSString *searchString;
@property (nonatomic, retain) NSString *searchSorting;
@property (nonatomic, retain) NSMutableArray *priceRanges;
@property (readwrite, assign) CheckinType checkInListType;
@property BOOL searchNextToMapArea;


- (void)setRangePage:(NSInteger)page;

@end