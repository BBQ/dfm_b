#import "FeedController.h"
#import "MainViewController.h"
#import "HJObjManager.h"
#import "RestaurantListController.h"
#import "RestaurantModel.h"
#import "ReviewDraftModel.h"

@interface DataSource : NSObject 
{

}

// Dialogs and help screens shoul be put there
@property (nonatomic, retain)   NSMutableArray *topLevelScreens;

//push notifications stuff
@property (readwrite, assign)   BOOL openedWithPushTokenBadge;
@property (nonatomic, retain)   NSString      *pushToken;
@property (readwrite, assign)   NSInteger numberOfNotifications;
           
           
@property (nonatomic, assign)   MainViewController  *tabBar;
@property (readwrite, assign)   UIImagePickerControllerSourceType lastImagePickerSourceType;
@property (nonatomic, assign)   FeedController      *feedController;
@property (nonatomic, assign)   UINavigationController *newReviewNavController;
@property (nonatomic, assign)   NSString            *APIBaseURL;
@property (nonatomic, assign)   NSString            *imageBaseURL;

@property (readwrite, assign)   BOOL                locationNoticeIsShown;

//search tips, keywords, etc...
@property (nonatomic, retain)   NSMutableArray      *dishTypes;
@property (nonatomic, retain)   NSMutableArray  *searchTips;
@property (nonatomic, retain)   NSMutableArray  *restaurantSearchTips;
@property (nonatomic, retain)   NSMutableArray  *keywords;
@property (nonatomic, retain)   NSNumber        *updateTimestamp;

@property (nonatomic, retain) HJObjManager *objMan;

//for adding review from dish
@property (nonatomic, retain)   NSString      *restaurantName;
@property (nonatomic, retain)   NSNumber      *restaurantID;
@property (nonatomic, retain)   NSString      *restaurantFoursquareVenueID;
@property (nonatomic, retain)   NSString      *dishName;
@property (nonatomic, retain)   NSNumber      *dishPrice;
@property (readwrite, assign)   NSInteger     dishID;
@property (nonatomic, retain)   NSString      *imageUUID;
@property (nonatomic, retain)   UIImage       *reviewImage;
//home-cooked
@property (nonatomic, retain)   NSMutableDictionary *homeCookedFriends;
//delivery
@property (readwrite, assign)   BOOL delivery;
//type
@property (readwrite, assign)   CheckinType     checkinType;
@property (nonatomic, retain)   NSString        *homeCookedPlace;

@property (nonatomic, retain)   NSMutableDictionary *helpScreensShown;
@property (nonatomic, retain)   NSNumber            *numberOfTimesLoaded;
@property (nonatomic, retain)   RestaurantModel     *lastChosenRestaurant;

// Drafts and reviews that haven't been uploaded successfully
@property (nonatomic, retain)   NSMutableArray      *unloadedReviews;
@property (nonatomic, retain)   NSMutableArray      *unloadedReviewsUUIDs;
@property (nonatomic, retain)   NSMutableArray      *photoLoadingQueue;
@property (nonatomic, retain)   NSMutableArray      *photoRPs;
@property (nonatomic, retain)   NSMutableDictionary *progressViews;
@property (nonatomic, retain)   NSMutableArray      *addedUsers;
@property (nonatomic, retain)   NSNumber            *shareOnFacebook;
@property (nonatomic, retain)   NSNumber            *shareOnTwitter;
@property (nonatomic, retain)   NSNumber            *shareOnPinterest;

+ (void)initialize;
+ (DataSource *)instance;

- (void)loadFromFile;
- (void)refreshCommonData;
- (void)saveToFile;

- (void)updateCommonData;

- (BOOL)isRestaurantInfoAvailable;
- (BOOL)isNewReviewDataAvailable;
- (void)cleanNewReviewData;

+ (NSArray *)keywordNames;
+ (void)showHelpScreen:(NSString *)screenName;
+ (void)showHelpScreen:(NSString *)screenName
                onView:(UIView *)view;

- (void)addUnloadedReview:(ReviewDraftModel *)review;
- (void)removeDraftWithUUID:(NSString *)uuid;
- (NSArray *)getReviewsWithType:(ReviewType)type;
- (NSArray *)getReviewsInLoadingQueue;
- (void)addReviewPhotoDataToQueue:(NSData *)photoData
                         withUUID:(NSString *)uuid;

- (void)retryUploadingReviewWithIndex:(NSInteger)index;
- (void)removeFromLoadingQueueItemWithIndex:(NSInteger)index;
- (void)attachProgressView:(UIProgressView *)progressView toReviewWithUUID:(NSString *)uuid;
- (void)loadUnloadedReviewsFromFile;

@end
