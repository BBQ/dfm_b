//#define kScrollViewFrame CGRectMake(0, 0, 320, 455)
//#define kScrollViewFrame CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height-49)
//#define kScrollViewFrame CGRectMake(0, -20-44, 320, 480)
#define kScrollViewFrame CGRectMake(0, 16, 320, 320)

//#define kScrollViewFrame CGRectMake(0, 0, 320, 480-2*(20+44))


#define kCropWindowFrame CGRectMake(0, 16, 320, 320)


#import "CropPhotoController.h"
#import "RequestProcessor.h"
#import "AddReviewController.h"
#import "DataSource.h"
#import "PickImageController.h"
#import "ConvenientPopups.h"
#import "UIImage+rotate.h"
#import "Config.h"
#import "Utils.h"
#import "MenuController.h"
#import "UIImage+Resize.h"
#import "LoggerController.h"
#import "UIImage+Resize_new.h"

@implementation CropPhotoController

@synthesize scrollView;
@synthesize imageView;
@synthesize photo;
@synthesize fullsizePhoto;

CGRect cropWindow;

- (void)dealloc 
{
    dlog(@"CropPhotoController dealloc");
    
    if(_restaurantListController)
    {
        [_restaurantListController release];
        _restaurantListController = nil;
    }
    
    self.scrollView = nil;
    self.imageView = nil; 
    self.fullsizePhoto = nil;
    
    dlog(@"self.photo  rc %i", [self.photo retainCount]);
    self.photo = nil;
    dlog(@"self.photo  rc %i", [self.photo retainCount]);
    
    [super dealloc];
}


- (id)initWithPhoto:(UIImage *)aPhoto
{
	self = [super initWithNibName:@"CropPhotoController" bundle:nil];
	
	if(self)
	{
        dlog(@"crop init");
        //[Utils printFreeMemory];
        
		cropWindow = kCropWindowFrame;
        
        self.fullsizePhoto = aPhoto;
	}
	
	return self;
}

- (void)viewDidLoad 
{
    [super viewDidLoad];

    [[UIApplication sharedApplication] setStatusBarHidden:NO animated:NO]; 
    
    _cancelButton.enabled = NO;
    _proceedButton.enabled = NO;
    _filtersdButton.enabled = NO;
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 24)];
    titleLabel.text = @"Preview";
    titleLabel.textColor = [UIColor colorWithRed:97.0/255 green:40.0/255 blue:15.0/255 alpha:1.0];
    titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:24.0];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textAlignment = UITextAlignmentLeft;
	self.navigationItem.titleView = titleLabel;
    
    self.navigationItem.hidesBackButton = YES;

    self.scrollView = [[UIScrollView alloc] initWithFrame:kScrollViewFrame];
	self.scrollView.contentMode = (UIViewContentModeScaleAspectFit);
    self.scrollView.autoresizingMask = ( UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
    
    self.scrollView.clipsToBounds = YES;
    self.scrollView.delegate = self;
	[self.view insertSubview:scrollView atIndex:0];
    
    //UIImageOrientation originalOrientation = self.photo.imageOrientation;
    

    [ConvenientPopups showNonBlockingPopupOnView:self.view withText:@"Just a sec..."];
    

    /*
    [NSThread detachNewThreadSelector:@selector(setImageInBackground) 
                             toTarget:self 
                           withObject:nil];
     */
    
    [self setImageInBackground];
    dlog(@"crop viewDidLoad");
    //[Utils printFreeMemory];
    
}

- (void)setImageInBackground
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    
    static const CGFloat kMaximumImageResolution = 800;
    
    if(self.fullsizePhoto.size.width > kMaximumImageResolution ||
       self.fullsizePhoto.size.height > kMaximumImageResolution
       )
    {
        CGFloat minResolution = MIN(self.fullsizePhoto.size.width, 
                                    self.fullsizePhoto.size.height);
        CGFloat coefficient = minResolution/kMaximumImageResolution;
        CGSize newSize = CGSizeMake(self.fullsizePhoto.size.width/coefficient, 
                                    self.fullsizePhoto.size.height/coefficient);
        
        //self.photo = [self.fullsizePhoto simpleResizeToSize:newSize];
        
        // Low interpolationQuality to speed up
        self.photo = [self.fullsizePhoto resizedImage:newSize
                                 interpolationQuality:kCGInterpolationNone];
    }
    else
        self.photo = self.fullsizePhoto;
    
    [pool release];
    
    UIImage *imageUpsideOriented = self.photo;
    
    if(self.photo.imageOrientation != UIImageOrientationUp)
        imageUpsideOriented = [self.photo rotate:self.photo.imageOrientation];
    
    self.imageView = 
    [[UIImageView alloc] initWithFrame:CGRectMake(0, 
                                                  0, 
                                                  imageUpsideOriented.size.width, 
                                                  imageUpsideOriented.size.height)];
    /*
     [[UIImageView alloc] initWithFrame:CGRectMake((self.scrollView.frame.size.width - self.photo.size.width)/2, 
     (self.scrollView.frame.size.height - self.photo.size.height)/2, 
     self.photo.size.width, 
     self.photo.size.height)];
     
     */

	imageView.image = imageUpsideOriented;
    
    [self.scrollView addSubview:imageView];
	self.scrollView.contentSize = imageView.frame.size;
    
    self.scrollView.maximumZoomScale = ((float)imageUpsideOriented.size.width)/kUploadPhotoSize.width/2;
    self.scrollView.minimumZoomScale = 
    MAX(kCropWindowFrame.size.width/imageUpsideOriented.size.width,
        kCropWindowFrame.size.height/imageUpsideOriented.size.height);
    
    self.scrollView.zoomScale = self.scrollView.minimumZoomScale;
    
    CGRect rectToZoom = CGRectMake(0, 0, 320, 320);
    
    //height > width
    if(imageView.frame.size.height > imageView.frame.size.width)
    {
        rectToZoom = CGRectMake(0, 
                                (imageView.frame.size.height-imageView.frame.size.width)/2 * 1.4f, 
                                imageView.frame.size.width, 
                                imageView.frame.size.width);
    }
    //height <= width
    else
    {
        rectToZoom = CGRectMake((imageView.frame.size.width-imageView.frame.size.height)/2, 
                                0, 
                                imageView.frame.size.height, 
                                imageView.frame.size.height);
    }
    
    [self.scrollView scrollRectToVisible:rectToZoom animated:NO];
    
    
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    //[self shiftView];
    //[self performSelector:@selector(shiftView) withObject:nil afterDelay:0.4f];
    
    _cancelButton.enabled = YES;
    _proceedButton.enabled = YES;
    _filtersdButton.enabled = YES;
}

/*
- (void)viewWillAppear:(BOOL)animated
{
    dlog(@"CropPhotoController viewWillAppear");
}
*/

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    dlog(@"CropPhotoController viewDidAppear");
    
    if(![[DataSource instance] isNewReviewDataAvailable] && ![[DataSource instance] isRestaurantInfoAvailable])
    {
        _restaurantListController = [[RestaurantListController alloc] init];
        _restaurantListController.isShortList = YES;
        _restaurantListController.noUpdateMode = YES;
        [_restaurantListController update];
    }
}


- (void)shiftView
{
    CGRect frame = self.view.frame;
    frame.origin.y += 44.0;
    self.view.frame = frame;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

#pragma mark -
#pragma mark IBActions

- (IBAction)submitPhoto
{
	UIImage *croppedImage = [self croppedImage];
    [self nextStepWithPhoto:croppedImage];
    
    [_croppedImage release];
    _croppedImage = nil;
}

- (void)nextStepWithPhoto:(UIImage *)photo
{
    //create a new UUID
	NSString *uuidString = [Utils newUUID];
    
    
    /*
     AddReviewController *addReviewController = 
     [[AddReviewController alloc] initWithPhoto:croppedImage
     UUID:uuidString];
     
     [self.navigationController pushViewController:addReviewController animated:YES];
     [addReviewController release];
     */
    
    NSData *imageData = UIImageJPEGRepresentation([photo imageResizedToFit:kUploadPhotoSize 
                                                      interpolationQuality:kCGInterpolationHigh], 0.8);
    
    [[DataSource instance] addReviewPhotoDataToQueue:imageData withUUID:uuidString];
    
    [DataSource instance].imageUUID = uuidString;
    [DataSource instance].reviewImage = photo;
    
    if([[DataSource instance] isNewReviewDataAvailable])
    {
        AddReviewController *addReviewController = [[AddReviewController alloc] init];
        [self.navigationController pushViewController:addReviewController animated:YES];
        [addReviewController release];
    }
    else if([[DataSource instance] isRestaurantInfoAvailable])
    {
        if([[DataSource instance].restaurantID intValue])
        {
            NSInteger restaurantID = [[DataSource instance].restaurantID intValue];
            
            MenuController *menuController = [[MenuController alloc] initWithRestaurantId:restaurantID];
            menuController.checkinMode = YES;
            [self.navigationController pushViewController:menuController animated:YES];
            [menuController release];
        }
        else if([DataSource instance].restaurantFoursquareVenueID)
        {
            RestaurantModel *restaurant = [[RestaurantModel alloc] init];
            
            restaurant.isFoursquareOnly = YES;
            restaurant.foursquareVenueId = [DataSource instance].restaurantFoursquareVenueID;
            
            MenuController *menuController = [[MenuController alloc] initWithRestaurant:restaurant];
            menuController.checkinMode = YES;
            [self.navigationController pushViewController:menuController animated:YES];
            [menuController release];
        }
    }
    else
    {
        if(!_restaurantListController)
        {
            _restaurantListController = [[RestaurantListController alloc] init];
            _restaurantListController.isShortList = YES;
            //restaurantListController.delegate = self;
        }
        
        [self.navigationController pushViewController:_restaurantListController animated:YES];
        [_restaurantListController release];
        _restaurantListController = nil;
    }
}

- (IBAction)cancel:(id)sender
{
    /*
    [self.navigationController popViewControllerAnimated:YES];
    [[UIApplication sharedApplication] setStatusBarHidden:NO animated:NO];
    //old code
    */
    
    /*
    [[[self.navigationController viewControllers] objectAtIndex:0] showImagePicker];
    [self.navigationController popViewControllerAnimated:NO];
     */
    
    
    [[DataSource instance].tabBar imagePickerControllerDidCancel];
    [self.navigationController popToRootViewControllerAnimated:NO];
}

- (IBAction)applyFilters:(id)sender
{
    UIImage *croppedImage = [self croppedImage];

    AFPhotoEditorController *editorController = [[AFPhotoEditorController alloc] initWithImage:croppedImage];
    [editorController setDelegate:self];
    //[self presentModalViewController:editorController animated:YES];
    
    [self presentModalViewController:editorController animated:YES];
    
    //[self.navigationController pushViewController:editorController animated:YES];
    [editorController release];
}

//new aviary delegates
- (void)photoEditor:(AFPhotoEditorController *)editor finishedWithImage:(UIImage *)image
{
    [LoggerController logEvent:@"User applied filters"];
    [self nextStepWithPhoto:image];
    
    [self dismissModalViewControllerAnimated:YES];
}

- (void)photoEditorCanceled:(AFPhotoEditorController *)editor
{
    [_croppedImage release];
    _croppedImage = nil;
    
    [self dismissModalViewControllerAnimated:YES];
}


#pragma mark -
#pragma mark Actions

- (void)setImage:(UIImage *)anImage
{    

}

- (UIImage*) croppedImage
{
	float scale = 1.0f/scrollView.zoomScale;
	
	CGRect visibleRect;
    
    /*
	visibleRect.origin.x = (scrollView.contentOffset.x + 60) * scale;
	visibleRect.origin.y = (scrollView.contentOffset.y + 100) * scale;
	visibleRect.size.width = 200 * scale;//scrollView.bounds.size.width * scale;
	visibleRect.size.height = 200 * scale;//scrollView.bounds.size.height * scale;
	*/
    
    //visibleRect.origin.x = (scrollView.contentOffset.x + cropWindow.origin.x) * scale;
	//visibleRect.origin.y = (scrollView.contentOffset.y + cropWindow.origin.y) * scale;
	
    visibleRect.origin.x = scrollView.contentOffset.x * scale;
	visibleRect.origin.y = scrollView.contentOffset.y * scale;
    
    visibleRect.size.width = cropWindow.size.width * scale;
	visibleRect.size.height = cropWindow.size.height * scale;
    
	CGImageRef cr = CGImageCreateWithImageInRect([imageView.image CGImage], visibleRect);
    
	//UIImage* cropped = [[[UIImage alloc] initWithCGImage:cr] autorelease];
	_croppedImage = [[UIImage alloc] initWithCGImage:cr];
    
    
    CGImageRelease(cr);
	return _croppedImage;
}


#pragma mark -
#pragma mark ScrollView delegate

-(UIView *) viewForZoomingInScrollView:(UIScrollView *)scrollView {
    return imageView;
}

- (void)scrollViewDidZoom:(UIScrollView *)aScrollView {
    CGFloat offsetX = (scrollView.bounds.size.width > scrollView.contentSize.width)? 
    (scrollView.bounds.size.width - scrollView.contentSize.width) * 0.5 : 0.0;
    CGFloat offsetY = (scrollView.bounds.size.height > scrollView.contentSize.height)? 
    (scrollView.bounds.size.height - scrollView.contentSize.height) * 0.5 : 0.0;
    imageView.center = CGPointMake(scrollView.contentSize.width * 0.5 + offsetX, 
                                   scrollView.contentSize.height * 0.5 + offsetY);
}

@end
