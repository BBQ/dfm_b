//
//  ActiveStarView.h
//  dish.fm
//
//  Created by Petr Prokop on 1/5/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActiveStarView : UIView
{
    float _rating;
    NSMutableArray *_imageViews;
}

@property (nonatomic, retain) UIImage *onImage;
@property (nonatomic, retain) UIImage *offImage;
@property (nonatomic, retain) UIImage *halfImage;

@property (assign, nonatomic) id delegate;

- (void)updateRating:(NSNumber *)rating;

@end
