@class AlertView;

@interface AlertView : UIAlertView<UIAlertViewDelegate>
{
    NSMutableArray* buttonCallbackArray;
    
    void(^cancel)(AlertView* alertView);
    void(^willPresent)(AlertView*);
    void(^didPresent)(AlertView*);
    void(^willDismiss)(AlertView*, NSInteger);
    void(^didDismiss)(AlertView*, NSInteger);
}

-(id)initWithTitle:(NSString*)title message:(NSString*)msg;
-(void)dealloc;

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex;
-(void)alertViewCancel:(UIAlertView *)alertView;
-(void)willPresentAlertView:(UIAlertView *)alertView;
-(void)didPresentAlertView:(UIAlertView *)alertView;
-(void)alertView:(UIAlertView *)alertView willDismissWithButtonIndex:(NSInteger)buttonIndex;
-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex;

-(void)addButtonWithTitle:(NSString*)title block:(void(^)(AlertView*, NSInteger))block;

-(void)setAlertViewCancelBlock:(void(^)(AlertView*))block;
-(void)setWillPresentAlertViewBlock:(void(^)(AlertView*))block;
-(void)setDidPresentAlertViewBlock:(void(^)(AlertView*))block;
-(void)setAlertViewWillDismissWithButtonIndexBlock:(void(^)(AlertView*, NSInteger))block;
-(void)setAlertViewDidDismissWithButtonIndexBlock:(void(^)(AlertView*, NSInteger))block;

@end