//
//  EmailLoginVC.m
//  dish.fm
//
//  Created by Petr Prokop on 5/17/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "EmailLoginVC.h"
#import "Utils.h"
#import "ConvenientPopups.h"
#import "RequestProcessor.h"
#import "Config.h"

@implementation EmailLoginVC

- (void)dealloc
{
    [RequestProcessor cancelAllRequestsFromDelegate:self];
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


#pragma mark - IBActions

- (IBAction)termsOfServiceClick:(id)sender
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:URL_TERMS]];
}

- (IBAction)privacyPolicyClick:(id)sender
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:URL_PRIVACY]];
}

- (IBAction)cancel:(id)sender
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"emailDidNotLogin"  object:nil];
}

- (IBAction)login:(id)sender
{
    if(!_email.text || ! [Utils checkIfEmailIsValid:_email.text])
    {
        [ConvenientPopups showToastLikeMessage:@"Please enter a valid email!" 
                                        onView:self.view 
                                     imageName:@"attentionIcon.png"
                                 verticalShift:-100];
        return;
    }
    
    if(!_password.text || [_password.text length] < 6)
    {
        [ConvenientPopups showToastLikeMessage:@"Please enter minimum 6 symbols for password!" 
                                        onView:self.view 
                                     imageName:@"attentionIcon.png"
                                 verticalShift:-100];
        return;
    }
    
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
                          _email.text, @"email",
                          _password.text, @"password",
                          _name.text, @"name",
                          nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"emailDidLogin" 
                                                        object:nil 
                                                      userInfo:dict];
}

- (IBAction)recoverPassword:(id)sender
{
    if(!_email.text || ! [Utils checkIfEmailIsValid:_email.text])
    {
        [ConvenientPopups showToastLikeMessage:@"Please enter a valid email!" 
                                        onView:self.view 
                                     imageName:@"attentionIcon.png"
                                 verticalShift:-100];
        return;
    }
    
    [ConvenientPopups showNonBlockingPopupOnView:self.view 
                                        withText:@"Recovering..."];
    
    RequestProcessor *rp = [RequestProcessor recoverPasswordOnEmail:_email.text];
    rp.delegate = self;
    rp.successCallback = @selector(recoverPasswordSuccess:);
    rp.failCallback = @selector(recoverPasswordFail:);
    [rp startRequest];
}


#pragma mark - RP callbacks

- (void)recoverPasswordSuccess:(RequestProcessor *)rp
{
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    [ConvenientPopups showToastLikeMessage:@"Check your email for recovery instructions!" 
                                    onView:self.view
                                 imageName:@"acceptIcon.png"
                             verticalShift:-100];
}

- (void)recoverPasswordFail:(RequestProcessor *)rp
{
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];    
}

@end