//
//  EmailLoginVC.h
//  dish.fm
//
//  Created by Petr Prokop on 5/17/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmailLoginVC : UIViewController
{
    IBOutlet UITextField *_email;
    IBOutlet UITextField *_password;
    IBOutlet UITextField *_name;
}

- (IBAction)cancel:(id)sender;
- (IBAction)login:(id)sender;
- (IBAction)recoverPassword:(id)sender;
- (IBAction)termsOfServiceClick:(id)sender;
- (IBAction)privacyPolicyClick:(id)sender;

@end

