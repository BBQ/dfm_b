#import <UIKit/UIKit.h>
#import "FBConnect.h"

@class MainViewController;

@interface dishAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MainViewController *viewController;
    
    BOOL _applicationIsActive;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MainViewController *viewController;

@end

