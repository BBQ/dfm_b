//
//  AddRestaurantController.m
//  dish.fm
//
//  Created by Petr Prokop on 2/27/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "AddDeliveryController.h"
#import "CustomAnnotation.h"
#import "DDAnnotation.h"
#import "DDAnnotationView.h"
#import "ConvenientPopups.h"
#import "AddRestaurantCategoriesVC.h"
#import "RequestProcessor.h"
#import "AddDishController.h"
#import "DataSource.h"

@implementation AddDeliveryController

@synthesize restaurantName;

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationItem setTitle:@"Add delivery service"];
    
    UIImage *buttonBackground = [UIImage imageNamed:@"HeaderButtonSquare.png"];
    UIButton *okButton = [UIButton buttonWithType:UIButtonTypeCustom];
    okButton.frame = CGRectMake(0, 0, buttonBackground.size.width, buttonBackground.size.height);
    [okButton setTitleShadowColor:[UIColor grayColor] forState:UIControlStateNormal];
    [okButton setBackgroundImage:buttonBackground forState:UIControlStateNormal];
    [okButton setTitle:@"Add" forState:UIControlStateNormal];
    okButton.titleLabel.shadowOffset = CGSizeMake(0, -1);    
    okButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0f];
    [okButton addTarget:self action:@selector(addClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:okButton];
    
    if(self.restaurantName)
        _nameTextField.text = self.restaurantName;
}


- (void)dealloc 
{
    self.restaurantName = nil;
    
    [_nameTextField release];

    [super dealloc];
}

- (void)viewDidUnload {
    [_nameTextField release];
    _nameTextField = nil;
    [_phoneTextField release];
    _phoneTextField = nil;
    [_webTextField release];
    _webTextField = nil;

    [super viewDidUnload];
}

#pragma mark - UI Actions

- (IBAction)addClicked
{    
    if((!_webTextField.text || [_webTextField.text isEqualToString:@""]) &&
       (!_phoneTextField.text || [_phoneTextField.text isEqualToString:@""]))
    {
        [ConvenientPopups showAlertWithTitle:@"" andMessage:@"Please add phone or web site!"];
        return;
    }
    
    [ConvenientPopups showNonBlockingPopupOnView:self.view 
                                        withText:@"Almost done..."];
    
    RequestProcessor *rp =
    [RequestProcessor addRestaurantWithName:_nameTextField.text 
                                   category:nil
                                    address:@""
                                   location:nil
                                   terrasse:NO
                                       wifi:NO
                                      cards:NO
                                      phone:_phoneTextField.text
                                        web:_webTextField.text
                               deliveryOnly:YES
                                 priceRange:_priceRange];
    rp.delegate = self;
    rp.successCallback = @selector(restaurantAdded:);
    rp.failCallback = @selector(restaurantFailedToAdd:);
    [rp startRequest];
}


- (IBAction)openChoosePriceRangeSheet:(id)sender
{
    _actionSheet = [[UIActionSheet alloc] initWithTitle:nil 
                                               delegate:nil
                                      cancelButtonTitle:nil
                                 destructiveButtonTitle:nil
                                      otherButtonTitles:nil];
    
    [_actionSheet setActionSheetStyle:UIActionSheetStyleBlackTranslucent];
    
    CGRect pickerFrame = CGRectMake(0, 40, 0, 0);
    
    _pickerView = [[UIPickerView alloc] initWithFrame:pickerFrame];
    _pickerView.showsSelectionIndicator = YES;
    _pickerView.dataSource = self;
    _pickerView.delegate = self;
    
    [_actionSheet addSubview:_pickerView];
    [_pickerView release];
    
    UIImage *buttonBackground = [UIImage imageNamed:@"HeaderButtonSquare.png"];
    UIButton *okButton = [UIButton buttonWithType:UIButtonTypeCustom];
    okButton.frame = CGRectMake(260, 7.0f, 50.0f, 30.0f);
    [okButton setTitleShadowColor:[UIColor grayColor] forState:UIControlStateNormal];
    [okButton setBackgroundImage:buttonBackground forState:UIControlStateNormal];
    [okButton setTitle:@"Yep" forState:UIControlStateNormal];
    okButton.titleLabel.shadowOffset = CGSizeMake(0, -1);    
    okButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0f];
    [okButton addTarget:self action:@selector(startCall) forControlEvents:UIControlEventTouchUpInside];
    [_actionSheet addSubview:okButton];
    
    UISegmentedControl *closeButton = 
    [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"Close", nil]];
    [_actionSheet addSubview:closeButton];
    
    closeButton.momentary = YES; 
    closeButton.frame = CGRectMake(10, 7.0f, 50.0f, 30.0f);
    closeButton.segmentedControlStyle = UISegmentedControlStyleBar;
    closeButton.tintColor = [UIColor blackColor];
    [closeButton addTarget:self action:@selector(dismissActionSheet:) forControlEvents:UIControlEventValueChanged];
    [_actionSheet addSubview:closeButton];
    [closeButton release];
    
    [_actionSheet showInView:[[UIApplication sharedApplication] keyWindow]];
    [_actionSheet setBounds:CGRectMake(0, 0, 320, 485)];
}

#pragma mark -
#pragma mark UIActionSheet delegate

#define kPriceRanges [NSArray arrayWithObjects:@"???", @"$", @"$$", @"$$$", @"$$$$", nil]

- (void)startCall
{
    _priceRange = [_pickerView selectedRowInComponent:0];
    [_choosePriceRangeButton setTitle:[kPriceRanges objectAtIndex:_priceRange] 
                             forState:UIControlStateNormal];
    [_actionSheet dismissWithClickedButtonIndex:0 animated:YES];
}

- (void)dismissActionSheet:(UISegmentedControl *)sender
{    
    [_actionSheet dismissWithClickedButtonIndex:0 animated:YES];
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [kPriceRanges count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [kPriceRanges objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
}

#pragma mark -
#pragma mark UITextField delegate


- (void)textFieldDidBeginEditing:(UITextField *)textField
{

}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField 
{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - RequestProcessro callbacks

- (void) restaurantAdded:(RequestProcessor *)rp
{
    NSNumber *restaurantID = [rp.processedJSON objectForKey:@"restaurant_id"];
    
    if(![restaurantID isKindOfClass:[NSNumber class]])
    {
        [ConvenientPopups showAlertWithTitle:@"Error" 
                                  andMessage:@"Ooops... Server did something wrong - please try again!"];
        return;
    }
    
    [DataSource instance].restaurantName = _nameTextField.text;
    [DataSource instance].restaurantID = restaurantID;
    
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    AddDishController *addDishController = [[AddDishController alloc] initWithDishName:@""];
    [self.navigationController pushViewController:addDishController animated:YES];
    [addDishController release];
}

- (void) restaurantFailedToAdd:(RequestProcessor *)rp
{
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];    
}

@end