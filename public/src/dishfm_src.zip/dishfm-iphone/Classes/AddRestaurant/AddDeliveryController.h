//
//  AddRestaurantController.h
//  dish.fm
//
//  Created by Petr Prokop on 2/27/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyViewController.h"

@interface AddDeliveryController : MyViewController
{    
    IBOutlet UITextField *_nameTextField;
    
    IBOutlet UITextField *_phoneTextField;
    IBOutlet UITextField *_webTextField;
    
    IBOutlet UIButton *_choosePriceRangeButton;
    UIActionSheet *_actionSheet;
    UIPickerView *_pickerView;
    
    NSInteger _priceRange;

}

@property (nonatomic, retain) NSString *restaurantName;

- (IBAction)openChoosePriceRangeSheet:(id)sender;

@end
