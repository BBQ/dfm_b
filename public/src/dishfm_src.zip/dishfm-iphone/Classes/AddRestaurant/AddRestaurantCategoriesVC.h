//
//  AddRestaurantCategoriesVC.h
//  dish.fm
//
//  Created by Petr Prokop on 2/28/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddRestaurantController.h"
#import "CustomSearchBar.h"

@interface AddRestaurantCategoriesVC : UIViewController<UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate>
{
    UITableViewController *_tableVC;
    NSArray *_categories;
    CustomSearchBar *_searchBar;
}

@property (nonatomic, assign) id<AddRestaurantCategoriesVCDelegate> delegate;

@end
