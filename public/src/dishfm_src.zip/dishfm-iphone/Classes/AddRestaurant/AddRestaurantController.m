//
//  AddRestaurantController.m
//  dish.fm
//
//  Created by Petr Prokop on 2/27/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "AddRestaurantController.h"
#import "CustomAnnotation.h"
#import "DDAnnotation.h"
#import "DDAnnotationView.h"
#import "ConvenientPopups.h"
#import "AddRestaurantCategoriesVC.h"
#import "RequestProcessor.h"
#import "AddDishController.h"
#import "DataSource.h"
#import "Config.h"
#import "LoggerController.h"

@implementation AddRestaurantController

@synthesize restaurantName;

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
 
    _isMapOpen = NO;
    _priceRange = 0;
    
    [_mapButton addTarget:self 
                   action:@selector(mapButtonTap:) 
         forControlEvents:UIControlEventTouchDown];
    
    [self.navigationItem setTitle:@"Add Place"];
    
    _originaMapViewFrame = _mapView.frame;
    
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImage *backButtonImage = [UIImage imageNamed:@"backBtn.png"];
    backButton.frame = CGRectMake(0, 0, backButtonImage.size.width, backButtonImage.size.height);
    [backButton setBackgroundImage:backButtonImage forState:UIControlStateNormal];
    [backButton setBackgroundImage:[UIImage imageNamed:@"backBtnTap.png"] forState:UIControlStateHighlighted];
    backButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0f];
    [backButton setTitle:@"  Back" forState:UIControlStateNormal];
    [backButton setTitleColor:kBrownTextColor forState:UIControlStateNormal];
    [backButton setTitleShadowColor:[UIColor whiteColor] forState:UIControlStateNormal];
    backButton.titleLabel.shadowOffset = CGSizeMake(0, 1);
    [backButton addTarget:self 
                   action:@selector(backClick) 
         forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = [[[UIBarButtonItem alloc] initWithCustomView:backButton] autorelease];
    
    
    
    UIImage *buttonBackground = [UIImage imageNamed:@"HeaderButtonSquare.png"];
    _okButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _okButton.frame = CGRectMake(0, 0, buttonBackground.size.width, buttonBackground.size.height);
    [_okButton setTitleShadowColor:[UIColor grayColor] forState:UIControlStateNormal];
    [_okButton setBackgroundImage:buttonBackground forState:UIControlStateNormal];
    [_okButton setTitle:@"Add" forState:UIControlStateNormal];
    _okButton.titleLabel.shadowOffset = CGSizeMake(0, -1);    
    _okButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0f];
    [_okButton addTarget:self action:@selector(addClicked) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:_okButton];

    
    if([[LocationManager instance] getLastLocation] == nil)
    {
        [ConvenientPopups showNonBlockingPopupOnView:self.view withText:@"Trying to find you..."];
        [[LocationManager instance] getUserLocation:self withType:LocationTypeLocation implicitly:YES];
    }
    else
    {
        [self locationFound:[[LocationManager instance] getLastLocation] 
                      isNew:YES 
                 sourceType:LocationTypeLocation];
    }
    
    if(self.restaurantName)
        _nameTextField.text = self.restaurantName;
}


- (void)dealloc 
{
    if(_closeMapButton)
    {
        [_closeMapButton removeFromSuperview];
        _closeMapButton = nil;
    }
    
    _mapView.delegate = nil;
    self.restaurantName = nil;
    
    [_nameTextField release];
    [_categoryTextField release];
    [_addressTextField release];
    [_terrasseSwitch release];
    [_wifiSwich release];
    [_cardsSwitch release];
    
    [_mapView release];
    [super dealloc];
}

- (void)viewDidUnload {
    [_nameTextField release];
    _nameTextField = nil;
    [_categoryTextField release];
    _categoryTextField = nil;
    [_addressTextField release];
    _addressTextField = nil;
    [_terrasseSwitch release];
    _terrasseSwitch = nil;
    [_wifiSwich release];
    _wifiSwich = nil;
    [_cardsSwitch release];
    _cardsSwitch = nil;
    
    [_mapView release];
    _mapView = nil;
    [super viewDidUnload];
}

#pragma mark -
#pragma mark LocationManager delegates

- (void) locationFound:(CLLocation*)location 
				 isNew:(BOOL)newLocation 
			sourceType:(int)type
{
    _addressTextField.placeholder = @"(optional)";
    
    _restaurantLocation = [location retain];
    
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    DDAnnotation *annotation = [[DDAnnotation alloc] initWithCoordinate:location.coordinate
                                                       addressDictionary:nil];
	//annotation.title = @"New restaurant location";
	//annotation.subtitle = @"Drag to Move Pin";
    
    [_mapView addAnnotation:annotation];
    [annotation release]; 
    
    MKCoordinateRegion regionToSet = MKCoordinateRegionMake(location.coordinate, 
                                                            MKCoordinateSpanMake(0.05f, 0.05f));
    [_mapView setRegion:regionToSet animated:YES];
}

- (void) locationNotFound
{
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    
    CLLocation *location = [[CLLocation alloc] initWithLatitude:40.783333 
                                                      longitude:-73.966667];
    
    _addressTextField.placeholder = @"(optional)";
    
    _restaurantLocation = [location retain];
    
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    DDAnnotation *annotation = [[DDAnnotation alloc] initWithCoordinate:location.coordinate
                                                      addressDictionary:nil];
	//annotation.title = @"New restaurant location";
	//annotation.subtitle = @"Drag to Move Pin";
    
    [_mapView addAnnotation:annotation];
    [annotation release]; 
    
    MKCoordinateRegion regionToSet = MKCoordinateRegionMake(location.coordinate, 
                                                            MKCoordinateSpanMake(0.05f, 0.05f));
    [_mapView setRegion:regionToSet animated:YES];
}

#pragma mark - UI Actions

- (void)backClick
{
    if(_isMapOpen)
        [self closeMap:nil];
    else
        [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)addClicked
{
    if(!_categoryTextField.text || [_categoryTextField.text isEqualToString:@""])
    {
        [ConvenientPopups showAlertWithTitle:@"" andMessage:@"Please select a category!"];
        return;
    }
    
    [LoggerController logEvent:@"User created restaurant"];
    
    [ConvenientPopups showNonBlockingPopupOnView:self.view 
                                        withText:@"Almost done..."];
    
    RequestProcessor *rp =
    [RequestProcessor addRestaurantWithName:_nameTextField.text 
                                   category:_categoryTextField.text 
                                    address:_addressTextField.text 
                                   location:_restaurantLocation
                                   terrasse:_terrasseSwitch.isOn
                                       wifi:_wifiSwich.isOn
                                      cards:_cardsSwitch.isOn
                                      phone:nil 
                                        web:nil 
                               deliveryOnly:NO
                                 priceRange:_priceRange];
    
    rp.delegate = self;
    rp.successCallback = @selector(restaurantAdded:);
    rp.failCallback = @selector(restaurantFailedToAdd:);
    [rp startRequest];
}

- (IBAction)categoryClicked
{
    AddRestaurantCategoriesVC *addRestaurantCategoriesVC = [[AddRestaurantCategoriesVC alloc] init];
    addRestaurantCategoriesVC.delegate = self;
    [self.navigationController pushViewController:addRestaurantCategoriesVC animated:YES];
    [addRestaurantCategoriesVC release];
}

- (void)mapButtonTap:(id)sender
{
    [self.view findAndResignFirstResponder];
    
    _isMapOpen = YES;
    
    _recognizer = [[UITapGestureRecognizer alloc] 
                   initWithTarget:self action:@selector(handleMapTap:)];
    _recognizer.numberOfTapsRequired = 1;
    _recognizer.numberOfTouchesRequired = 1;
    [_mapView addGestureRecognizer:_recognizer];
    [_recognizer release];
    
    UIImage *buttonBackground = [UIImage imageNamed:@"HeaderButtonSquare.png"];
    _closeMapButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _closeMapButton.frame = _okButton.frame;
    [_closeMapButton setTitleShadowColor:[UIColor grayColor] forState:UIControlStateNormal];
    [_closeMapButton setBackgroundImage:buttonBackground forState:UIControlStateNormal];
    [_closeMapButton setTitle:@"Yep!" forState:UIControlStateNormal];
    _closeMapButton.titleLabel.shadowOffset = CGSizeMake(0, -1);    
    _closeMapButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0f];
    [_closeMapButton addTarget:self
                        action:@selector(closeMap:) 
              forControlEvents:UIControlEventTouchUpInside];
    [_okButton.superview addSubview:_closeMapButton];
    _closeMapButton.alpha = 0.0f;
    
    [_mapButton.superview  sendSubviewToBack:_mapButton];
    
    [UIView animateWithDuration:0.3f 
                     animations:^{
                         _mapView.frame = CGRectMake(0, 0, 320, 416);
                         _okButton.alpha = 0.0f;
                         _closeMapButton.alpha = 1.0f;
                         _mapLabel.alpha = 0.0f;
                     } 
                     completion:^(BOOL finished) {
                         
                         if(finished)
                         {
                             [_mapLabel removeFromSuperview];
                         }
                     }];
}

- (void)closeMap:(UIButton *)sender
{
    [_mapView removeGestureRecognizer:_recognizer];
    _isMapOpen = NO;
    
    MKCoordinateRegion region = MKCoordinateRegionMake(_restaurantLocation.coordinate, MKCoordinateSpanMake(0.02, 0.02));
    [_mapView setRegion:region animated:YES];
    
    [UIView animateWithDuration:0.3f 
                     animations:^{
                         _okButton.alpha = 1.0;
                         _closeMapButton.alpha = 0.0f;
                         _mapView.frame = _originaMapViewFrame;
                     } 
                     completion:^(BOOL finished) {
                         [_mapButton.superview bringSubviewToFront:_mapButton];
                         
                         [_closeMapButton removeFromSuperview];
                         _closeMapButton = nil;
                     }];
}

- (IBAction)openChoosePriceRangeSheet:(id)sender
{
    _actionSheet = [[UIActionSheet alloc] initWithTitle:nil 
                                               delegate:nil
                                      cancelButtonTitle:nil
                                 destructiveButtonTitle:nil
                                      otherButtonTitles:nil];
    
    [_actionSheet setActionSheetStyle:UIActionSheetStyleBlackTranslucent];
    
    CGRect pickerFrame = CGRectMake(0, 40, 0, 0);
    
    _pickerView = [[UIPickerView alloc] initWithFrame:pickerFrame];
    _pickerView.showsSelectionIndicator = YES;
    _pickerView.dataSource = self;
    _pickerView.delegate = self;
    
    [_actionSheet addSubview:_pickerView];
    [_pickerView release];

    UIImage *buttonBackground = [UIImage imageNamed:@"HeaderButtonSquare.png"];
    UIButton *okButton = [UIButton buttonWithType:UIButtonTypeCustom];
    okButton.frame = CGRectMake(260, 7.0f, 50.0f, 30.0f);
    [okButton setTitleShadowColor:[UIColor grayColor] forState:UIControlStateNormal];
    [okButton setBackgroundImage:buttonBackground forState:UIControlStateNormal];
    [okButton setTitle:@"Yep" forState:UIControlStateNormal];
    okButton.titleLabel.shadowOffset = CGSizeMake(0, -1);    
    okButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0f];
    [okButton addTarget:self action:@selector(startCall) forControlEvents:UIControlEventTouchUpInside];
    [_actionSheet addSubview:okButton];
    
    UISegmentedControl *closeButton = 
    [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"Close", nil]];
    [_actionSheet addSubview:closeButton];
    
    closeButton.momentary = YES; 
    closeButton.frame = CGRectMake(10, 7.0f, 50.0f, 30.0f);
    closeButton.segmentedControlStyle = UISegmentedControlStyleBar;
    closeButton.tintColor = [UIColor blackColor];
    [closeButton addTarget:self action:@selector(dismissActionSheet:) forControlEvents:UIControlEventValueChanged];
    [_actionSheet addSubview:closeButton];
    [closeButton release];
    
    [_actionSheet showInView:[[UIApplication sharedApplication] keyWindow]];
    [_actionSheet setBounds:CGRectMake(0, 0, 320, 485)];
}

#pragma mark -
#pragma mark UIActionSheet delegate

#define kPriceRanges [NSArray arrayWithObjects:@"???", @"$", @"$$", @"$$$", @"$$$$", nil]

- (void)startCall
{
    _priceRange = [_pickerView selectedRowInComponent:0];
    [_choosePriceRangeButton setTitle:[kPriceRanges objectAtIndex:_priceRange] 
                             forState:UIControlStateNormal];
    [_actionSheet dismissWithClickedButtonIndex:0 animated:YES];
}

- (void)dismissActionSheet:(UISegmentedControl *)sender
{    
    [_actionSheet dismissWithClickedButtonIndex:0 animated:YES];
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [kPriceRanges count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [kPriceRanges objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
}

#pragma mark -
#pragma mark UITextField delegate


- (void)textFieldDidBeginEditing:(UITextField *)textField
{

}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField 
{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark -
#pragma mark MKMapViewDelegate


/*
- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)annotationView didChangeDragState:(MKAnnotationViewDragState)newState fromOldState:(MKAnnotationViewDragState)oldState 
{
	
	if (oldState == MKAnnotationViewDragStateDragging) 
    {
		DDAnnotation *annotation = (DDAnnotation *)annotationView.annotation;
        [_restaurantLocation release];
        _restaurantLocation = [[CLLocation alloc] initWithLatitude:annotation.coordinate.latitude 
                                                         longitude:annotation.coordinate.longitude];
        
		//annotation.subtitle = [NSString	stringWithFormat:@"%f %f", annotation.coordinate.latitude, annotation.coordinate.longitude];		
	}
}
*/

- (MKAnnotationView *)mapView:(MKMapView *)mapView 
            viewForAnnotation:(id <MKAnnotation>)annotation 
{
	
    if ([annotation isKindOfClass:[MKUserLocation class]]) {
        return nil;		
	}
	
	static NSString * const kPinAnnotationIdentifier = @"PinIdentifier";
    
    MKPinAnnotationView *draggablePinView = [_mapView dequeueReusableAnnotationViewWithIdentifier:kPinAnnotationIdentifier];
	
	if (draggablePinView) 
    {
		draggablePinView.annotation = annotation;
	} 
    else 
    {
		draggablePinView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation 
                                                           reuseIdentifier:kPinAnnotationIdentifier];
        draggablePinView.animatesDrop = YES;
        
        /*[DDAnnotationView annotationViewWithAnnotation:annotation reuseIdentifier:kPinAnnotationIdentifier mapView:_mapView];*/
	}
    
    /*
	MKAnnotationView *draggablePinView = [_mapView dequeueReusableAnnotationViewWithIdentifier:kPinAnnotationIdentifier];
	
	if (draggablePinView) 
    {
		draggablePinView.annotation = annotation;
	} 
    else 
    {
		draggablePinView = [DDAnnotationView annotationViewWithAnnotation:annotation reuseIdentifier:kPinAnnotationIdentifier mapView:_mapView];
	}		
    */
    
	return draggablePinView;
}

#pragma mark - AddRestaurantCategoriesVCDelegate

- (void)updateCategory:(NSString *)category
{
    _categoryTextField.text = category;
}

#pragma mark - RequestProcessro callbacks

- (void) restaurantAdded:(RequestProcessor *)rp
{
    NSNumber *restaurantID = [rp.processedJSON objectForKey:@"restaurant_id"];
    
    if(![restaurantID isKindOfClass:[NSNumber class]])
    {
        [ConvenientPopups showAlertWithTitle:@"Error" 
                                  andMessage:@"Ooops... Server did something wrong - please try again!"];
        return;
    }
    
    [DataSource instance].restaurantName = _nameTextField.text;
    [DataSource instance].restaurantID = restaurantID;
    
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    AddDishController *addDishController = [[AddDishController alloc] initWithDishName:@""];
    [self.navigationController pushViewController:addDishController animated:YES];
    [addDishController release];
}

- (void) restaurantFailedToAdd:(RequestProcessor *)rp
{
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];    
}

- (void)handleMapTap:(UIGestureRecognizer *)gestureRecognizer
{
    [_mapView removeAnnotations:_mapView.annotations];
    
    CGPoint touchPoint = [gestureRecognizer locationInView:_mapView];   
    CLLocationCoordinate2D touchMapCoordinate = 
    [_mapView convertPoint:touchPoint toCoordinateFromView:_mapView];
    
    [_restaurantLocation release];
    _restaurantLocation = [[CLLocation alloc] initWithLatitude:touchMapCoordinate.latitude 
                                                     longitude:touchMapCoordinate.longitude];
    
    CustomAnnotation *annot = [[CustomAnnotation alloc] initWithCoordinates:touchMapCoordinate 
                                                                      title:@"" 
                                                                   subtitle:@""];
    [_mapView addAnnotation:annot];
    [annot release];
}

@end