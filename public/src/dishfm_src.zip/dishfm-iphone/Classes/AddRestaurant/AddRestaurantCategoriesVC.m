//
//  AddRestaurantCategoriesVC.m
//  dish.fm
//
//  Created by Petr Prokop on 2/28/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "AddRestaurantCategoriesVC.h"
#import "SBJsonParser.h"

@interface AddRestaurantCategoriesVC(Private)

- (NSArray *)filteredSubcategoriesForSection:(NSInteger)section;
    
@end


@implementation AddRestaurantCategoriesVC

@synthesize delegate;

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.navigationItem setTitle:@"Select category"];
    
    //read categoies and subcategories from JSON file
    NSString* path = [[NSBundle mainBundle] pathForResource:@"place_categories" 
                                                     ofType:@"json"];
    NSString* content = [NSString stringWithContentsOfFile:path
                                                  encoding:NSUTF8StringEncoding
                                                     error:NULL];
    SBJsonParser *jsonParser = [SBJsonParser new];
	NSDictionary *parsedData = [jsonParser objectWithString:content];
	[jsonParser release], jsonParser = nil;
    _categories = [parsedData objectForKey:@"place_categories"];
    [_categories retain];
    
    _tableVC = [[UITableViewController alloc] initWithStyle:UITableViewStylePlain];
    _tableVC.tableView.frame = CGRectMake(self.view.bounds.origin.x, 
                                          self.view.bounds.origin.y, 
                                          self.view.bounds.size.width, 
                                          self.view.bounds.size.height);
    _tableVC.tableView.dataSource = self;
    _tableVC.tableView.delegate = self;
    
    _searchBar = [[CustomSearchBar alloc] init];
    _searchBar.delegate = self;
    _tableVC.tableView.tableHeaderView = _searchBar;
    
    [self.view addSubview:_tableVC.tableView];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    [_categories release];
    _categories = nil;
    
    [_tableVC release];
    _tableVC = nil;
}

- (NSArray *)filteredSubcategoriesForSection:(NSInteger)section
{
    NSArray *subcategories = [[_categories objectAtIndex:section] objectForKey:@"subcategories"];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF CONTAINS[cd] %@", _searchBar.text];
    
    
    if(_searchBar.text && ![_searchBar.text isEqualToString:@""])
        return [subcategories filteredArrayUsingPredicate:predicate];
    
    return subcategories;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
     NSArray *categories = [[self filteredSubcategoriesForSection:indexPath.section]  sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    
    NSString *category = [categories objectAtIndex:indexPath.row];
    
    if(self.delegate && [self.delegate respondsToSelector:@selector(updateCategory:)])
    {
        [self.delegate updateCategory:category];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - UITableViewDataSource

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [[_categories objectAtIndex:section] objectForKey:@"name"];
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return [_categories count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self filteredSubcategoriesForSection:section] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellID = @"AddRestaurantCategoryCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    if(!cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault 
                                      reuseIdentifier:cellID];
    }
    
    NSArray *categories = [[self filteredSubcategoriesForSection:indexPath.section] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    
    cell.textLabel.text = [categories objectAtIndex:indexPath.row];
    
    return cell;
}


#pragma mark - UISearchBarDelegate

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    [_tableVC.tableView reloadData];
}

@end