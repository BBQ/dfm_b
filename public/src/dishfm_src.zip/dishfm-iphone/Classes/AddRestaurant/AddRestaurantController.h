//
//  AddRestaurantController.h
//  dish.fm
//
//  Created by Petr Prokop on 2/27/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyViewController.h"
#import <MapKit/MapKit.h>
#import "LocationManager.h"
#import "DDAnnotation.h"

@protocol  AddRestaurantCategoriesVCDelegate<NSObject>

- (void)updateCategory:(NSString *)category;

@end

@interface AddRestaurantController : MyViewController<LocationManagerDelegate>
{
    IBOutlet MKMapView *_mapView;
    
    IBOutlet UITextField *_nameTextField;
    IBOutlet UITextField *_categoryTextField;
    IBOutlet UITextField *_addressTextField;
    
    IBOutlet UISwitch *_terrasseSwitch;
    IBOutlet UISwitch *_wifiSwich;
    IBOutlet UISwitch *_cardsSwitch;
    
    CLLocation *_restaurantLocation;
    
    IBOutlet UIButton *_mapButton;
    UIButton *_closeMapButton;
    UIButton *_okButton;
    
    IBOutlet UILabel *_mapLabel;
    UITapGestureRecognizer *_recognizer;
    BOOL _isMapOpen;
    
    IBOutlet UIButton *_choosePriceRangeButton;
    UIActionSheet *_actionSheet;
    UIPickerView *_pickerView;
    CGRect _originaMapViewFrame;
    
    NSInteger _priceRange;
}

@property (nonatomic, retain) NSString *restaurantName;

- (IBAction)categoryClicked;
- (IBAction)openChoosePriceRangeSheet:(id)sender;

@end
