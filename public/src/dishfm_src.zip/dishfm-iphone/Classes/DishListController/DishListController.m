#define DEAL_NAME_TAG 1000
#define kAddressTag 1001
#define kDistanceTag 1002
#define kVotesTag 1003
#define kPhotoPlaceholderTag 1004
#define kRestaurantLabelTag 1012
#define kShadowViewTag 1013

#define kDishIVsTags [NSArray arrayWithObjects:[NSNumber numberWithInt:2001], [NSNumber numberWithInt:2002], [NSNumber numberWithInt:2003], [NSNumber numberWithInt:2004], nil]


#define kPicsPerPage 4
#define kNumberOfPicsPages 2

#define kRestaurantsPerPage 25

//cell xib tags
#define kFirstManagedIVTag 2001
#define kBackgroundTag 3001
#define kScrollViewTag 3002

#define kRatingPositionTag 5001

#define kRowHeight 95.0f

#define kDistanceButtonTag 4001
#define kSortByRatingButtonTag 4002
#define kSortByDistanceButtonTag 4003
#define kMapButtonTag 4004

#define kBlockerViewTag 666999

//for range bar
#define kFistRangeLabelTag 21001

#define kCenteredRangeButtonTag 1004
#define kRangeOptionsCount 5

//#define kDistanceOptions [NSArray arrayWithObjects:@"0.5", @"2", @"5", @"city", @"global", nil]
#define kScrollViewWindowSize 67


//top section
#define kTopSectionHeight 37+15

#import "DishListController.h"
#import "ConvenientPopups.h"
#import "PullRefreshTableViewController.h"
#import "RestaurantModel.h"
#import "LoginController.h"
#import "Utils.h"
#import "Config.h"
#import "UIDevice-Hardware.h"
#import "MapForRestaurants.h"
#import <QuartzCore/QuartzCore.h>
#import "FilterController.h"
#import "DishController.h"
#import "DataSource.h"
#import "GeneralMapController.h"
#import "CustomAnnotation.h"
#import "StarView.h"
#import "RangeBarVC.h"
#import "EmptyScreenVC.h"
#import "LoggerController.h"

@implementation DishListController

@synthesize selectRangeBullet;
@synthesize setDistanceButton;
@synthesize sortByRatingButton;
@synthesize sortByDistanceButton;

@synthesize tableViewController,
            tableCell,
            cityLabel,
            currentCity,
            dishes,
            firstTimeItemsList,
            currentCategory,
            categories,
            delegate,
            keywordsView,
            searchString,
            userLocation,
            distanceFilter,
            keywordID,
            searchSorting,
            priceRanges,
            headerView,
            mapController,
            needsToUpdateLocation,
            restaurants;
@synthesize firstTimeRestaurants;
@synthesize searchNextToMapArea;
@synthesize checkInListType;
@synthesize userID;
@synthesize subPageMode;
@synthesize savedMode;

UIBarButtonItem *changeStateButton;


#pragma mark -
#pragma mark Init/Dealloc

- (id)init
{
	self = [super init];
	
	if(self)
	{		
		self.currentCategory = nil;
        self.userLocation = nil;
        self.searchString = @"";
        self.keywordID = [NSNumber numberWithInt:0];
        self.searchSorting = @"rating";
        self.priceRanges = [NSMutableArray arrayWithObjects:[NSNumber numberWithInt:0],
                            [NSNumber numberWithInt:0], 
                            [NSNumber numberWithInt:0], 
                            [NSNumber numberWithInt:0], 
                            [NSNumber numberWithInt:0], 
                            nil];

        
        self.needsToUpdateLocation = YES;
        
        
        _firstTimeLoading = YES;
		_isLoadingMoreRestaurants = NO;
        _isUpdating = NO;
        
        _currentPage = 0;
        
        _currentRangePage = 1;
        _currentRangeOption = 1; //city level
        self.distanceFilter = [Utils stringForRangeOption:_currentRangeOption];
        
        _thereIsAnotherPage = YES;
		self.firstTimeItemsList = nil;
        self.firstTimeRestaurants = nil;
        
        _requestProcessor = nil;
        
        _objMan = [[HJObjManager alloc] initWithLoadingBufferSize:40 memCacheSize:20];
		NSString* cacheDirectory = [NSHomeDirectory() stringByAppendingString:kImageChachePathSuffix];
		HJMOFileCache* fileCache = [[[HJMOFileCache alloc] initWithRootPath:cacheDirectory] autorelease];
		_objMan.fileCache = fileCache;
        
        self.searchNextToMapArea = NO;
        self.subPageMode = NO;
	}
	
	return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    // Cancel requests
    
    [RequestProcessor cancelAllRequestsFromDelegate:self];
    if(_requestProcessor != nil)
    {
        [_requestProcessor cancelRequest];
    }
    
    [[LocationManager instance] removeDelegate:self];
    
    self.tableViewController.tableView.delegate = nil;
    self.tableViewController.tableView.dataSource = nil;
    
	self.tableViewController = nil;
	self.tableCell = nil;
	self.cityLabel = nil;
	self.currentCity = nil;
	self.dishes = nil;
	self.firstTimeItemsList = nil;
    self.firstTimeRestaurants = nil;
    self.priceRanges = nil;
    
    [_objMan release];
    
    [sortByRatingButton release];
    [sortByDistanceButton release];
    [setDistanceButton release];
    [super dealloc];
}

- (void)viewDidUnload {
    
    [self setSortByRatingButton:nil];
    [self setSortByDistanceButton:nil];
    [self setSetDistanceButton:nil];
    
    [super viewDidUnload];
}

- (void)didReceiveMemoryWarning
{ 
    if(_searchTipsController)
    {
        [_searchTipsController release];
        _searchTipsController = nil;
    }
    
	[super didReceiveMemoryWarning];
}

#pragma mark - 
#pragma mark login delegate

- (void)didLogin
{
    UIBarButtonItem *logoutButton = [[[UIBarButtonItem alloc] initWithTitle:@"Logout" 
                                                                     style:UIBarButtonItemStyleBordered
                                                                    target:self 
                                                                    action:@selector(logout)] autorelease];
    
    self.navigationItem.rightBarButtonItem = logoutButton;
}

- (void)didLogout
{
    self.navigationItem.rightBarButtonItem = nil;
}


- (void)logout
{
    LoginController *facebookLogin = [[LoginController alloc] init];
    facebookLogin.delegate = self;
    [facebookLogin logout];
    [facebookLogin release];
}

#pragma mark - RequestProcessor delegate

-(void)requestProcessorSuccessCallback:(RequestProcessor *) requestProcessor
{	
	id result = requestProcessor.processedJSON;
    
    if([result isKindOfClass:[NSDictionary class]])
	{
        if(self.restaurants == nil)
        {
			self.restaurants = [[NSMutableArray alloc] init];
            [self.restaurants release];
        }
		else
        {
            if(!_isLoadingMoreRestaurants)
                [self.restaurants removeAllObjects];
		}
        
        id restaurantsResult = [result objectForKey:@"restaurants"];
        
        if([restaurantsResult isKindOfClass:[NSArray class]])
        for(id currentRestaurant in restaurantsResult)
        {
            RestaurantModel *restaurantModel = [[RestaurantModel alloc] initWithDictionary:currentRestaurant];
            [self.restaurants addObject:restaurantModel];
            [restaurantModel release];
        }
        
		if(self.dishes == nil)
        {
			self.dishes = [[NSMutableArray alloc] init];
            [self.dishes release];
        }
		else
        {
            if(!_isLoadingMoreRestaurants)
                [self.dishes removeAllObjects];
		}
		
        NSArray *dishesArray = [result objectForKey:@"dishes"];
        
        
        if([dishesArray isKindOfClass:[NSArray class]])
        {
            if([dishesArray count])
            {
                for(NSDictionary *restaurantDict in dishesArray)
                {
                    //[self.dishes addObject:[restaurantDict objectForKey:@"dish"]]; //deprecated
                    [self.dishes addObject:restaurantDict];
                }
            }
            else
            {
                //array is empty - there no more items in this list
                _thereIsAnotherPage = NO;
            }
        }
        
        
        
        if(_firstTimeLoading)
        {
            self.firstTimeItemsList = self.dishes;
            self.firstTimeRestaurants = self.restaurants;
        }
        
        _firstTimeLoading = NO;
        
        
        /*
        NSNumber *restaurantCount = [result objectForKey:@"count"];
        
        if([restaurantCount isKindOfClass:[NSNumber class]])
        {
            _restaurantCount = [restaurantCount intValue];
        }
        
        dlog(@"_restaurantCount %i", _restaurantCount);
        */
         
         
		[self.tableViewController.tableView reloadData];
        
        if(self.mapController)
        {
            [self updateMapAnnotations];
            [self.mapController update];
            self.mapController = nil;
        }
	}
    
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
	[self.tableViewController stopLoading];
    _isLoadingMoreRestaurants = NO;
    _isUpdating = NO;
    
    _requestProcessor = nil;
    
    if(self.searchNextToMapArea)
    {
        [_rangeBarVC updateAddress:@"Searching on the map"];
    }
    
    if(![self.dishes count])
    {
        EmptyScreenVC *esvc = [[EmptyScreenVC alloc] initWithType:kEmptyScreenTypeDiscover];
        [_backgroundIV addSubview:esvc.view];
        [esvc release];
    }
}

- (void)requestProcessorFailedCallback:(RequestProcessor *)requestProcessor
{
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
	[self.tableViewController stopLoading];
    _isLoadingMoreRestaurants = NO;
    _isUpdating = NO;
    
    _requestProcessor = nil;
}

#pragma mark - 
#pragma mark UIActionSheetDelegate

//#define kDistanceLabels [NSArray arrayWithObjects:@"500m", @"2km", @"5km", @"City", @"Glob", nil]


- (BOOL)showDetailForItemsWithIndex:(NSInteger)index
{
    if(index >= [self.dishes count])
        return NO;
    
    id dish = [self.dishes objectAtIndex:index];
    
    DishController *dishController = [[DishController alloc] initWithDishId:[[dish objectForKey:@"id"] intValue]];
    dishController.dishName = [dish objectForKey:@"name"];
    [self.navigationController pushViewController:dishController animated:YES];
    
    [dishController release];
    
    return YES;
}

#pragma mark - Actions

- (void)updateMapAnnotations
{
    [mapController.mapAnnotations removeAllObjects];
    [mapController.mapView removeAnnotations:mapController.mapView.annotations];
    
    if(![self.dishes count])
    {
        [mapController nothingFound];
        return;
    }
    
    for(NSDictionary *currentDish in self.dishes)
    {
        NSNumber *networkID = [[currentDish objectForKey:@"network"] objectForKey:@"id"];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"networkId == %@", networkID];
        
        NSArray *filteredRestaurants = [self.restaurants filteredArrayUsingPredicate:predicate];
        //dlog(@"filteredRestaurants %@", filteredRestaurants);
        
        for(RestaurantModel *currentRestaurant in filteredRestaurants)
        {		
            if(currentRestaurant.location != nil)
            {
                //dlog(@"currentRestaurant.location %@", currentRestaurant.location);
                
                //NSPredicate *predicate = [NSPredicate predicateWithFormat:@"id == %i", currentRestaurant.dishId];
                
                //NSArray *dishArray = [self.dishes filteredArrayUsingPredicate:predicate];
                
                //if([dishArray count])
                //{
                    //id currentDish = [dishArray objectAtIndex:0];
                    
                    NSString *title = [NSString stringWithFormat:@"#%i(%.1f) %@", [self.dishes indexOfObject:currentDish]+1,
                                       [[currentDish objectForKey:@"rating"] floatValue],
                                       [currentDish objectForKey:@"name"]];
                    NSString *subtitle = [NSString stringWithFormat:@" %@, %@", currentRestaurant.name, currentRestaurant.address];
                    
                    if(title == nil)
                        title = @"";
                    
                    if(subtitle == nil)
                        subtitle = @"";
                    
                    CustomAnnotation *annotation = 
                    [[CustomAnnotation alloc] initWithCoordinates:currentRestaurant.location.coordinate
                                                            title:title
                                                         subtitle:subtitle];
                    
                    annotation.tag = [self.dishes indexOfObject:currentDish];
                    [mapController.mapAnnotations addObject:annotation];
                    [annotation release];
                //}
            }
        }
    }
    
    [mapController gotoLocation];
}

- (IBAction)showOnMap:(id)sender
{
    mapController = [[GeneralMapController alloc] init];
    
    [self updateMapAnnotations];
    
    mapController.delegate = self;
    
    if(!self.subPageMode)
        mapController.showsRedo = YES;
    
    mapController.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:mapController animated:YES];
    [mapController viewWillAppear:YES];//ios4 crutch
    
    [mapController release];
}

/*
- (IBAction)setDistanceClick:(id)sender
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Select distance"
                                              delegate:self 
                                     cancelButtonTitle:@"Cancel" 
                                destructiveButtonTitle:nil
                                     otherButtonTitles:@"500 m", @"2 km", @"5 km", @"City", @"Globally", nil];
    
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackTranslucent;

    //[actionSheet showInView:self.view];
    [actionSheet showInView:self.view.window];
}
*/

- (IBAction)search:(id)sender
{
    //old search
    /*
    if(self.tableViewController.tableView.contentOffset.y == 0)
    {
        [self.tableViewController.tableView scrollRectToVisible:CGRectMake(0, 
                                                                           42, 
                                                                           320, 
                                                                           self.tableViewController.tableView.frame.size.height) 
                                                       animated:YES];
    }
    else
        [self.tableViewController.tableView scrollRectToVisible:CGRectMake(0, 0, 320, 10) animated:YES];
    */
 
    FilterController *filterController = [[FilterController alloc] init];
    [[DataSource instance].tabBar hideTabBar];
    filterController.delegate = self;
    //[self.navigationController pushViewController:_searchTipsController animated:YES];
    [[DataSource instance].tabBar presentModalViewController:filterController animated:YES];
    //[[DataSource instance].tabBar hideTabBar];
    [filterController release];
}	

- (void)getDishes
{    
    if(_requestProcessor != nil)
    {
        [_requestProcessor cancelRequest];
        _requestProcessor = nil;
        [self.tableViewController stopLoading];
    }
    
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    [ConvenientPopups showNonBlockingPopupOnView:self.view withText:@"Scanning for dishes..."];
    
    if(self.subPageMode)
    {
        if(self.userID)
        {
            _requestProcessor = [RequestProcessor getDishesForExpertID:self.userID];
            _requestProcessor.delegate = self;
            [_requestProcessor startRequest];
            return;
        }
        else
        if(self.savedMode) 
        {
            RequestProcessor *rp = [RequestProcessor getSavedDishes];
            rp.delegate = self;
            [rp startRequest];
            return;
        }
    }
    
    _requestProcessor = [[RequestProcessor alloc] init];
	_requestProcessor.delegate = self;
	
    _requestProcessor.offset = kRestaurantsPerPage * _currentPage;
    _requestProcessor.limit = kRestaurantsPerPage;
    
    NSNumber *lastDishID = [[self.dishes lastObject] objectForKey:@"id"];
    
    if(_currentPage == 0 || !lastDishID)
        lastDishID = [NSNumber numberWithInt:0];
    
    [_requestProcessor getDishListForUserCoordinates:self.userLocation 
                                         afterDishID:lastDishID
                                        searchString:self.searchString 
                                            distance:self.distanceFilter 
                                           keywordID:self.keywordID 
                                             sorting:self.searchSorting 
                                         priceRanges:self.priceRanges
                                                type:self.checkInListType];
    
    [_requestProcessor release];    
}

- (void)update
{
    for(UIView *view in _backgroundIV.subviews)
        [view removeFromSuperview];
    
    _isUpdating = YES;
    
    if(!self.searchString || [self.searchString isEqualToString:@""])
        _firstTimeLoading = YES;
    
    
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    
    //uncomment to activate location update
    //[[LocationManager instance] getUserLocation:self withType:LocationTypeLocation implicitly:NO];
    
    _currentPage = 0;
    _thereIsAnotherPage = YES;
    
    if(_rangeBarVC.searchOnMapActive)
        self.needsToUpdateLocation = NO;
    
    if([[UIDevice currentDevice] platformType] == UIDeviceiPhoneSimulatoriPhone ||
       [[UIDevice currentDevice] platformType] == UIDeviceiPhoneSimulatoriPad ||
        !self.needsToUpdateLocation
       )
    {
        [self getDishes];
        self.needsToUpdateLocation = YES;
    }
    else
    {
        self.searchNextToMapArea = NO;
        self.userLocation = nil;
        [ConvenientPopups showNonBlockingPopupOnView:self.view withText:@"Scanning for dishes..."];
        [[LocationManager instance] getUserLocation:self withType:LocationTypeLocation implicitly:YES];
    }
}

- (void)setRangePage:(NSInteger)page
{
    [_rangeBarVC setRangePage:page];
}

- (void)updateRangeOption:(NSInteger) rangeOption
{
    NSArray *distancesArray;
    
    if([Utils shouldUseMetricSystem])
    {
        distancesArray = kGlobalMetricDistanceOptions;
    }
    else
    {
        distancesArray = kGlobalMilesDistanceOptions;
    }
    
    self.distanceFilter = [distancesArray objectAtIndex:rangeOption];
    [self update];
}

#pragma mark -
#pragma mark LocationManager delegates

- (void) locationFound:(CLLocation*) location 
				 isNew:(BOOL)newLocation 
			sourceType:(int)type
{
    self.needsToUpdateLocation = YES;
    [ConvenientPopups closeNonBlockingPopupOnView:self.view];
    
    /*
    [ConvenientPopups showAlertWithTitle:@"Warning" 
							  andMessage:@"locationFound!"];
    */
    
	dlog(@"locationFound:%@ isNew:%i sourceType:%i", location, newLocation, type);
	self.userLocation = location;
	[self getDishes];
}

- (void) locationNotFound
{
    self.needsToUpdateLocation = YES;
	[ConvenientPopups closeNonBlockingPopupOnView:self.view];
    
    self.userLocation = kDefaultUserLocation;
    
    if(![DataSource instance].locationNoticeIsShown)
    {
        [ConvenientPopups showAlertWithTitle:@"Warning" 
							  andMessage:@"Your location cannot be determined. Please, give us permission to see your location, and we will show places near you. Otherwise, we will use New York as a default location."];
        [DataSource instance].locationNoticeIsShown = YES;
    }
    
	[self getDishes];
}



/*
#pragma mark -
#pragma mark UIScrollViewDelegate

- (void)setRangePage:(NSInteger)page
{
    if(_currentRangePage != page)
    {
        CGFloat horizontalShift = (page - _currentRangePage) * kScrollViewWindowSize;
        CGFloat duration = 0.5f * abs(horizontalShift) / 250.0f;
        
        [UIView beginAnimations:@"" context:nil];
        [UIView setAnimationDuration:duration];
        
        CGPoint center = self.selectRangeBullet.center;
        
        //dlog(@"center %f %f %i %i", center.x, center.y, page, _currentPage);
        
        if (page == 4)
            center.x = page * kScrollViewWindowSize + 27;
        else
            if (page == 3)
                center.x = page * kScrollViewWindowSize + 26;
            else
                center.x = page * kScrollViewWindowSize + 25.5f;
        
        self.selectRangeBullet.center = center;
        
        _currentRangePage = page;
        _currentRangeOption = page;
        
        [UIView commitAnimations];
        
        CGRect rectToScroll = CGRectMake(_currentRangeOption * kScrollViewWindowSize, 
                                         0, 
                                         kScrollViewWindowSize, 
                                         44);
        [_pagingScrollView scrollRectToVisible:rectToScroll animated:YES];
        
        [self updateRangeOption:page];
    }
}

- (void)scrollViewChanged:(UIScrollView *)scrollView
{    
    NSInteger page = scrollView.contentOffset.x/kScrollViewWindowSize;
    
    [self setRangePage:page];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [self scrollViewChanged:scrollView];
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    [self scrollViewChanged:scrollView];
}

 */
#pragma mark -
#pragma mark View lifecycle

- (void)viewDidLoad
{		
	[super viewDidLoad];
    
    if(![LoginController isLoggedIn])
        [LoggerController logEvent:@"NR user clicked get_dishes"];
    else
        [LoggerController logEvent:@"User clicked get_dishes"];
    
    
    if(self.subPageMode && self.title)
        [self.navigationItem setTitle:self.title];
    
    /*
    UIImage *buttonBackground = [UIImage imageNamed:@"HeaderButtonSquare.png"];
    
    UIButton *searchButton = [UIButton buttonWithType:UIButtonTypeCustom];
    searchButton.frame = CGRectMake(0, 
                                    0, 
                                    buttonBackground.size.width, 
                                    buttonBackground.size.height);
    
    [searchButton setBackgroundImage:buttonBackground forState:UIControlStateNormal];
    [searchButton setImage:[UIImage imageNamed:@"searchIcnBtn.png"] forState:UIControlStateNormal];
    [searchButton addTarget:self action:@selector(search:) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem = 
        [[UIBarButtonItem alloc] initWithCustomView:searchButton];
    
    buttonBackground = [UIImage imageNamed:@"BtnCommon.png"];
    */

    /*
    self.setDistanceButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.setDistanceButton.frame = CGRectMake(0, 
                                      0, 
                                      buttonBackground.size.width, 
                                      buttonBackground.size.height);
    [self.setDistanceButton setBackgroundImage:buttonBackground forState:UIControlStateNormal];
    [self.setDistanceButton setTitle:@"2km" forState:UIControlStateNormal];
    [self.setDistanceButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.setDistanceButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0f];
    [self.setDistanceButton addTarget:self action:@selector(setDistanceClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.setDistanceButton setTitleColor:[UIColor colorWithRed:97.0/255 green:40.0/255 blue:15.0/255 alpha:1.0f] forState:UIControlStateNormal];
    */
    
    /*
    UIButton *mapButton = [UIButton buttonWithType:UIButtonTypeCustom];
        mapButton.frame = CGRectMake(buttonBackground.size.width + 5, 
                                     0, 
                                     buttonBackground.size.width, 
                                     buttonBackground.size.height);
    [mapButton setBackgroundImage:buttonBackground forState:UIControlStateNormal];
    [mapButton setTitle:@"Map" forState:UIControlStateNormal];
    [mapButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    mapButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0f];
    [mapButton addTarget:self action:@selector(showOnMap:) forControlEvents:UIControlEventTouchUpInside];
    [mapButton setTitleColor:[UIColor colorWithRed:97.0/255 green:40.0/255 blue:15.0/255 alpha:1.0f] forState:UIControlStateNormal];
    
    UIView *rightBarItemView = [[UIView alloc] initWithFrame:CGRectMake(0, 
                                                                        0, 
                                                                        buttonBackground.size.width, 
                                                                        buttonBackground.size.height)];
    //[rightBarItemView addSubview:self.setDistanceButton];
    [rightBarItemView addSubview:mapButton];
    
    
    self.navigationItem.rightBarButtonItem = 
        [[UIBarButtonItem alloc] initWithCustomView:mapButton];
    */
        
	UIImage *backgroundImage = [UIImage imageNamed:@"Background.png"];
	_backgroundIV = [[UIImageView alloc] initWithImage:backgroundImage];
	[self.view addSubview:_backgroundIV];
    [_backgroundIV release];
    
    /*
    [[NSBundle mainBundle] loadNibNamed: @"RestaurantListTop" owner:self options:nil];
    [headerView setAutoresizingMask:UIViewAutoresizingNone];
    headerView.frame = CGRectMake(0, 0, 320, 37+18+44);

    [self.view addSubview:headerView];
    */
    
    /*
    UIButton *distanceButton = (UIButton *)[headerView viewWithTag:kDistanceTag];
    UIButton *sortByRatingButton = (UIButton *)[headerView viewWithTag:kSortByRatingButtonTag];
    UIButton *sortByDistanceButton = (UIButton *)[headerView viewWithTag:kSortByDistanceButtonTag];
    UIButton *mapButton = (UIButton *)[headerView viewWithTag:kMapButtonTag];
    

    [distanceButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [sortByRatingButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [sortByDistanceButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [mapButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    */
    
    if(self.subPageMode && self.savedMode)
    {
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Map" 
                                                                                  style:UIBarButtonItemStyleBordered
                                                                                 target:self 
                                                                                 action:@selector(showOnMap:)];
    }
	
	self.tableViewController = [[PullRefreshTableViewController alloc] initWithStyle:UITableViewStylePlain];
    
	self.tableViewController.tableView.frame = CGRectMake(0, 0, 320, 455);
	
    [self.view addSubview:self.tableViewController.view];
	
	self.tableViewController.parent = self;
	
	[self.tableViewController.tableView setDataSource:self];
	
	self.tableViewController.tableView.backgroundColor = [UIColor clearColor];
	self.tableViewController.tableView.opaque = NO;
	self.tableViewController.tableView.backgroundView = nil;
	
	self.tableViewController.tableView.tableFooterView = [[UIView new] autorelease];
	
	[self.tableViewController release]; //retained twice

    // Before getting location!
    [DataSource showHelpScreen:@"dishes_screen" onView:self.navigationController.view];
    
    [LocationManager initialize];
    
    if(!self.subPageMode)
    {
        if([[LocationManager instance] getLastLocation] == nil)
        {
            [ConvenientPopups showNonBlockingPopupOnView:self.view withText:@"Scanning for dishes..."];
            [[LocationManager instance] getUserLocation:self withType:LocationTypeLocation implicitly:YES];
        }
        else
        {
            self.userLocation = [[LocationManager instance] getLastLocation];
            [self getDishes];
        }
    }
    else
        [self getDishes];
    
    self.tableViewController.tableView.separatorColor = [UIColor clearColor];
    
    /*
     search section
     */
    
    if(!self.subPageMode)
    {
        _searchBar = [[UISearchBar alloc] init];
        _searchBar.frame = CGRectMake(0, 0, 320, 43);
        _searchBar.delegate = self;
        _searchBar.placeholder = @"Find: e.g. tiramisu, Carbonara";
        
        [[_searchBar.subviews objectAtIndex:0] removeFromSuperview];
        
        UIImage *searchBarBackgroundImage = [UIImage imageNamed:@"SearchBarBg.png"];
        
        UIImageView *searchBarBackgroundIV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 
                                                                                           0, 
                                                                                           searchBarBackgroundImage.size.width, 
                                                                                           searchBarBackgroundImage.size.height)];
        searchBarBackgroundIV.image = searchBarBackgroundImage;
        [_searchBar insertSubview:searchBarBackgroundIV atIndex:0];
        [searchBarBackgroundIV release];
        _searchBar.tintColor = kTintColor;
        
        
        //enables "search" key on keyboard when search bar text field contains empty string
        UITextField *searchBarTextField = nil;
        for (UIView *subview in _searchBar.subviews)
        {
            if ([subview isKindOfClass:[UITextField class]])
            {
                searchBarTextField = (UITextField *)subview;
                break;
            }
        }
        searchBarTextField.enablesReturnKeyAutomatically = NO;
        self.tableViewController.tableView.tableHeaderView = _searchBar;
        [_searchBar release];
    
    
        /*
         setting range bar
         */
        
        [[NSBundle mainBundle] loadNibNamed:@"RatingTitleView" owner:self options:nil];    
        self.navigationItem.titleView = _ratingTitleView;

        
        _rangeBarVC = [[RangeBarVC alloc] initWithCurrentRangeOption:_currentRangeOption]; 
        _rangeBarVC.delegate = self;
        
        [self.navigationItem.titleView insertSubview:_rangeBarVC.view atIndex:0];
        
        [self.navigationController.navigationBar bringSubviewToFront:self.navigationItem.titleView];
        
        /*
         eof setting range bar
         */
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(userFavouritedDishFromController:) 
                                                 name:@"userFavouritedDishFromController"
                                               object:nil];
}
 

#pragma mark - Notification processing

- (void)userFavouritedDishFromController:(NSNotification *)notification
{
    if(notification.object == self)
        return;
    else
    {
        NSNumber *dishID = [notification.userInfo objectForKey:@"dish_id"];
        
        if(self.dishes && [self.dishes isKindOfClass:[NSArray class]])
        {
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.id == %@", dishID];
            NSArray *filteredArray = [self.dishes filteredArrayUsingPredicate:predicate];
            
            if([filteredArray count])
            {
                NSDictionary *currentItem = [filteredArray objectAtIndex:0];
                NSNumber *saved = [currentItem objectForKey:@"favourite"];
                
                if([saved isKindOfClass:[NSNumber class]] && [saved boolValue])
                    [currentItem setValue:[NSNumber numberWithInt:0] forKey:@"favourite"];
                else
                    [currentItem setValue:[NSNumber numberWithInt:1] forKey:@"favourite"];
                
                [self.tableViewController.tableView reloadData];
            }
        }
    }
}

#pragma mark -
#pragma mark UITableViewDelegate Protocol

- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSInteger row = [indexPath row];
	NSInteger section = [indexPath section];
    
    if(section == 1)
    {
        NSDictionary *dish = [self.dishes objectAtIndex:row];
        
        NSInteger dishID = [[dish objectForKey:@"id"] intValue];

        CheckinType type = kCheckInListTypeRestaurants;
        
        NSString *typeString = [dish objectForKey:@"type"];
        
        if([typeString isKindOfClass:[NSString class]])
        {
            if([typeString isEqualToString:@"home_cooked"])
                type = kCheckInListTypeFriends;
            else if([typeString isEqualToString:@"delivery"])
                type = kCheckInListTypeDelivery;
        }
        
        
        DishController *dishController = [[DishController alloc] initWithDishId:dishID
                                                                     type:type];
        
        dishController.dishName = [[self.dishes objectAtIndex:row] objectForKey:@"name"];
        
        if(_searchBar.text != nil && ![_searchBar.text isEqualToString:@""])
            dishController.isFound = YES;
        
        dishController.title = dishController.dishName;
        [self.navigationController pushViewController:dishController animated:YES];
        [dishController release];
        
        [tableView deselectRowAtIndexPath:indexPath animated:NO];
    }
}

#pragma mark -
#pragma mark UITableViewDataSource Protocol

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
	return 3;
}

- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section
{
    if(section == 0)
    {
        if(self.subPageMode)
            return 0;
        
        return 1;
    }
    
    if(section == 1)
    {
        if([self.dishes count] > 0)
        {
            return [self.dishes count];
                
        }
        else
            return 0;
        
    }
    
    //load more/dead end
    if(section == 2)
    {
        if(self.subPageMode)
            return 0;
        
        if(([self.dishes count] > 0) //&& 
           //_thereIsAnotherPage
           //([self.dishes count] < _restaurantCount)
        )
            return 1;
        else
            return 0;
    }
    
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger section = [indexPath section];
    //NSInteger row = [indexPath row];
    
    if(section == 0)
        return kTopSectionHeight;
    
    if(section == 1)
    {
        return kRowHeight;
    }
    
    if(section == 2)
        return 70.0f;

    return 0;
}

- (NSString *)getSearchDescriptionForMap:(BOOL)forMap
{
    NSString *searchDescription = @"Searching by rating";
    
    NSString *rangeDiscription = @"";
    
    if(self.searchNextToMapArea)
    {
        searchDescription = [NSString stringWithFormat:@"Searching by %@, %@",
                             self.searchSorting, 
                             [Utils getPriceRangesPrettyString:self.priceRanges]];
    }
    else
    {
        if([self.distanceFilter isEqualToString:@"city"])
            rangeDiscription = @"in your city";
        else
            if([self.distanceFilter isEqualToString:@"global"])
                rangeDiscription = @"globally";
            else
            {
                if([Utils shouldUseMetricSystem])
                    rangeDiscription = [NSString stringWithFormat:@"in %.1f km near you", [self.distanceFilter floatValue]];
                else
                    rangeDiscription = [NSString stringWithFormat:@"in %.1f mi near you", [self.distanceFilter floatValue]*kMetersToMi*1000];
                
                //rangeDiscription = [NSString stringWithFormat:@"in %.1f km", [self.distanceFilter floatValue]];
            }
        searchDescription = [NSString stringWithFormat:@"Searching by %@, %@, %@",
                             self.searchSorting, 
                             rangeDiscription,
                             [Utils getPriceRangesPrettyString:self.priceRanges]];
    }
    
    if(forMap)
    {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"id == %@", self.keywordID];
        NSArray *filteredArray = [[DataSource instance].keywords filteredArrayUsingPredicate:predicate];
        
        if([filteredArray count])
        {
            searchDescription = [searchDescription stringByAppendingFormat:@". In category: %@", [[filteredArray objectAtIndex:0] objectForKey:@"name"]];
        }
        else
        {
            
        }
    }
    
    return searchDescription;
}

- (void)addToFavourites:(id) sender
{    
    if(![[LoginController instance] isLoggedIn])
    {
        [LoggerController logEvent:@"NR user clicked save to favourites"];
        
        [[LoginController instance] login];
        return;
    }
    
    [LoggerController logEvent:@"User clicked save to favourites"];
    
    UIButton *currentButton = (UIButton *)sender;
    UITableViewCell *cell = (UITableViewCell*) [[currentButton superview] superview];
    NSInteger row = [self.tableViewController.tableView indexPathForCell:cell].row;
    
    NSDictionary *currentDish = [self.dishes objectAtIndex:row];
    NSNumber *dishId = [currentDish objectForKey:@"id"];
    
    if(![dishId isKindOfClass:[NSNumber class]])
        return;
    
    // TODO: add fail callback, delivery dishes!
    RequestProcessor *rp = [RequestProcessor saveDishToFavourites:[dishId intValue] 
                                                             type:kCheckInListTypeRestaurants];
    [rp startRequest];
    
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"userFavouritedDishFromController" 
                                                        object:self 
                                                      userInfo:[NSDictionary dictionaryWithObject:dishId
                                                                                           forKey:@"dish_id"]];
    BOOL favourited = [[currentDish objectForKey:@"favourite"] boolValue];
    [currentDish setValue:[NSNumber numberWithBool:!favourited] 
                   forKey:@"favourite"];
    currentButton.selected = !favourited;
}

- (UITableViewCell *)tableView:(UITableView *)aTableView 
		 cellForRowAtIndexPath:(NSIndexPath *)indexPath
{	
	NSInteger row = [indexPath row];
	NSInteger section = [indexPath section];
    
    static NSString *cellIdentifier = @"";
    UITableViewCell *cell;
    
	id currentDish;
	
    static const NSInteger kSaveButtonTag = 1022;
    
    switch (section) {
        // Text description
        case 0:            
            cellIdentifier = @"RestaurantListControllerHeaderCell";
            
            cell = [aTableView dequeueReusableCellWithIdentifier:cellIdentifier];
            
            if (cell == nil) 
            {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
                
                self.keywordsView = [[KeywordsView alloc] initWithFrame:CGRectMake(0, 0, 320, 37)];
                self.keywordsView.delegate = self;

                self.keywordsView.keywords = [DataSource keywordNames];

                
                [self.keywordsView setKeywordSelected:0];
                
                [cell.contentView addSubview:self.keywordsView];
                [self.keywordsView release];
                
                UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 40, 320, 12)];
                label.tag = 789789456;
                label.font = [UIFont fontWithName:@"HelveticaNeue" size:12.0f];
                label.textColor = kBrownTextColor;
                label.shadowColor = [UIColor whiteColor];
                label.shadowOffset = CGSizeMake(0, 1);
                label.textAlignment = UITextAlignmentCenter;
                label.backgroundColor = [UIColor clearColor];
                [cell.contentView addSubview:label];
                [label release];
                
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
            }
            
            UILabel *label = (UILabel *)[cell.contentView viewWithTag:789789456];
            
            
            
            label.text = [self getSearchDescriptionForMap:NO];
            
            break;
        
        // Dish cell
        case 1:
            if(row < [self.dishes count])
            {
                currentDish = [self.dishes objectAtIndex:row];

                cellIdentifier = @"DishListControllerCell";
                
                cell = [aTableView dequeueReusableCellWithIdentifier:cellIdentifier];
                
                HJManagedImageV *managedIV = nil;
                
                UIView *imagePlaceholder = nil;
                
                if (cell == nil) 
                {
                    [[NSBundle mainBundle] loadNibNamed: @"DishListControllerCell" owner:self options:nil];
                    cell = tableCell;
                    self.tableCell = nil;
  
                    UIScrollView *scrollView = (UIScrollView *)[cell viewWithTag:kScrollViewTag];
                    UIView *shadowView = (UIView *)[cell viewWithTag:kShadowViewTag];
                    //CGSize onePageSize = scrollView.frame.size;
                    
                    /*
                     managedIV
                     */
                    imagePlaceholder = [cell viewWithTag:kPhotoPlaceholderTag];
                    managedIV = [[HJManagedImageV alloc] initWithFrame:imagePlaceholder.frame];
                    managedIV.tag = kFirstManagedIVTag;
                    managedIV.layer.masksToBounds = YES;
                    managedIV.layer.cornerRadius = 3;
                    [cell addSubview:managedIV];
                    //[imagePlaceholder removeFromSuperview];

                    
                    /*
                    cell.backgroundColor = [UIColor clearColor];
                    cell.backgroundView.backgroundColor = [UIColor clearColor];
                    cell.contentView.backgroundColor = [UIColor clearColor];
                    */
                    
                    //selected state
                    cell.selectedBackgroundView = [[UIView new] autorelease];
                    cell.selectedBackgroundView.layer.masksToBounds = YES;
                    cell.selectedBackgroundView.layer.cornerRadius = 3;
                    
                    UIView *background = (UIView *)[cell viewWithTag:kBackgroundTag];

                    background.layer.masksToBounds = YES;
                    background.layer.cornerRadius = 3;
                    
                    background.layer.shadowOffset = CGSizeMake(0, 3);
                    background.layer.shadowRadius = 1;
                    background.layer.shadowOpacity = 0.3;
                    background.layer.shadowPath = [UIBezierPath bezierPathWithRect:background.bounds].CGPath;
                    
                    
                    shadowView.layer.masksToBounds = NO;
                    shadowView.layer.cornerRadius = 3;
                    shadowView.layer.shadowOffset = CGSizeMake(0, 1);
                    shadowView.layer.shadowRadius = 1;
                    shadowView.layer.shadowOpacity = 0.3;
                    shadowView.layer.shadowPath = [UIBezierPath bezierPathWithRect:background.bounds].CGPath;
                    //cell.selectionStyle = UITableViewCellSelectionStyleNone;
                    
                    
                    UIButton *saveButton = (UIButton *)[cell viewWithTag:kSaveButtonTag];
                    [saveButton addTarget:self 
                                   action:@selector(addToFavourites:) 
                         forControlEvents:(UIControlEventTouchUpInside)];
                    
                }
                else
                {
                    managedIV = 
                        (HJManagedImageV*)[cell viewWithTag:kFirstManagedIVTag];

                    [managedIV clear];
                }

                //cell cleaning
                imagePlaceholder = [cell viewWithTag:kPhotoPlaceholderTag];
                                                
                for(NSInteger i=1;i<=5;i++)
                {
                    UIImageView *star = (UIImageView *)[cell.contentView viewWithTag:i];
                    star.highlighted = NO;
                }
                
                imagePlaceholder.hidden = YES;

            
                // Setting values
                UILabel *nameLabel = (UILabel *)[cell viewWithTag:DEAL_NAME_TAG];
                UILabel *restaurantLabel = (UILabel *)[cell viewWithTag:kRestaurantLabelTag];
                
                UILabel *addressLabel = (UILabel *)[cell viewWithTag:kAddressTag];
                UILabel *distanceLabel = (UILabel *)[cell viewWithTag:kDistanceTag];
                UILabel *votesLabel = (UILabel *)[cell viewWithTag:kVotesTag];
                UILabel *ratingLabel = (UILabel *)[cell viewWithTag:kRatingPositionTag];
                UIButton *saveButton = (UIButton *)[cell viewWithTag:kSaveButtonTag];
                
                
                // Save/Saved button
                saveButton.selected = NO;
                NSNumber *favourited = [currentDish objectForKey:@"favourite"];
                if([favourited isKindOfClass:[NSNumber class]] && [favourited boolValue])
                {
                    saveButton.selected = YES;
                }
                
                nameLabel.text = [currentDish objectForKey:@"name"];
                
                
                if(self.checkInListType == kCheckInListTypeFriends)
                    restaurantLabel.text = @"Home";
                else
                    restaurantLabel.text = [[currentDish objectForKey:@"network"] objectForKey:@"name"];
                
                float rating = 0;
                id ratingObj = [currentDish objectForKey:@"rating"];
                if([ratingObj isKindOfClass:[NSNumber class]])
                    rating = [ratingObj floatValue];
               
                
                NSInteger votes = 0;
                id votesObj = [currentDish objectForKey:@"rating"];
                if([votesObj isKindOfClass:[NSNumber class]])
                    votes = [[currentDish objectForKey:@"votes"] intValue];
                
                
                NSString *priceString = @"";
                NSNumber *priceObj = [currentDish objectForKey:@"price"];
                NSString *currencyObj = [currentDish objectForKey:@"currency"];
                
                if([priceObj isKindOfClass:[NSNumber class]] && ([priceObj floatValue] != 0.0))
                {
                    if([currencyObj isKindOfClass:[NSString class]])
                        priceString = [NSString stringWithFormat:@", %@ %@", priceObj, currencyObj];
                    else
                        priceString = [NSString stringWithFormat:@", %@", priceObj];
                }
                
                addressLabel.text = @"";
                distanceLabel.text = @"";
                
                votesLabel.text = [NSString stringWithFormat:@"%i votes%@", votes, priceString];
                
                ratingLabel.text = [NSString stringWithFormat:@"#%i", row+1];
                               
                StarView *starView = [[StarView alloc] init];
                [starView updateRating:[NSNumber numberWithFloat:rating]
                                onView:cell.contentView];
                [starView release];
                
                //uncomment for testing
                //self.userLocation = [[CLLocation alloc] initWithLatitude:55.710065 longitude:37.623892];
                
                
                NSNumber *networkID = [[currentDish objectForKey:@"network"] objectForKey:@"id"];
                NSPredicate *predicate = [NSPredicate predicateWithFormat:@"networkId == %@", networkID];
                
                NSArray *restaurants = [self.restaurants filteredArrayUsingPredicate:predicate];                    
                
                float minDistance = FLT_MAX;
                RestaurantModel *nearestRestaurant = nil;
                
                if([restaurants isKindOfClass:[NSArray class]] && [restaurants count])
                {
                    
                    if(self.userLocation != nil)
                    {
                        CLLocation *nearestLocation = nil;
                        
                        for(RestaurantModel *restaurant in restaurants)
                        {
                            if(restaurant.location != nil)
                            {
                                float currentDistance = [Utils distanceFromLocation:restaurant.location 
                                                                         toLocation:userLocation];
                                if(currentDistance < minDistance)
                                {
                                    minDistance = currentDistance;
                                    nearestRestaurant = restaurant;
                                    
                                    [nearestLocation release];
                                    nearestLocation = restaurant.location;
                                    [nearestLocation retain];
                                }
                            }
                        }
                        
                        if(nearestLocation)
                        {
                            dlog(@"nearestLocation");
                            distanceLabel.text = [Utils stringForDistanceFromLocation:self.userLocation 
                                                                           toLocation:nearestLocation];
                        }                        
                    }
                    else
                        nearestRestaurant = [restaurants objectAtIndex:0];
                    
                    addressLabel.text = nearestRestaurant.address; //[nearestRestaurant objectForKey:@"address"];
                }                    
                
    
                //dish photo
                NSString *dishPhotoURLString = [currentDish objectForKey:@"image_sd"];
                
                BOOL photoIsPresent = NO;
                
                if([dishPhotoURLString isKindOfClass:[NSString class]])
                if(![dishPhotoURLString isEqualToString:@""])
                {
                    photoIsPresent = YES;
                    
                    managedIV.url = 
                        [NSURL URLWithString:[NSString stringWithFormat:@"%@%@", [DataSource instance].imageBaseURL, dishPhotoURLString]];
                    
                    [managedIV showLoadingWheel];
                    
                    managedIV.loadingWheel.frame = 
                        CGRectMake(managedIV.frame.origin.x + (managedIV.frame.size.width - 20)/2 - 11, 
                                   managedIV.frame.origin.y + (managedIV.frame.size.height - 20)/2 - 9, 
                                   20, 
                                   20);
                    [_objMan manage:managedIV];
                    
                    imagePlaceholder.hidden = YES;
                }
                
                if(!photoIsPresent)
                    imagePlaceholder.hidden = NO;
            }
            
            break;
            
        case 2:
            cellIdentifier = @"RestaurantListBottom";
            
            cell = [aTableView dequeueReusableCellWithIdentifier:cellIdentifier];
            
            static const NSInteger wheelTag = 456123789;
            
            if (cell == nil) 
            {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
                
                cell.contentView.backgroundColor = [UIColor colorWithRed:242.0/255 green:239.0/255 blue:234.0/255 alpha:1.0];
                
                UIActivityIndicatorView *wheel = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                
                [wheel startAnimating];
                wheel.center = CGPointMake(300, 70.0f/2);
                wheel.tag = wheelTag;
                wheel.hidesWhenStopped = YES;
                [cell addSubview:wheel];
                
                cell.textLabel.numberOfLines = 0;
                cell.textLabel.textAlignment = UITextAlignmentCenter;
                
                cell.textLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:12.0f];
                cell.textLabel.textColor = kBrownTextColor;
                cell.textLabel.shadowColor = [UIColor whiteColor];
                cell.textLabel.shadowOffset = CGSizeMake(0, 1);

                
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                cell.backgroundColor = [UIColor clearColor];
                cell.backgroundView.backgroundColor = [UIColor clearColor];
                cell.contentView.backgroundColor = [UIColor clearColor];
            }
            
            //resetting cell
            UIActivityIndicatorView *wheel = (UIActivityIndicatorView *)[cell viewWithTag:wheelTag];
            [wheel startAnimating];
            
            if(!_thereIsAnotherPage)
            {
                [wheel stopAnimating];
                
                cell.textLabel.text = @"Seems that this is a dead end! Yep, that's it, nothing more to see here.";
            }
            else
            {
                cell.textLabel.text = @"Loading more...";
            }
            
            if(!_isLoadingMoreRestaurants && !_isUpdating && _thereIsAnotherPage)
            {
                [LoggerController logEvent:@"User downloaded next 25 in get_dishes"];
                
                _isLoadingMoreRestaurants = YES;
                _currentPage++;
                [self getDishes];
            }
            break;
            
        default:
            break;
    }
    
	return cell;
}


#pragma mark -
#pragma mark KeywordViewDelegate

- (void)keywordPressed:(NSString *)aKeyword
{    
    _searchBar.text = @"";
    self.searchString = @"";
    
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@", aKeyword];
    NSArray *filteredArray = [[DataSource instance].keywords filteredArrayUsingPredicate:predicate];
    
    if([filteredArray count])
        self.keywordID = [[filteredArray objectAtIndex:0] objectForKey:@"id"];

    self.needsToUpdateLocation = NO;
    _isLoadingMoreRestaurants = NO;
    [self update];
}

#pragma mark -
#pragma mark UISearchBarDelegate

/*
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar 
{    
    
}

- (void)searchFromSearchBar
{
    self.keyword = @"";
    [self.keywordsView selectNone];
    
    _searchBar.text = self.searchString;
    [_searchBar resignFirstResponder];
    
    _isLoadingMoreRestaurants = NO;
    [self update];
}
*/

//old KeywordViewDelegate
#pragma mark -
#pragma mark KeywordViewDelegate

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar 
{
    [self.tableViewController stopLoading];
    
    self.tableViewController.tableView.scrollEnabled = NO;
    [self.tableViewController.tableView scrollRectToVisible:CGRectMake(0, 0, 320, 10) animated:YES];
    
    searchBar.showsScopeBar = YES;
    [searchBar sizeToFit];
    [searchBar setShowsCancelButton:YES animated:YES];
    
    if(!_searchTipsController)
    {
        _searchTipsController = [[SearchTipsController alloc] initWithType:kSearchTipsTypeDishes];
        //_searchTipsController = [[RestaurantSearchController alloc] init];

        _searchTipsController.delegate = self;
    }
    
    _searchTipsController.view.frame = CGRectMake(self.tableViewController.tableView.frame.origin.x, 
                                                  self.tableViewController.tableView.frame.origin.y+44,
                                                  self.tableViewController.tableView.frame.size.width, 
                                                  self.tableViewController.tableView.frame.size.height-44-210+49);
    if(![_searchTipsController.view superview])
    {
        _searchTipsController.view.frame = CGRectMake(self.tableViewController.tableView.frame.origin.x, 
                                                      self.tableViewController.tableView.frame.origin.y+44,
                                                      self.tableViewController.tableView.frame.size.width, 
                                                      0);
        
        [self.view addSubview:_searchTipsController.view];
        
        [UIView beginAnimations:@"Search tips drop out" context:nil];
        [UIView setAnimationDuration:0.3f];
        
        _searchTipsController.view.frame = CGRectMake(self.tableViewController.tableView.frame.origin.x, 
                                                      self.tableViewController.tableView.frame.origin.y+44,
                                                      self.tableViewController.tableView.frame.size.width, 
                                                      self.tableViewController.tableView.frame.size.height-44-210+49);
        [UIView commitAnimations];
    }
    
    return YES;
    
}

- (void)searchBarEndEditing
{
    self.tableViewController.tableView.scrollEnabled = YES;
    
    _searchBar.showsScopeBar = NO;
	[_searchBar sizeToFit];
	[_searchBar setShowsCancelButton:NO animated:YES];
    [_searchBar resignFirstResponder];
    
    [_searchTipsController.view removeFromSuperview];
}

- (void)blockerClick
{
    [self searchBarEndEditing];
    _searchBar.text = self.searchString;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar 
{
	[self searchBarEndEditing];
    
	return YES;
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar 
{
    for(UIView *view in _backgroundIV.subviews)
        [view removeFromSuperview];
    
    searchBar.text = @"";
    self.searchString = @"";
    
    
    //[self.keywordsView setKeywordSelected:0];
    _thereIsAnotherPage = YES;
    
    if(self.dishes && [self.dishes count])
    {    
        /*
        if(_requestProcessor != nil)
        {
            _requestProcessor = nil;
            [_requestProcessor cancelRequest];
        }
        
        [ConvenientPopups closeNonBlockingPopupOnView:self.view];
        */
        
        self.dishes = [self.firstTimeItemsList mutableCopy];
        [self.dishes release];
        
        self.restaurants = [self.firstTimeRestaurants mutableCopy];
        [self.restaurants release];
    }
    
    self.keywordID = nil;
    
    [self.tableViewController.tableView reloadData];
    
    [searchBar resignFirstResponder];
    [searchBar setShowsCancelButton:NO animated:YES];
}

- (void)searchFromSearchBar
{
    //self.keyword = @"";
    [self.keywordsView setKeywordSelected:0];
    
    _searchBar.text = self.searchString;
    [_searchBar resignFirstResponder];
    
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@", self.searchString];
    NSArray *filteredArray = [[DataSource instance].searchTips filteredArrayUsingPredicate:predicate];
    
    if([filteredArray count])
    {
        self.keywordID = [[filteredArray objectAtIndex:0] objectForKey:@"id"];
        self.searchString = @"";
    }
    else
        self.keywordID = nil;
    
    _isLoadingMoreRestaurants = NO;
    [self update];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    self.searchString = searchBar.text;
    [self searchFromSearchBar];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    [_searchTipsController setSearchString:searchText];
    
    /*
    if([searchText isEqualToString:@""])
    {
        
        
        if(_requestProcessor != nil)
        {
            [_requestProcessor cancelRequest];
            _requestProcessor = nil;
            [self.tableViewController stopLoading];
        }
        
        self.searchString = @"";
        self.dishes = [self.firstTimeItemsList mutableCopy];
        [self.dishes release];
        [self.tableViewController.tableView reloadData];
    }
     */
}

- (void)addressClose
{
    [_rangeBarVC addressClose:nil];
}

@end
