#import <UIKit/UIKit.h>
#import "JSON.h"
#import "PullRefreshTableViewController.h"
#import "LocationManager.h"
#import "HJObjManager.h"
#import "HJManagedImageV.h"
#import "RequestProcessor.h"
#import "KeywordsView.h"
#import "MapForRestaurants.h"
#import "GeneralMapController.h"
//#import "PagingScrollView.h"
#import "SearchTipsController.h"
#import "AdvancedSearchController.h"
#import "RangeBarVC.h"
#import "CheckinType.h"

@class MapForRestaurants;

@interface DishListController : UIViewController<UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, LocationManagerDelegate, KeywordsViewDelegate>
{
	IBOutlet UITableViewCell *tableCell;
    IBOutlet UIView *_ratingTitleView;
    IBOutlet UIView *_rangeBarView;
    
    
    BOOL _firstTimeLoading;
    BOOL _isLoadingMoreRestaurants;
    BOOL _isUpdating;
    NSInteger _currentPage;
    NSInteger _restaurantCount;
    
    HJObjManager *_objMan;
    
    RequestProcessor *_requestProcessor;
    
    UISearchBar *_searchBar;
    NSString *sorting;
    
    GeneralMapController *_mapController;
    
    NSInteger _currentRangeOption;
    NSInteger _currentRangePage;
    
    PagingScrollView *_pagingScrollView;
    
    //SearchTipsController *_searchTipsController;
    AdvancedSearchController *_searchTipsController;
    BOOL _thereIsAnotherPage;
    
    RangeBarVC *_rangeBarVC;
    UIImageView *_backgroundIV;
}

@property (retain, nonatomic) IBOutlet UIImageView *selectRangeBullet;
@property (nonatomic, retain) PullRefreshTableViewController *tableViewController;
@property (nonatomic, retain) IBOutlet UITableViewCell *tableCell;
@property (nonatomic, retain) UILabel *cityLabel;
@property (nonatomic, retain) id currentCity;
@property (nonatomic, retain) NSMutableArray *dishes;
@property (nonatomic, copy) NSArray *firstTimeItemsList;
@property (nonatomic, copy) NSArray *firstTimeRestaurants;
@property (nonatomic, retain) id currentCategory;
@property (nonatomic, retain) id categories;
@property (nonatomic, retain) id delegate;
@property (nonatomic, retain) KeywordsView *keywordsView;

/*
 Search options
 */

@property (nonatomic, copy) NSString *searchString;
@property (nonatomic, retain) CLLocation *userLocation;
@property (nonatomic, retain) NSString *distanceFilter;
@property (nonatomic, retain) NSNumber *keywordID;
@property (nonatomic, retain) NSString *searchSorting;
@property (nonatomic, retain) NSMutableArray *priceRanges;

@property (nonatomic, retain) IBOutlet UIView *headerView;

@property (retain, nonatomic) IBOutlet UIButton *setDistanceButton;
@property (retain, nonatomic) IBOutlet UIButton *sortByRatingButton;
@property (retain, nonatomic) IBOutlet UIButton *sortByDistanceButton;
@property (assign, nonatomic) GeneralMapController *mapController;
@property (assign, readwrite) BOOL needsToUpdateLocation;
@property (retain, nonatomic) NSMutableArray *restaurants;

@property (readwrite, assign) BOOL searchNextToMapArea;
@property (readwrite, assign) CheckinType checkInListType;

@property (nonatomic, retain) NSNumber *userID;

// When appears from profile should be set to YES
@property (readwrite, assign) BOOL subPageMode;

// Saved dishes (from profile)
@property (readwrite, assign) BOOL savedMode;

- (void)update;

- (IBAction)selectRangeButtonClick:(id)sender;
- (IBAction)showOnMap:(id)sender;
- (IBAction)selectRangeButtonClick:(id)sender;
- (IBAction)search:(id)sender;

@end
