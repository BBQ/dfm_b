#import "dishAppDelegate.h"
#import "MainViewController.h"
#import "LoginController.h"
#import "LoggerController.h"
//#import "TestFlight.h"
#import "RequestProcessor.h"
#import "DataSource.h"
#import "ConvenientPopups.h"
#import "Crittercism.h"
#import "AlertView.h"
#import "Config.h"
#import "Utils.h"
#import "Dialog.h"
//#import "GANTracker.h"
#import "LocalyticsSession.h"
#import "IntroVC.h"
#import "TapjoyConnect.h"

// GA Dispatch period in seconds
static const NSInteger kGANDispatchPeriodSec = 10;

@implementation dishAppDelegate

@synthesize window;
@synthesize viewController;

#pragma mark -
#pragma mark Application lifecycle




- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    

    //remove in release builds!
    //[[UIApplication sharedApplication] unregisterForRemoteNotifications];
    
    /*
     Crittercism
     */
    [Crittercism initWithAppID: @"4f630357b0931566f000023a"
                        andKey:@"cgkphczfwgb1qnuk8xd3plvntjjr"
                     andSecret:@"u607kgmfojbcforqexdclpy29uwilvgj"];
    
    /*
     Tapjoy
     */
    [TapjoyConnect requestTapjoyConnect:@"dec28e42-0258-4daa-b1bc-e4d67bf432c0" secretKey:@"xnw4bxTj8K1jJJChMr0U"];
    
    
    //[TestFlight takeOff:@"451e836581cdcded0c7ddb46cc460f43_MzY5NDUyMDExLTEyLTIxIDA2OjI3OjU3LjE2MDc0NA"];
    
    [FlurryAnalytics startSession:@"TGAM9BV5Z3UUMILPW73Y"];
    [[LocalyticsSession sharedLocalyticsSession] startSession:@"fc9b340ffd041163d584d42-d1b08880-a3d1-11e1-3b12-00ef75f32667"];
    
    // Google analytics
    /*
     [[GANTracker sharedTracker] startTrackerWithAccountID:@"UA-31149545-1"
     dispatchPeriod:kGANDispatchPeriodSec
     delegate:nil];
     */
    
    [self.window addSubview:viewController.view];
    [self.window makeKeyAndVisible];
    
    
    
    
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    
    
    NSNumber *isIntroShown = [defaults objectForKey:@"isIntroShown"];
    
    if(isIntroShown == nil)
    {
        IntroVC *ivc = [[IntroVC alloc] init];
        [viewController presentModalViewController:ivc animated:NO];
        [ivc release];
    }
    
    
    NSInteger launchCount = [defaults integerForKey:@"launchCount" ] + 1;
    dlog(@"launchCount %i", launchCount);
    [defaults setInteger:launchCount forKey:@"launchCount"];
    [defaults synchronize];
    
    if(launchCount == 1)
    {
        [LoggerController logEvent:@"1st time in the app"];
    }
    
    BOOL askForRating = YES;
    NSNumber *neverShowRateInAppStoreDialogNumber = [defaults objectForKey:@"neverShowRateInAppStoreDialog"];
    if(neverShowRateInAppStoreDialogNumber && [neverShowRateInAppStoreDialogNumber isKindOfClass:[NSNumber class]])
        askForRating = ![neverShowRateInAppStoreDialogNumber boolValue];
        
    if(launchCount % kNUmberOfApplicationStartsBeforeAskForRating == 0 && askForRating)
    {
        Dialog *di = [[Dialog alloc] init];
        [di showRatingDialog];
        [di release];
        
        /*
        AlertView* view = [[AlertView alloc] initWithTitle:@"" 
                                                   message:@"It look like you're enjoying dish.fm! Will you give us five star rating? (Please-Please-Please-Pretty please)"];
        
        [view addButtonWithTitle:@"No" block:[[^(AlertView* a, NSInteger i){} copy] autorelease]];
        
        [view addButtonWithTitle:@"Yes" block:[[^(AlertView* a, NSInteger i){
            [Utils rateInAppstore];
        } copy] autorelease]];
        
        [view show];
        [view release];
         */
    }

    if(launchCount == kNUmberOfApplicationStartsBeforeAskToShare)
    {
        Dialog *di = [[Dialog alloc] init];
        [di showSharingDialog];
        [di release];
    }
    
    NSDictionary* userInfo = [launchOptions valueForKey:@"UIApplicationLaunchOptionsRemoteNotificationKey"];
    NSDictionary *apsInfo = [userInfo objectForKey:@"aps"];

    if([UIApplication sharedApplication].applicationIconBadgeNumber)
    {
        [DataSource instance].numberOfNotifications = [UIApplication sharedApplication].applicationIconBadgeNumber;
        [DataSource instance].openedWithPushTokenBadge = YES;        
        [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    }
    
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    
    // No dialog for now
    /*
    NSNumber *askForLocationDialogIsShown = [defaults objectForKey:@"askForPushTokenDialogIsShown"];
    if(!askForLocationDialogIsShown)
    {
        [defaults setObject:[NSNumber numberWithBool:YES] forKey:@"askForPushTokenDialogIsShown"];
        [defaults synchronize];
        
        Dialog *dialog = [[Dialog alloc] init];
        dialog.delegate = self;
        [dialog showAskForPushTokenDialog];
        [dialog release];
    }
    */
    


    [self performSelector:@selector(changeSplash) withObject:nil afterDelay:3];
    return YES;
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    //UIApplicationState state = [application applicationState];
    
    if (!_applicationIsActive)
    {
        [DataSource instance].numberOfNotifications = [UIApplication sharedApplication].applicationIconBadgeNumber;
        [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
        
        [[NSNotificationCenter defaultCenter] 
         postNotificationName:@"appplicationBecameActiveWithPushNotification" 
         object:self];
    }
    else
    {
        
        [DataSource instance].numberOfNotifications ++;
        
        [[NSNotificationCenter defaultCenter] 
         postNotificationName:@"updateNotificationNumber" 
         object:self];
    }
}

- (void)applicationWillResignActive:(UIApplication *)application 
{
    _applicationIsActive = NO;
    
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application 
{
    _applicationIsActive = YES;
    
    if([UIApplication sharedApplication].applicationIconBadgeNumber)
    {
        [DataSource instance].numberOfNotifications = [UIApplication sharedApplication].applicationIconBadgeNumber;
        //[DataSource instance].openedWithPushTokenBadge = YES;
        
        [[NSNotificationCenter defaultCenter] 
         postNotificationName:@"updateNotificationNumber" 
         object:self];
        
        [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    }
    
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
    
    [[LocalyticsSession sharedLocalyticsSession] close];
    [[LocalyticsSession sharedLocalyticsSession] upload];
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
    
    [[LocalyticsSession sharedLocalyticsSession] resume];
    [[LocalyticsSession sharedLocalyticsSession] upload];
}





- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
    
    [[LocalyticsSession sharedLocalyticsSession] close];
    [[LocalyticsSession sharedLocalyticsSession] upload];
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
    //[[GANTracker sharedTracker] stopTracker];
    [viewController release];
    [window release];
    [super dealloc];
}

#pragma mark -
#pragma mark Facebook stuff

// Pre 4.2 support
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url 
{
	//dlog(@"Pre 4.2");
    return [[LoginController instance].facebook handleOpenURL:url]; 
}

// For 4.2+ support
- (BOOL)application:(UIApplication *)application 
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication 
         annotation:(id)annotation 
{
	//dlog(@"4.2+");
    return [[LoginController instance].facebook handleOpenURL:url]; 
}


#pragma mark - Push ntifications
- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    [LoggerController logEvent:@"push notification token added"];
    
	dlog(@"My token is: %@", deviceToken);
    
    NSString* newToken = [deviceToken description];
	newToken = [newToken stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    newToken = [newToken stringByReplacingOccurrencesOfString:@"<" withString:@""];
    newToken = [newToken stringByReplacingOccurrencesOfString:@">" withString:@""];
    
    [DataSource instance].pushToken = newToken;
    [[DataSource instance] saveToFile];
    
    RequestProcessor *requestProcessor = [[RequestProcessor alloc] init];
    [requestProcessor addPushToken:newToken];
    [requestProcessor release];
}

- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
    [LoggerController logEvent:@"user prohibited remote notifications"];
    
	dlog(@"Failed to get token, error: %@", error);
}

#pragma mark - Dialog

- (void)dialogClosed
{
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
}

- (void)changeSplash
{
    // Change splash image
    NSString *sourceSplash =
    [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"Splash%i", arc4random()%3+1]
                                    ofType:@"png"];
    
    NSString *sourceSplash2 =
    [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"Splash%i@2x", arc4random()%3+1]
                                    ofType:@"png"];
    
    
    NSUserDefaults *df = [NSUserDefaults standardUserDefaults];
    
    NSString *destinationSplash = [df objectForKey:@"Splash"];
    NSString *destinationSplash2 = [df objectForKey:@"Splash2x"];
    
    
    if(!destinationSplash || !destinationSplash2) 
    {
        destinationSplash =
        [[NSBundle mainBundle] pathForResource:@"Default"
                                        ofType:@"png"];
        
        destinationSplash2 =
        [[NSBundle mainBundle] pathForResource:@"Default@2x"
                                        ofType:@"png"];
        
        [df setObject:destinationSplash forKey:@"Splash"];
        [df setObject:destinationSplash2 forKey:@"Splash2x"];
        
        [df synchronize];
    }
    
    dlog(@"%@ %@ %@ %@ ", sourceSplash, sourceSplash2, destinationSplash, destinationSplash2);
    
    
    if(sourceSplash && sourceSplash2 && destinationSplash && destinationSplash2)
    {
        NSError *error1 = [[NSError alloc] init];
        NSError *error2 = [[NSError alloc] init];
        
        [[NSFileManager defaultManager] removeItemAtPath:destinationSplash error:&error1];
        [[NSFileManager defaultManager] removeItemAtPath:destinationSplash2 error:&error2];
        
        //dlog(@"errors: %@ %@", error1, error2);
        
        [[NSFileManager defaultManager] copyItemAtPath:sourceSplash toPath:destinationSplash error:&error1];
        [[NSFileManager defaultManager] copyItemAtPath:sourceSplash2 toPath:destinationSplash2 error:&error2];
        
        //dlog(@"errors: %@ %@", error1, error2);
    }
}

@end