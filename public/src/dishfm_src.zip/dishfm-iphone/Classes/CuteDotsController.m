//
//  CuteDotsController.m
//  dish.fm
//
//  Created by Petr Prokop on 1/25/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "CuteDotsController.h"
#import <QuartzCore/QuartzCore.h>

@implementation CuteDotsController

@synthesize view;

//static const 

- (id)initWithFrame:(CGRect) frame
{
    self = [super init];
    
    if(self)
    {
        self.view = [[UIView alloc] initWithFrame:frame];
        [self.view release];
        
        _viewsArray = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (void)dealloc
{
    self.view = nil;
    
    [_viewsArray release];
    
    [super dealloc];
}

#define kBeigeColor  [UIColor colorWithRed:246.0f/255 \
                                      green:245.0f/255 \
                                       blue:242.0f/255 \
                                      alpha:1.0f]

#define kGrayColor  [UIColor colorWithRed:205.0f/255 \
                                     green:200.0f/255 \
                                      blue:194.0f/255 \
                                     alpha:1.0f]

#define  kBrownColor  [UIColor colorWithRed:49.0f/255 \
                                      green:26.0f/255 \
                                       blue:3.0f/255 \
                                      alpha:1.0f]

- (void)setNumberOfDots:(NSInteger)numberOfDots
               andPhoto:(BOOL)photo
{
    static const CGFloat barHeight = 12.0f;
    static const CGFloat spaceBetweenDots = 4.0f;
    static const CGFloat dotSize = 7.0f;
    static const CGFloat dotVerticalOffset = 2.0f;
    
    _numberOfDots = numberOfDots;
    _photo = photo;
    
    
    //cleaning
    for(UIView *view in self.view.subviews)
    {
        [view removeFromSuperview];
    }
    
    [_viewsArray removeAllObjects];
    
    UIView *holder = [[UIView alloc] init];
    [self.view addSubview:holder];
    [holder release];
    
    //UIView *background1;
    CGFloat horizontalShift = spaceBetweenDots*2;
    
    for(NSInteger i=0; i<numberOfDots; i++)
    {
        UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(horizontalShift, 
                                                               dotVerticalOffset, 
                                                               dotSize, 
                                                               dotSize)];
        [holder addSubview:dot];
        dot.backgroundColor = kGrayColor;
        dot.layer.cornerRadius = dotSize/2;
        dot.layer.masksToBounds = YES;
        [_viewsArray addObject:dot];
        [dot release];
        
        horizontalShift += spaceBetweenDots + dotSize;
    }
    
    //horizontalShift += spaceBetweenDots;
    
    if(photo)
    {
        UIImage *photoImage = [UIImage imageNamed:@"dot-photo-inactive.png"];
        UIImageView *dot = [[UIImageView alloc] initWithFrame:CGRectMake(horizontalShift, 
                                                               dotVerticalOffset - 2.0f, 
                                                               photoImage.size.width, 
                                                               photoImage.size.height)];
        dot.image = photoImage;
        [holder addSubview:dot];

        [_viewsArray addObject:dot];
        [dot release];
        
        horizontalShift += spaceBetweenDots + dotSize;
    }
    
    horizontalShift += spaceBetweenDots;
    
    holder.frame = CGRectMake((self.view.frame.size.width - horizontalShift)/2, 
                              0, 
                              horizontalShift, 
                              barHeight+1);
    
    UIView *mostBottomBg = [[UIView alloc] initWithFrame:CGRectMake(0, 
                                                                    0, 
                                                                    horizontalShift, 
                                                                    barHeight/2)];
    mostBottomBg.backgroundColor = kBeigeColor;
    [holder insertSubview:mostBottomBg atIndex:0];
    [mostBottomBg release];
    
    
    mostBottomBg = [[UIView alloc] initWithFrame:CGRectMake(0, 
                                                            0, 
                                                            horizontalShift, 
                                                            barHeight)];
    mostBottomBg.backgroundColor = kBeigeColor;
    mostBottomBg.layer.cornerRadius = 3.0f;
    mostBottomBg.layer.masksToBounds = YES;
    [holder insertSubview:mostBottomBg atIndex:0];
    [mostBottomBg release];
    
    mostBottomBg = [[UIView alloc] initWithFrame:CGRectMake(0, 
                                                            1, 
                                                            horizontalShift, 
                                                            barHeight)];
    mostBottomBg.backgroundColor = kBrownColor;
    mostBottomBg.layer.cornerRadius = 3.0f;
    mostBottomBg.layer.masksToBounds = YES;
    mostBottomBg.alpha = 0.5f;
    [holder insertSubview:mostBottomBg atIndex:0];
    [mostBottomBg release];
    
    
    [self setActivePage:0];
}

- (void)setActivePage:(NSInteger) page
{
    if(page < 0 || page > [_viewsArray count])
    {
        dlog(@"Page index %i is out of bounds", page);
        return;
    }
    
    for(UIView *view in _viewsArray)
    {
        if([view isKindOfClass:[UIImageView class]])
        {
            UIImage *photoImage = [UIImage imageNamed:@"dot-photo-inactive.png"];
            ((UIImageView *)view).image = photoImage;
        }
        else
            view.backgroundColor = kGrayColor;
    }
    
    UIView *view = [_viewsArray objectAtIndex:page];
    
    if([view isKindOfClass:[UIImageView class]])
    {
        UIImage *photoImage = [UIImage imageNamed:@"dot-photo-active.png"];
        ((UIImageView *)view).image = photoImage;
    }
    else
        view.backgroundColor = kBrownColor;
}

@end