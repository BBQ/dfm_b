//
//  EmptyScreenVC.h
//  dish.fm
//
//  Created by Petr Prokop on 3/27/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum{
    kEmptyScreenTypeMe = 1,
    kEmptyScreenTypeFriends,
    kEmptyScreenTypeDiscover,
    kEmptyScreenTypeNews,
    kEmptyScreenTypeFollowing,
    kEmptyScreenTypeGeolocationDisabled
} EmptyScreenType;


@interface EmptyScreenVC : NSObject
{
    IBOutlet UIImageView *_iv;
    IBOutlet UILabel *_upperLabel;
    IBOutlet UILabel *_lowerLabel;
}

@property (nonatomic, retain) IBOutlet UIView *view;

- (id)initWithType:(EmptyScreenType)type;

@end
