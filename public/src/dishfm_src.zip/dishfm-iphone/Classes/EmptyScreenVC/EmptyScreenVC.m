//
//  EmptyScreenVC.m
//  dish.fm
//
//  Created by Petr Prokop on 3/27/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "EmptyScreenVC.h"

@implementation EmptyScreenVC

@synthesize view;

- (id)initWithType:(EmptyScreenType)type
{
    self = [super init];
    
    if(self)
    {
        [[NSBundle mainBundle] loadNibNamed:@"EmptyScreenVC" owner:self options:nil];
        
        if(type == kEmptyScreenTypeMe)
        {
            _iv.image = [UIImage imageNamed:@"emptyIcon02.png"];
            _upperLabel.text = @"Your dish-ins will appear here";
            _lowerLabel.text = @"Add your favourite dish!";
        }
        else if(type == kEmptyScreenTypeFriends)
        {
            _iv.image = [UIImage imageNamed:@"emptyIcon02.png"];
            _upperLabel.text = @"Your friends dish-ins will appear here";
            _lowerLabel.text = @"Add some friends";
        }
        else if(type == kEmptyScreenTypeDiscover)
        {
            _iv.image = [UIImage imageNamed:@"emptyIcon01.png"];
            _upperLabel.text = @"No results";
            _lowerLabel.text = @"Try something more general or expand your radius";
        }
        else if(type == kEmptyScreenTypeNews)
        {
            _iv.image = [UIImage imageNamed:@"emptyIcon03.png"];
            _upperLabel.text = @"Comments and likes on your dish-ins will appear here";
            _lowerLabel.text = @"Add some friends and post something";
        }
        else if(type == kEmptyScreenTypeFollowing)
        {
            _iv.image = [UIImage imageNamed:@"emptyIcon04.png"];
            _upperLabel.text = @"No one is here";
            _lowerLabel.text = @"Add some friends and post something";
        }
        else if(type == kEmptyScreenTypeGeolocationDisabled)
        {
            _iv.image = nil;
            _upperLabel.text = @"Settings > Location Services > Dish.fm";
            _upperLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:16.0];
            _lowerLabel.text = @"Location services are disabled. To proceed with dish-in, you need to enable location services for Dish.fm. Then we will be able to show you nearby places.";
            _lowerLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:12.0];
        }
    }
    
    return self;
}

- (void)dealloc
{
    self.view = nil;
    [super dealloc];
}

@end
