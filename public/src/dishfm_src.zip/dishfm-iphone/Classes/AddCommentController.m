//
//  AddCommentController.m
//  dish.fm
//
//  Created by Petr Prokop on 11/21/11.
//  Copyright (c) 2011 Dish.FM. All rights reserved.
//

#import "AddCommentController.h"
#import "RequestProcessor.h"
#import "ConvenientPopups.h"
#import "FeedItemModel.h"
#import "ReviewCommentsController.h"
#import "Utils.h"

@implementation AddCommentController

@synthesize textView;
@synthesize charactersLeftCount;
@synthesize delegate;
@synthesize row;

- (id)initWithReviewId:(NSInteger) aReviewId
{
    self = [super init];
    
    if (self) 
    {
        _reviewId = aReviewId;
        _isSendingComment = NO;
    }
    
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.navigationItem setHidesBackButton:YES animated:YES];
    
    [self.textView setDelegate:self];
    [self.textView becomeFirstResponder];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 24)];
    titleLabel.text = @"What do you think?";
    titleLabel.textColor = [UIColor colorWithRed:97.0/255 green:40.0/255 blue:15.0/255 alpha:1.0];
    titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:24.0];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];
}

- (void)viewDidUnload
{
    [self setTextView:nil];
    [self setCharactersLeftCount:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [textView release];
    [charactersLeftCount release];
    [super dealloc];
}

- (BOOL)textView:(UITextView *)aTextView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    //dlog(@"shouldChangeCharactersInRange");
    
    NSString *output = [aTextView.text stringByReplacingCharactersInRange:range withString:text];
    
    self.charactersLeftCount.text = [NSString stringWithFormat:@"%i", 200-[output length]];
    
    if(200-[output length] <= 0)
        return NO;
    else
        return YES;
}

#pragma mark -
#pragma mark Actions

- (IBAction)sendComment:(id)sender
{
    if(_isSendingComment)
        return;
    
    if(textView.text == nil || 
       [[Utils trimSpacesFromString:textView.text] isEqualToString:@""]
       )
    {
        [ConvenientPopups showAlertWithTitle:@"" andMessage:@"Please write something!"];
        return;
    }
    
    
    [ConvenientPopups showNonBlockingPopupOnView:self.view withText:@"Your thoughts are on the way..."];
    
    _isSendingComment = YES;
    
    RequestProcessor *requestProcessor = [[RequestProcessor alloc] init];
    [requestProcessor commentOnReview:_reviewId comment:textView.text];
    requestProcessor.delegate = self;
    [requestProcessor release];
}

- (IBAction)cancel:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark RequestProcessor delegate

- (void)requestProcessorSuccessCallback:(RequestProcessor *)processor
{
    _isSendingComment = NO;
    
    [ConvenientPopups showAlertWithTitle:@"" andMessage:@"Your comment has been posted successfully"];
    
    if(self.delegate)
    {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"reviewId == %i", _reviewId];
        FeedItemModel *review = (FeedItemModel *)[[self.delegate.feedItems filteredArrayUsingPredicate:predicate] objectAtIndex:0];

        review.comments++;
        [self.delegate.tableViewController.tableView reloadData];
        
        /*
        [self.delegate performSelector:@selector(showAllComments:) 
                            withObject:self.parentButton 
                            afterDelay:0.5f];
        */
        
        //[self.delegate showAllComments:self.parentButton];
        
        //[self.delegate showDetailsForRow:self.row];
        [self.delegate commentIsAdded];
        
        /*
        ReviewCommentsController *reviewCommentsController = [[ReviewCommentsController alloc] initWithFeedItem:review];
        reviewCommentsController.delegate = self.delegate;
        [[self retain] autorelease];
        [self.navigationController popViewControllerAnimated:NO];
        [self.delegate.navigationController pushViewController:reviewCommentsController animated:YES];
        [reviewCommentsController release];
         */
        
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)requestProcessorFailedCallback:(RequestProcessor *)processor
{
    _isSendingComment = NO;
}

@end
