#import <Foundation/Foundation.h>

@interface ConvenientPopups : NSObject 
{

}

@property (nonatomic, retain) NSURL *url;

+ (void)closePopup;
+ (void)showLoadingPopupWithTitle:(NSString *) title;
+ (void)showAlertWithTitle:(NSString *) title 
				andMessage:(NSString *) message;

+ (void)showNonBlockingPopupOnView:(UIView *)aView
						  withText:(NSString *)aText;

+ (void)centerPopupOnView:(UIView *)view;

+ (void)resetAnimations;

+ (void)closeNonBlockingPopupOnView:(UIView *)aView;

+ (void)showToastLikeMessage:(NSString *)message
                      onView:(UIView *)aView;

+ (void)showToastLikeMessage:(NSString *)message
                      onView:(UIView *)aView
                   imageName:(NSString *)imageName;

+ (void)showToastLikeMessage:(NSString *)message
                      onView:(UIView *)aView
                   imageName:(NSString *)imageName
               verticalShift:(CGFloat)verticalShift;

@end
