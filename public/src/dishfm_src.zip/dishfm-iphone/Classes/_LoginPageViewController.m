//
//  LoginPageViewController.m
//  dish.fm
//
//  Created by Petr Prokop on 2/6/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "_LoginPageViewController.h"
#import "LoginController.h"
#import "DataSource.h"
#import <QuartzCore/QuartzCore.h>
#import "ConvenientPopups.h"

@implementation _LoginPageViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) 
    {
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(currentUserInfoArrived:) 
                                                     name:@"currentUserInfoArrived"
                                                   object:nil];
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    [_viewsToRound release];
    [super dealloc];
}

- (void)currentUserInfoArrived:(NSNotification *) notification
{
    [[DataSource instance].tabBar dismissModalViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    for(UIView *view in _viewsToRound)
    {
        view.layer.masksToBounds = YES;
        view.layer.cornerRadius = 3.0f;
    }
    
    for(UIView *view in _viewsToShadow)
    {
        UIView *shadow = [[UIView alloc] initWithFrame:view.frame];
        shadow.layer.cornerRadius = 3.0f;
        shadow.layer.shadowOffset = CGSizeMake(0, 1);
        shadow.layer.shadowOpacity = 0.3f;
        shadow.layer.shadowPath = [UIBezierPath bezierPathWithRect:shadow.bounds].CGPath;
        [view.superview insertSubview:shadow belowSubview:view];
        [shadow release];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)cancel:(id)sender
{
    [self dismissModalViewControllerAnimated:YES];
}

- (IBAction)loginWithFacebook:(id)sender
{
    [LoginController instance].delegate = self;
    [[LoginController instance] loginWithFacebook];
}

- (IBAction)loginWithTwitter:(id)sender
{
    [LoginController instance].delegate = self;
    [[LoginController instance] loginWithTwitter];
}

- (IBAction)loginWithEmail:(id)sender
{
    [LoginController instance].delegate = self;
    [[LoginController instance] loginWithEmail];
}

- (void)didLogin
{
    //[ConvenientPopups showLoadingPopupWithTitle:@"Trying to find you..."];
    //[self dismissModalViewControllerAnimated:YES];
    [ConvenientPopups showNonBlockingPopupOnView:self.view withText:@"Trying to find you..."];
}

- (void)loginCancelled
{
    [self dismissModalViewControllerAnimated:YES];
}

@end
