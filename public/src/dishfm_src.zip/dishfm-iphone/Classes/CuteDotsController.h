//
//  CuteDotsController.h
//  dish.fm
//
//  Created by Petr Prokop on 1/25/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CuteDotsController : NSObject
{
    NSInteger _numberOfDots;
    BOOL _photo;
    
    NSInteger _currentPage;
    NSMutableArray *_viewsArray;
}

@property (nonatomic, retain) UIView *view;



- (id)initWithFrame:(CGRect) frame;


- (void)setActivePage:(NSInteger) page;

- (void)setNumberOfDots:(NSInteger)numberOfDots
               andPhoto:(BOOL)photo;

@end
