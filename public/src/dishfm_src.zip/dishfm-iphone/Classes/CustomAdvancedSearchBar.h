//
//  CustomAdvancedSearchBar.h
//  dish.fm
//
//  Created by Petr Prokop on 1/26/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CustomAdvancedSearchBar : NSObject

@end
