#import <UIKit/UIKit.h>
#import "AdvancedSearchDelegate.h"

@interface AdvancedSearchController : UITableViewController<UITextFieldDelegate>
{
    BOOL _refineSearchIsOpen;
    BOOL _rangeOptionChanged;
    NSInteger _currentRangeOption;
    
    NSArray *_tips;
    NSString *_searchString;
    NSString *_sortingString;
    NSMutableArray *_options;
    
    IBOutlet UIButton *_sortByRatingButton;
    IBOutlet UIButton *_sortByDistanceButton;
    IBOutlet UIButton *_topSearchButton;
    
    IBOutletCollection(UIView) NSArray *_restaurantSpecificViews;
}


@property (nonatomic, retain) IBOutlet UIView *headerView;
@property (retain, nonatomic) IBOutlet UIImageView *selectRangeBullet;
@property (retain, nonatomic) IBOutlet UIView *refineSearchView;
@property (retain, nonatomic) IBOutlet UIImageView *refineSearchBackground;
@property (retain, nonatomic) IBOutlet UIButton *refineSearchButton;
@property (retain, nonatomic) IBOutlet UITextField *searchField;
@property (retain, nonatomic) IBOutlet UITextField *locationField;

@property (retain, nonatomic) IBOutlet UIView *searchView;
@property (retain, nonatomic) IBOutlet UIView *placeView;

//id<AdvancedSearchDelegate>
@property (nonatomic, assign) id<AdvancedSearchDelegate> delegate;

/*
 search options
 */

@property (nonatomic, retain) NSMutableArray *priceRanges;

@property (readwrite, assign) BOOL restaurantMode;

- (IBAction)optionClick:(id)sender;
- (IBAction)selectRangeButtonClick:(id)sender;
- (IBAction)priceRangeClick:(id)sender;
- (IBAction)refineSearchButtonClick:(id)sender;
- (IBAction)close;
- (IBAction)search;
- (IBAction)sortingClick:(id)sender;

@end
