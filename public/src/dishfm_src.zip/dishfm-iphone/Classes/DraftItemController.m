//
//  RestaurantBestDishesItemController.m
//  dish.fm
//
//  Created by Petr Prokop on 1/20/12.
//  Copyright (c) 2012 Dish.FM. All rights reserved.
//

#import "DraftItemController.h"
#import "Config.h"
#import "DataSource.h"
#import <QuartzCore/QuartzCore.h>
#import "DataSource.h"
#import "ReviewDraftModel.h"

#define kImagesTagShift 852963741

@implementation DraftItemController

@synthesize view;
@synthesize imagesArray;
@synthesize delegate;
@synthesize delegateTapCallback;
@synthesize delegateTapCallbackWithSender;
@synthesize row;

#pragma mark - init/dealloc

- (id)init
{
    self = [super init];
    
    if(self)
    {
        self.jumpIndex = 0;
        
        self.view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 70 , 100)];
        [self.view release];

         _iv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 70 , 70)];
        _iv.layer.masksToBounds = YES;
        _iv.layer.cornerRadius = 3;
        //_iv.tag = self.jumpIndex;
        //[_iv setCallbackOnImageTap:self method:@selector(imageTap:)];
        [self.view addSubview:_iv];


        UIButton *button = [UIButton buttonWithType:(UIButtonTypeCustom)];
        button.frame = _iv.frame;
        [button addTarget:self action:@selector(imageTap:) forControlEvents:(UIControlEventTouchUpInside)];
        [self.view addSubview:button];
        

        UIImage *image = [UIImage imageNamed:@"photoEmpty140.png"];
        _placeholderView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 
                                                                         0, 
                                                                         image.size.width,
                                                                         image.size.height)];
        _placeholderView.image = image;
        [self.view addSubview:_placeholderView];
        [_placeholderView release];

    }
    
    return self;
}

- (void)dealloc
{
    self.view = nil;
    self.imagesArray = nil;
    [_label release];

    [_iv release];
}

- (void)setJumpIndex:(NSInteger) index
{
    if(index < 0 || index >= [self.imagesArray count])
        return;
    
    _jumpIndex = index;

    ReviewDraftModel *rdm = [self.imagesArray objectAtIndex:index];

    
    _placeholderView.hidden = YES;


    if(rdm.photoData != nil)
    {
       _iv.image = [UIImage imageWithData:rdm.photoData];
    }
    else
    {
        _placeholderView.hidden = NO;
    }
}

- (void)setJumpIndexWithNumber:(NSNumber *)index
{
    [self setJumpIndex:[index intValue]];
}

- (NSInteger)jumpIndex
{
    return _jumpIndex;
}

- (void)imageTap:(UIView *)image
{
    NSInteger objectIndex = _jumpIndex; //image.tag - kImagesTagShift;
    
    if(self.delegate)
    {
        if(self.row &&
           self.delegate &&
           [self.delegate respondsToSelector:@selector(jumpingItemTouched:atRow:)]
           )
        {
            [self.delegate performSelector:@selector(jumpingItemTouched:atRow:) 
                                withObject:self
                                withObject:self.row];
        }
        else if(self.delegateTapCallback && [self.delegate respondsToSelector:self.delegateTapCallback])
            [self.delegate performSelector:self.delegateTapCallback 
                                withObject:[NSNumber numberWithInt:objectIndex]];
        else if([self.delegate respondsToSelector:@selector(tappedImageWithIndex:)])
            [self.delegate tappedImageWithIndex:objectIndex];
    }
}

@end